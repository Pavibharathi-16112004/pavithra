# routers/inventory.py — Full CRUD + AI Forecast
from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional
from config.database import get_db
from config.auth import get_current_user, require_role
from models.schemas import InventoryCreate, InventoryUpdate, StockActionRequest
from datetime import date

router = APIRouter(prefix="/api/inventory", tags=["Inventory"])

# ── GET /api/inventory ───────────────────────────────────────
@router.get("/")
def get_inventory(
    search:   Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    status:   Optional[str] = Query(None),
    db=Depends(get_db),
    _=Depends(get_current_user)
):
    cursor, _ = db
    query  = "SELECT * FROM inventory WHERE 1=1"
    params = []

    if search:
        query += " AND (name LIKE %s OR item_id LIKE %s)"
        params += [f"%{search}%", f"%{search}%"]
    if category:
        query += " AND category = %s"
        params.append(category)
    query += " ORDER BY name ASC"

    cursor.execute(query, params)
    items = cursor.fetchall()

    # Auto-calculate status + days left
    for item in items:
        item["status"]   = (
            "critical" if item["stock"] == 0
            else "warn" if item["stock"] < item["reorder_pt"]
            else "ok"
        )
        item["days_left"] = (
            item["stock"] // item["daily_use"]
            if item["daily_use"] > 0 else 999
        )
        # Convert date to string for JSON
        if item.get("expiry") and isinstance(item["expiry"], date):
            item["expiry"] = str(item["expiry"])

    # Filter by computed status if requested
    if status:
        items = [i for i in items if i["status"] == status]

    return {"success": True, "data": items, "total": len(items)}

# ── GET /api/inventory/{id} ──────────────────────────────────
@router.get("/{item_id}")
def get_item(item_id: str, db=Depends(get_db), _=Depends(get_current_user)):
    cursor, _ = db
    cursor.execute(
        "SELECT * FROM inventory WHERE id=%s OR item_id=%s",
        (item_id, item_id)
    )
    item = cursor.fetchone()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    if item.get("expiry") and isinstance(item["expiry"], date):
        item["expiry"] = str(item["expiry"])
    return {"success": True, "data": item}

# ── POST /api/inventory ──────────────────────────────────────
@router.post("/")
def add_item(
    body: InventoryCreate,
    db=Depends(get_db),
    user=Depends(require_role("admin", "pharmacist"))
):
    cursor, conn = db
    try:
        cursor.execute(
            """INSERT INTO inventory
               (item_id, name, category, stock, max_stock, reorder_pt, daily_use, location, expiry, barcode)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (body.item_id, body.name, body.category, body.stock,
             body.max_stock, body.reorder_pt, body.daily_use,
             body.location, body.expiry, body.barcode)
        )
        conn.commit()
        cursor.execute(
            "INSERT INTO audit_logs (user_id,action,module,details) VALUES(%s,%s,%s,%s)",
            (user["id"], "ADD_ITEM", "inventory", f"Added {body.name} ({body.item_id})")
        )
        conn.commit()
        return {"success": True, "message": "Item added", "id": cursor.lastrowid}
    except Exception as e:
        if "Duplicate" in str(e):
            raise HTTPException(status_code=409, detail="Item ID already exists")
        raise HTTPException(status_code=500, detail=str(e))

# ── PUT /api/inventory/{id} ──────────────────────────────────
@router.put("/{item_id}")
def update_item(
    item_id: str,
    body: InventoryUpdate,
    db=Depends(get_db),
    user=Depends(require_role("admin", "pharmacist"))
):
    cursor, conn = db
    fields = {k: v for k, v in body.dict().items() if v is not None}
    if not fields:
        raise HTTPException(status_code=400, detail="No fields to update")

    set_clause = ", ".join(f"{k}=%s" for k in fields)
    values     = list(fields.values()) + [item_id, item_id]

    cursor.execute(
        f"UPDATE inventory SET {set_clause} WHERE id=%s OR item_id=%s",
        values
    )
    conn.commit()
    cursor.execute(
        "INSERT INTO audit_logs (user_id,action,module,details) VALUES(%s,%s,%s,%s)",
        (user["id"], "EDIT_ITEM", "inventory", f"Updated {item_id}")
    )
    conn.commit()
    return {"success": True, "message": "Item updated"}

# ── DELETE /api/inventory/{id} ───────────────────────────────
@router.delete("/{item_id}")
def delete_item(
    item_id: str,
    db=Depends(get_db),
    user=Depends(require_role("admin"))
):
    cursor, conn = db
    cursor.execute("SELECT name FROM inventory WHERE id=%s OR item_id=%s", (item_id, item_id))
    item = cursor.fetchone()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")

    cursor.execute("DELETE FROM inventory WHERE id=%s OR item_id=%s", (item_id, item_id))
    conn.commit()
    cursor.execute(
        "INSERT INTO audit_logs (user_id,action,module,details) VALUES(%s,%s,%s,%s)",
        (user["id"], "DELETE_ITEM", "inventory", f"Deleted {item['name']}")
    )
    conn.commit()
    return {"success": True, "message": "Item deleted"}

# ── POST /api/inventory/{id}/stock ───────────────────────────
@router.post("/{item_id}/stock")
def stock_action(
    item_id: str,
    body: StockActionRequest,
    db=Depends(get_db),
    user=Depends(require_role("admin", "pharmacist", "nurse"))
):
    cursor, conn = db
    cursor.execute("SELECT * FROM inventory WHERE id=%s OR item_id=%s", (item_id, item_id))
    item = cursor.fetchone()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")

    before = item["stock"]
    after  = (before + body.quantity) if body.action == "stock_in" else max(0, before - body.quantity)

    cursor.execute("UPDATE inventory SET stock=%s WHERE id=%s", (after, item["id"]))
    cursor.execute(
        """INSERT INTO stock_transactions
           (item_id, action, quantity, before_qty, after_qty, reason, done_by)
           VALUES (%s,%s,%s,%s,%s,%s,%s)""",
        (item["id"], body.action, body.quantity, before, after, body.reason, user["id"])
    )
    conn.commit()

    # Auto-alert if stock drops below reorder point
    if after < item["reorder_pt"]:
        severity = "critical" if after == 0 else "warning"
        cursor.execute(
            """INSERT INTO alerts (type, item_id, message, severity)
               SELECT %s,%s,%s,%s WHERE NOT EXISTS (
                 SELECT 1 FROM alerts WHERE item_id=%s AND type='low_stock' AND resolved=0
               )""",
            ("low_stock", item["id"],
             f"{item['name']}: Only {after} units remaining", severity,
             item["id"])
        )
        conn.commit()

    return {
        "success": True,
        "before": before,
        "after":  after,
        "message": f"Stock {'added' if body.action == 'stock_in' else 'reduced'} successfully"
    }

# ── GET /api/inventory/{id}/forecast ────────────────────────
@router.get("/{item_id}/forecast")
def get_forecast(item_id: str, db=Depends(get_db), _=Depends(get_current_user)):
    cursor, _ = db
    cursor.execute("SELECT * FROM inventory WHERE id=%s OR item_id=%s", (item_id, item_id))
    item = cursor.fetchone()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")

    # Last 30 days actual usage from transactions
    cursor.execute(
        """SELECT DATE(done_at) as dt, SUM(quantity) as total
           FROM stock_transactions
           WHERE item_id=%s AND action='stock_out'
           AND done_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
           GROUP BY DATE(done_at) ORDER BY dt ASC""",
        (item["id"],)
    )
    txns = cursor.fetchall()

    # Weighted Moving Average (AI Forecast Engine)
    history = [t["total"] for t in txns] if txns else [item["daily_use"]]
    w_sum, weights = 0, 0
    for i, val in enumerate(history):
        w       = i + 1
        w_sum  += val * w
        weights += w

    avg_daily    = w_sum / weights if weights else item["daily_use"]
    forecast_7   = round(avg_daily * 7  * 1.05)   # +5% safety buffer
    forecast_30  = round(avg_daily * 30 * 1.05)
    days_left    = int(item["stock"] / avg_daily) if avg_daily > 0 else 999
    need_reorder = item["stock"] < item["reorder_pt"]

    return {
        "success": True,
        "item": {"id": item["item_id"], "name": item["name"], "stock": item["stock"]},
        "forecast": {
            "avg_daily_usage":  round(avg_daily),
            "next_7_days":      forecast_7,
            "next_30_days":     forecast_30,
            "days_until_empty": days_left,
            "need_reorder":     need_reorder,
            "suggested_order":  max(forecast_30, item["max_stock"] - item["stock"]) if need_reorder else 0
        }
    }
