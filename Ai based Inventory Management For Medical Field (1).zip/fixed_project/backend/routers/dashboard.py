# routers/dashboard.py — Stats, Alerts, Audit Logs, Reorder
from fastapi import APIRouter, Depends
from config.database import get_db
from config.auth import get_current_user, require_role

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])

# ── GET /api/dashboard/stats ─────────────────────────────────
@router.get("/stats")
def get_stats(db=Depends(get_db), _=Depends(get_current_user)):
    cursor, _ = db

    cursor.execute("SELECT COUNT(*) AS count FROM inventory")
    total_items = cursor.fetchone()["count"]

    cursor.execute("SELECT COUNT(*) AS count FROM inventory WHERE stock < reorder_pt")
    critical = cursor.fetchone()["count"]

    cursor.execute(
        "SELECT COUNT(*) AS count FROM inventory WHERE expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)"
    )
    expiring = cursor.fetchone()["count"]

    cursor.execute("SELECT COUNT(*) AS count FROM purchase_orders WHERE status='pending'")
    pending_pos = cursor.fetchone()["count"]

    cursor.execute("SELECT category, COUNT(*) AS count FROM inventory GROUP BY category")
    categories = cursor.fetchall()

    cursor.execute(
        """SELECT t.*, i.name AS item_name, u.name AS user_name
           FROM stock_transactions t
           LEFT JOIN inventory i ON t.item_id = i.id
           LEFT JOIN users     u ON t.done_by  = u.id
           ORDER BY t.done_at DESC LIMIT 10"""
    )
    recent = cursor.fetchall()
    for r in recent:
        if r.get("done_at"):
            r["done_at"] = str(r["done_at"])

    return {
        "success": True,
        "stats": {
            "total_items":    total_items,
            "critical_items": critical,
            "expiring_items": expiring,
            "pending_pos":    pending_pos
        },
        "categories": categories,
        "recent_transactions": recent
    }

# ── GET /api/dashboard/alerts ────────────────────────────────
@router.get("/alerts")
def get_alerts(db=Depends(get_db), _=Depends(get_current_user)):
    cursor, conn = db

    # Auto-generate alerts from current stock
    _generate_alerts(cursor, conn)

    cursor.execute(
        """SELECT a.*, i.name AS item_name, i.stock, i.reorder_pt
           FROM alerts a
           LEFT JOIN inventory i ON a.item_id = i.id
           WHERE a.resolved = 0
           ORDER BY a.created_at DESC"""
    )
    alerts = cursor.fetchall()
    for a in alerts:
        if a.get("created_at"):
            a["created_at"] = str(a["created_at"])

    return {"success": True, "data": alerts, "count": len(alerts)}

# ── PUT /api/dashboard/alerts/{id}/resolve ───────────────────
@router.put("/alerts/{alert_id}/resolve")
def resolve_alert(
    alert_id: int,
    db=Depends(get_db),
    user=Depends(require_role("admin", "pharmacist"))
):
    cursor, conn = db
    cursor.execute("UPDATE alerts SET resolved=1 WHERE id=%s", (alert_id,))
    conn.commit()
    return {"success": True, "message": "Alert resolved"}

# ── GET /api/dashboard/reorder ───────────────────────────────
@router.get("/reorder")
def get_reorder_list(db=Depends(get_db), _=Depends(get_current_user)):
    cursor, _ = db
    cursor.execute(
        """SELECT *,
             DATEDIFF(expiry, CURDATE())              AS days_to_expiry,
             FLOOR(stock / NULLIF(daily_use, 0))      AS days_of_stock
           FROM inventory
           WHERE stock < reorder_pt
           ORDER BY stock ASC"""
    )
    items = cursor.fetchall()
    for i in items:
        if i.get("expiry"):
            i["expiry"] = str(i["expiry"])
    return {"success": True, "data": items, "count": len(items)}

# ── GET /api/dashboard/audit ─────────────────────────────────
@router.get("/audit")
def get_audit_logs(
    db=Depends(get_db),
    user=Depends(require_role("admin"))
):
    cursor, _ = db
    cursor.execute(
        """SELECT l.*, u.name AS user_name, u.role
           FROM audit_logs l
           LEFT JOIN users u ON l.user_id = u.id
           ORDER BY l.logged_at DESC LIMIT 100"""
    )
    logs = cursor.fetchall()
    for l in logs:
        if l.get("logged_at"):
            l["logged_at"] = str(l["logged_at"])
    return {"success": True, "data": logs}

# ── Helper ────────────────────────────────────────────────────
def _generate_alerts(cursor, conn):
    """Inventory-ல இருந்து auto alerts generate பண்றது"""
    # Low stock
    cursor.execute("SELECT * FROM inventory WHERE stock < reorder_pt")
    for item in cursor.fetchall():
        cursor.execute(
            """INSERT INTO alerts (type, item_id, message, severity)
               SELECT %s,%s,%s,%s WHERE NOT EXISTS (
                 SELECT 1 FROM alerts WHERE item_id=%s AND type='low_stock' AND resolved=0
               )""",
            ("low_stock", item["id"],
             f"{item['name']}: Only {item['stock']} units left (reorder at {item['reorder_pt']})",
             "critical" if item["stock"] == 0 else "warning",
             item["id"])
        )
    # Expiring within 30 days
    cursor.execute(
        "SELECT * FROM inventory WHERE expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)"
    )
    for item in cursor.fetchall():
        cursor.execute(
            """INSERT INTO alerts (type, item_id, message, severity)
               SELECT %s,%s,%s,%s WHERE NOT EXISTS (
                 SELECT 1 FROM alerts WHERE item_id=%s AND type='expiry' AND resolved=0
               )""",
            ("expiry", item["id"],
             f"{item['name']} expires on {item['expiry']}",
             "warning", item["id"])
        )
    conn.commit()
