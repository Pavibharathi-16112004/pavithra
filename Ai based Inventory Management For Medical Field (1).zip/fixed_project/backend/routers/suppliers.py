# routers/suppliers.py — Suppliers + Purchase Orders
from fastapi import APIRouter, Depends, HTTPException
from config.database import get_db
from config.auth import get_current_user, require_role
from models.schemas import SupplierCreate, POCreate, POStatusUpdate

router = APIRouter(prefix="/api/suppliers", tags=["Suppliers"])

# ── GET /api/suppliers ───────────────────────────────────────
@router.get("/")
def get_suppliers(db=Depends(get_db), _=Depends(get_current_user)):
    cursor, _ = db
    cursor.execute("SELECT * FROM suppliers ORDER BY name ASC")
    return {"success": True, "data": cursor.fetchall()}

# ── POST /api/suppliers ──────────────────────────────────────
@router.post("/")
def add_supplier(
    body: SupplierCreate,
    db=Depends(get_db),
    user=Depends(require_role("admin"))
):
    cursor, conn = db
    cursor.execute(
        """INSERT INTO suppliers
           (supplier_id, name, contact, phone, email, location, category, pay_terms, gst)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (body.supplier_id, body.name, body.contact, body.phone,
         body.email, body.location, body.category, body.pay_terms, body.gst)
    )
    conn.commit()
    return {"success": True, "id": cursor.lastrowid}

# ── GET /api/suppliers/orders ────────────────────────────────
@router.get("/orders")
def get_orders(db=Depends(get_db), _=Depends(get_current_user)):
    cursor, _ = db
    cursor.execute(
        """SELECT po.*,
             s.name  AS supplier_name,
             i.name  AS item_name,
             u.name  AS ordered_by_name
           FROM purchase_orders po
           LEFT JOIN suppliers s ON po.supplier_id = s.id
           LEFT JOIN inventory i ON po.item_id     = i.id
           LEFT JOIN users     u ON po.ordered_by  = u.id
           ORDER BY po.ordered_at DESC"""
    )
    rows = cursor.fetchall()
    for r in rows:
        for k in ("ordered_at", "delivered_at"):
            if r.get(k):
                r[k] = str(r[k])
    return {"success": True, "data": rows}

# ── POST /api/suppliers/orders ───────────────────────────────
@router.post("/orders")
def create_order(
    body: POCreate,
    db=Depends(get_db),
    user=Depends(require_role("admin", "pharmacist"))
):
    cursor, conn = db
    total = body.quantity * body.unit_price
    cursor.execute(
        """INSERT INTO purchase_orders
           (po_id, supplier_id, item_id, quantity, unit_price, total, ordered_by)
           VALUES (%s,%s,%s,%s,%s,%s,%s)""",
        (body.po_id, body.supplier_id, body.item_id,
         body.quantity, body.unit_price, total, user["id"])
    )
    conn.commit()
    cursor.execute(
        "INSERT INTO audit_logs (user_id,action,module,details) VALUES(%s,%s,%s,%s)",
        (user["id"], "CREATE_PO", "suppliers", f"PO {body.po_id} created")
    )
    conn.commit()
    return {"success": True, "id": cursor.lastrowid, "po_id": body.po_id}

# ── PUT /api/suppliers/orders/{id} ───────────────────────────
@router.put("/orders/{order_id}")
def update_order_status(
    order_id: int,
    body: POStatusUpdate,
    db=Depends(get_db),
    user=Depends(require_role("admin"))
):
    cursor, conn = db

    delivered_at = "NOW()" if body.status == "delivered" else "NULL"
    cursor.execute(
        f"UPDATE purchase_orders SET status=%s, delivered_at={delivered_at} WHERE id=%s",
        (body.status, order_id)
    )
    conn.commit()

    # Auto stock-in when delivered
    if body.status == "delivered":
        cursor.execute("SELECT * FROM purchase_orders WHERE id=%s", (order_id,))
        po = cursor.fetchone()
        if po:
            cursor.execute(
                "UPDATE inventory SET stock = stock + %s WHERE id=%s",
                (po["quantity"], po["item_id"])
            )
            cursor.execute(
                """INSERT INTO stock_transactions
                   (item_id, action, quantity, reason, done_by)
                   VALUES (%s,'stock_in',%s,%s,%s)""",
                (po["item_id"], po["quantity"], f"PO Delivered: {po['po_id']}", user["id"])
            )
            conn.commit()

    return {"success": True, "message": f"PO status → {body.status}"}
