# routers/auth.py — Login, OTP, Reset Password
from fastapi import APIRouter, Depends, HTTPException
from passlib.context import CryptContext
from config.database import get_db
from config.auth import create_token, decode_token, get_current_user
from models.schemas import LoginRequest, ForgotPasswordRequest, VerifyOTPRequest, ResetPasswordRequest
import random, time

router = APIRouter(prefix="/api/auth", tags=["Auth"])
pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

# In-memory OTP store { email: {otp, expires} }
otp_store = {}

# ── POST /api/auth/setup ── Hash seed passwords (1 time only)
@router.post("/setup")
def setup_passwords(db=Depends(get_db)):
    """First time run பண்ணும் போது இதை call பண்ணுங்க — passwords hash ஆகும்"""
    cursor, conn = db
    cursor.execute("SELECT id, password FROM users")
    users = cursor.fetchall()
    for u in users:
        if not u["password"].startswith("$2"):   # not yet hashed
            hashed = pwd_ctx.hash(u["password"])
            cursor.execute("UPDATE users SET password=%s WHERE id=%s", (hashed, u["id"]))
    conn.commit()
    return {"success": True, "message": "Passwords hashed successfully"}

# ── POST /api/auth/login ──────────────────────────────────────
@router.post("/login")
def login(body: LoginRequest, db=Depends(get_db)):
    cursor, conn = db

    cursor.execute("SELECT * FROM users WHERE email=%s AND active=1", (body.email,))
    user = cursor.fetchone()

    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    # Check password (bcrypt or plain for demo)
    valid = pwd_ctx.verify(body.password, user["password"]) \
            if user["password"].startswith("$2") \
            else body.password == user["password"]

    if not valid:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    # Audit log
    cursor.execute(
        "INSERT INTO audit_logs (user_id, action, module, details) VALUES (%s,%s,%s,%s)",
        (user["id"], "LOGIN", "auth", "User logged in")
    )
    conn.commit()

    token = create_token({
        "id":       user["id"],
        "username": user["username"],
        "role":     user["role"],
        "name":     user["name"]
    })

    return {
        "success": True,
        "token": token,
        "user": {
            "id":       user["id"],
            "name":     user["name"],
            "role":     user["role"],
            "email":    user["email"],
            "initials": user["initials"]
        }
    }

# ── POST /api/auth/forgot-password ───────────────────────────
@router.post("/forgot-password")
def forgot_password(body: ForgotPasswordRequest, db=Depends(get_db)):
    cursor, _ = db
    cursor.execute("SELECT id FROM users WHERE email=%s", (body.email,))
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Email not found")

    otp = str(random.randint(100000, 999999))
    otp_store[body.email] = {"otp": otp, "expires": time.time() + 600}  # 10 min

    print(f"[OTP] {body.email} → {otp}")  # Console-ல தெரியும்
    return {"success": True, "message": "OTP generated", "otp": otp}  # Demo only

# ── POST /api/auth/verify-otp ────────────────────────────────
@router.post("/verify-otp")
def verify_otp(body: VerifyOTPRequest):
    stored = otp_store.get(body.email)
    if not stored or stored["otp"] != body.otp or time.time() > stored["expires"]:
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")

    reset_token = create_token({"email": body.email, "purpose": "reset"})
    return {"success": True, "reset_token": reset_token}

# ── POST /api/auth/reset-password ────────────────────────────
@router.post("/reset-password")
def reset_password(body: ResetPasswordRequest, db=Depends(get_db)):
    cursor, conn = db
    payload = decode_token(body.reset_token)

    if payload.get("purpose") != "reset":
        raise HTTPException(status_code=400, detail="Invalid reset token")

    hashed = pwd_ctx.hash(body.new_password)
    cursor.execute("UPDATE users SET password=%s WHERE email=%s", (hashed, payload["email"]))
    conn.commit()

    otp_store.pop(payload["email"], None)
    return {"success": True, "message": "Password reset successful"}

# ── GET /api/auth/me ─────────────────────────────────────────
@router.get("/me")
def get_me(user=Depends(get_current_user), db=Depends(get_db)):
    cursor, _ = db
    cursor.execute("SELECT id,name,role,email,initials FROM users WHERE id=%s", (user["id"],))
    return {"success": True, "user": cursor.fetchone()}
