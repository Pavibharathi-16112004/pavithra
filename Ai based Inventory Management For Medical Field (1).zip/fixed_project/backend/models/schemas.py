# models/schemas.py — Request & Response Models
from pydantic import BaseModel, EmailStr
from typing import Optional, Literal
from datetime import date

# ── AUTH ──────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    email:    str
    password: str

class ForgotPasswordRequest(BaseModel):
    email: str

class VerifyOTPRequest(BaseModel):
    email: str
    otp:   str

class ResetPasswordRequest(BaseModel):
    reset_token:  str
    new_password: str

# ── INVENTORY ─────────────────────────────────────────────────
class InventoryCreate(BaseModel):
    item_id:   str
    name:      str
    category:  Literal['drug','critical','supply','equipment'] = 'drug'
    stock:     int = 0
    max_stock: int = 500
    reorder_pt:int = 100
    daily_use: int = 10
    location:  Optional[str] = None
    expiry:    Optional[date] = None
    barcode:   Optional[str] = None

class InventoryUpdate(BaseModel):
    name:      Optional[str]  = None
    category:  Optional[str]  = None
    max_stock: Optional[int]  = None
    reorder_pt:Optional[int]  = None
    daily_use: Optional[int]  = None
    location:  Optional[str]  = None
    expiry:    Optional[date]  = None
    barcode:   Optional[str]  = None

class StockActionRequest(BaseModel):
    action:   Literal['stock_in','stock_out','adjustment']
    quantity: int
    reason:   Optional[str] = ""

# ── SUPPLIER ──────────────────────────────────────────────────
class SupplierCreate(BaseModel):
    supplier_id: str
    name:        str
    contact:     Optional[str] = None
    phone:       Optional[str] = None
    email:       Optional[str] = None
    location:    Optional[str] = None
    category:    Optional[str] = None
    pay_terms:   Optional[str] = None
    gst:         Optional[str] = None

# ── PURCHASE ORDER ────────────────────────────────────────────
class POCreate(BaseModel):
    po_id:       str
    supplier_id: int
    item_id:     int
    quantity:    int
    unit_price:  float

class POStatusUpdate(BaseModel):
    status: Literal['pending','approved','delivered','cancelled']
