# config/database.py — MySQL Connection
import mysql.connector
from mysql.connector import pooling
from dotenv import load_dotenv
import os

load_dotenv()

# Connection pool — multiple requests handle ஆகும்
db_pool = pooling.MySQLConnectionPool(
    pool_name="medai_pool",
    pool_size=5,
    host     = os.getenv("DB_HOST",     "localhost"),
    port     = int(os.getenv("DB_PORT", "3306")),
    user     = os.getenv("DB_USER",     "root"),
    password = os.getenv("DB_PASSWORD", ""),
    database = os.getenv("DB_NAME",     "medai_pro"),
    charset  = "utf8mb4",
    time_zone= "+05:30"
)

def get_db():
    """FastAPI dependency — automatically connection return பண்ணும்"""
    conn   = db_pool.get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        yield cursor, conn
    finally:
        cursor.close()
        conn.close()
