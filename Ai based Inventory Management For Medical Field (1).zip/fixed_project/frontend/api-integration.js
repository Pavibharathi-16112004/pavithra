// ============================================================
//  api-integration.js — MedAI Pro  (Fixed)
//  Key fix: API field names → app.js field names mapping
//  API:    item_id, category, max_stock, daily_use, reorder_pt
//  app.js: id,     cat,      max,       dailyUse,  reorderPt
// ============================================================

const API = 'http://localhost:8000/api';
let _backendOnline = false;

// ── Token ─────────────────────────────────────────────────────
const Auth = {
  getToken: () => localStorage.getItem('medai_token'),
  setToken: t  => localStorage.setItem('medai_token', t),
  clearAll: () => {
    localStorage.removeItem('medai_token');
    localStorage.removeItem('medai_user');
  },
  headers: () => ({
    'Content-Type' : 'application/json',
    'Authorization': 'Bearer ' + (localStorage.getItem('medai_token') || '')
  })
};

// ── API item → app.js field mapping (THE KEY FIX) ─────────────
function _mapItem(item) {
  const catMap = { drug:'drug', critical:'critical', supply:'supply', equipment:'device', device:'device' };
  const cat    = catMap[item.category] || item.cat || 'drug';
  const stock  = item.stock || 0;
  const rpt    = item.reorder_pt || item.reorderPt || 100;
  return {
    ...item,
    id       : item.item_id    || item.id,
    cat      : cat,
    max      : item.max_stock  || item.max  || 500,
    dailyUse : item.daily_use  || item.dailyUse || 5,
    reorderPt: rpt,
    expiry   : item.expiry     || 'N/A',
    status   : item.status || (stock === 0 ? 'critical' : stock < rpt ? 'warn' : 'ok'),
  };
}

// ── API fetch — 5s timeout ────────────────────────────────────
async function apiFetch(path, opts = {}) {
  try {
    const ctrl  = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 5000);
    const res   = await fetch(API + path, { headers: Auth.headers(), signal: ctrl.signal, ...opts });
    clearTimeout(timer);
    const data = await res.json();
    if (res.status === 401) { Auth.clearAll(); location.reload(); }
    return data;
  } catch (e) {
    console.warn('[API]', path, e.name === 'AbortError' ? 'timeout' : e.message);
    return { success: false };
  }
}

// ── Loader ────────────────────────────────────────────────────
function showLoader(msg) {
  msg = msg || 'Loading...';
  let el = document.getElementById('apiLoader');
  if (!el) {
    el = document.createElement('div');
    el.id = 'apiLoader';
    el.style.cssText = 'position:fixed;inset:0;background:rgba(10,20,40,0.75);z-index:9999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;';
    el.innerHTML = '<div style="width:44px;height:44px;border:4px solid #1a3a5c;border-top:4px solid #00b4d8;border-radius:50%;animation:spin 0.8s linear infinite;"></div><div id="apiLoaderMsg" style="color:#90e0ef;font-size:14px;font-weight:600;">' + msg + '</div><style>@keyframes spin{to{transform:rotate(360deg)}}</style>';
    document.body.appendChild(el);
  } else {
    var m = document.getElementById('apiLoaderMsg');
    if (m) m.textContent = msg;
    el.style.display = 'flex';
  }
}

function hideLoader() {
  var el = document.getElementById('apiLoader');
  if (el) el.style.display = 'none';
}

// ════════════════════════════════════════════════════════════
//  LOGIN — Instant local + background API sync
// ════════════════════════════════════════════════════════════
window.doLogin = async function () {
  var email = document.getElementById('loginEmail').value.trim();
  var pass  = document.getElementById('loginPass').value;

  // Clear previous errors
  clearFieldError('emailError', 'loginEmail');
  clearFieldError('passError', 'loginPass');

  // Per-field validation
  if (!email && !pass) {
    showFieldError('emailError', 'loginEmail', 'Email address is required.');
    showFieldError('passError', 'loginPass', 'Password is required.');
    document.getElementById('loginEmail').focus(); return;
  }
  if (!email) {
    showFieldError('emailError', 'loginEmail', 'Email address is required.');
    document.getElementById('loginEmail').focus(); return;
  }
  if (!pass) {
    showFieldError('passError', 'loginPass', 'Password is required.');
    document.getElementById('loginPass').focus(); return;
  }

  // Instant local login
  var localUser = null;
  var emailOnly = null;
  var ukeys = Object.keys(users);
  for (var i = 0; i < ukeys.length; i++) {
    var u = users[ukeys[i]];
    if (u.email === email) { emailOnly = u; }
    if (u.email === email && u.pass === pass) { localUser = u; break; }
  }

  if (!localUser) {
    if (emailOnly) {
      showFieldError('passError', 'loginPass', 'Incorrect password. Please try again.');
      document.getElementById('loginPass').value = '';
      document.getElementById('loginPass').type = 'password';
      document.getElementById('eyeIcon').style.display = 'block';
      document.getElementById('eyeOffIcon').style.display = 'none';
    } else {
      showFieldError('emailError', 'loginEmail', 'Email not found. Check your credentials.');
    }
    document.getElementById('loginPass').focus();
    return;
  }

  // Show dashboard instantly with local data
  _showAppShell(localUser);
  currentData = [...inventoryData];
  try { renderTable(currentData); } catch(e) { console.warn('renderTable:', e); }
  try { renderAlerts();           } catch(e) {}
  try { renderChart();            } catch(e) {}
  try { renderReorder();          } catch(e) {}
  showToast('success', '✅ Logged In', 'Welcome, ' + localUser.name.split(' ')[0] + '!');

  // Background: try API login + live data
  _bgLogin(email, pass);
};

async function _bgLogin(email, pass) {
  try {
    var ping = await fetch(API + '/health', { signal: AbortSignal.timeout(2000) });
    if (!ping.ok) { _setBadge(false); return; }
  } catch(e) { _setBadge(false); return; }

  var data = await apiFetch('/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: email, password: pass })
  });

  if (data && data.success) {
    Auth.setToken(data.token);
    _setBadge(true);
    await _loadLiveData();
    showToast('info', '🔄 Live Data Loaded', 'Database synced successfully!');
  }
}

async function _loadLiveData() {
  try {
    // Load inventory with FIELD MAPPING
    var inv = await apiFetch('/inventory');
    if (inv.success && Array.isArray(inv.data) && inv.data.length > 0) {
      inventoryData = inv.data.map(_mapItem);
      currentData   = [...inventoryData];
      try { renderTable(currentData); } catch(e) { console.warn('renderTable error:', e); }
    }

    var sup = await apiFetch('/suppliers');
    if (sup.success && Array.isArray(sup.data)) suppliers = sup.data;

    var stats = await apiFetch('/dashboard/stats');
    if (stats.success && stats.stats) _updateCards(stats.stats);

    var al = await apiFetch('/dashboard/alerts');
    if (al.success && Array.isArray(al.data)) {
      _patchAlerts(al.data);
      try { renderAlerts(); } catch(e) {}
    }
  } catch(e) {
    console.warn('[_loadLiveData]', e);
  }
}

function _showAppShell(user) {
  currentUser = user;
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('appShell').style.display    = 'block';
  var ids = { sidebarAvatar: user.initials, sidebarName: user.name, sidebarRole: user.role, topbarAvatar: user.initials };
  Object.keys(ids).forEach(function(id) {
    var el = document.getElementById(id); if (el) el.textContent = ids[id];
  });
  var ta = document.getElementById('topbarAvatar');
  if (ta) ta.title = user.name;
}

window.quickLogin = function (role) {
  var map = { admin:{e:'admin@hospital.com',p:'medai2024'}, pharmacist:{e:'pharmacist@hospital.com',p:'pharma123'}, nurse:{e:'nurse@hospital.com',p:'nurse2024'}, viewer:{e:'viewer@hospital.com',p:'view2024'} };
  var c = map[role];
  document.getElementById('loginEmail').value = c.e;
  document.getElementById('loginPass').value  = c.p;
  window.doLogin();
};

// ════════════════════════════════════════════════════════════
//  LOGOUT
// ════════════════════════════════════════════════════════════
window.doLogout = function () {
  Auth.clearAll();
  document.getElementById('appShell').style.display    = 'none';
  document.getElementById('loginScreen').style.display = 'flex';
  showToast('info', '👋 Logged Out', 'You have been securely logged out.');
};

// ════════════════════════════════════════════════════════════
//  MANUAL REFRESH
// ════════════════════════════════════════════════════════════
window.refreshFromDB = async function () {
  try {
    var ping = await fetch(API + '/health', { signal: AbortSignal.timeout(2000) });
    if (!ping.ok) throw new Error();
  } catch(e) {
    showToast('warn', '🔴 Offline', 'Backend not running. Start uvicorn first.');
    return;
  }
  showLoader('Syncing from database...');
  await _loadLiveData();
  hideLoader();
  showToast('success', '🔄 Refreshed', 'All data synced from database.');
};

// ════════════════════════════════════════════════════════════
//  FORGOT PASSWORD
// ════════════════════════════════════════════════════════════
var _resetToken = '';

window.fpSendOTP = async function () {
  var email = document.getElementById('fp-email').value.trim();
  var errEl = document.getElementById('fp-email-error');

  try {
    var ping = await fetch(API + '/health', { signal: AbortSignal.timeout(2000) });
    if (ping.ok) {
      var data = await apiFetch('/auth/forgot-password', {
        method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email: email })
      });
      if (data.success) {
        fpResetEmail = email; errEl.style.display = 'none';
        _fpStep2(email);
        showToast('info','📨 OTP Sent','OTP: <strong style="font-size:16px;letter-spacing:3px;color:var(--accent)">' + data.otp + '</strong>', 15000);
        return;
      }
    }
  } catch(e) {}

  // Offline fallback
  var role = Object.keys(users).find(function(k){ return users[k].email === email; });
  if (!role) { errEl.style.display = 'block'; return; }
  errEl.style.display = 'none';
  fpResetEmail = email; fpResetRole = role;
  fpCurrentOTP = String(Math.floor(100000 + Math.random() * 900000));
  _fpStep2(email);
  showToast('info','📨 OTP (Demo)','OTP: <strong style="font-size:16px;letter-spacing:3px;color:var(--accent)">' + fpCurrentOTP + '</strong>', 15000);
};

function _fpStep2(email) {
  document.getElementById('fp-email-display').textContent = email;
  for (var i = 0; i < 6; i++) {
    var el = document.getElementById('otp'+i);
    if (el) { el.value = ''; el.classList.remove('filled'); }
  }
  var e = document.getElementById('fp-otp-error'); if (e) e.style.display = 'none';
  fpGoStep(2);
  setTimeout(function(){ var el = document.getElementById('otp0'); if(el) el.focus(); }, 100);
}

window.fpVerifyOTP = async function () {
  var otp = [0,1,2,3,4,5].map(function(i){ var el=document.getElementById('otp'+i); return el?el.value:''; }).join('');
  var errEl = document.getElementById('fp-otp-error');
  if (otp.length < 6) { if(errEl){errEl.style.display='block';errEl.textContent='⚠ Enter all 6 digits.';} return; }

  try {
    var ping = await fetch(API + '/health', { signal: AbortSignal.timeout(2000) });
    if (ping.ok) {
      var data = await apiFetch('/auth/verify-otp', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email: fpResetEmail, otp: otp }) });
      if (data.success) { _resetToken = data.reset_token; if(errEl)errEl.style.display='none'; _fpStep3(); return; }
    }
  } catch(e) {}

  if (typeof fpCurrentOTP !== 'undefined' && otp === fpCurrentOTP) {
    if(errEl) errEl.style.display='none'; _fpStep3();
  } else {
    if(errEl){errEl.style.display='block';errEl.textContent='⚠ Invalid OTP.';}
  }
};

function _fpStep3() {
  var np=document.getElementById('fp-newpass'); var cp=document.getElementById('fp-confirmpass'); var pe=document.getElementById('fp-pass-error');
  if(np)np.value=''; if(cp)cp.value=''; if(pe)pe.style.display='none';
  fpGoStep(3);
  setTimeout(function(){ var el=document.getElementById('fp-newpass'); if(el)el.focus(); },100);
}

window.fpResetPassword = async function () {
  var np = document.getElementById('fp-newpass').value;
  var cp = document.getElementById('fp-confirmpass').value;
  var errEl = document.getElementById('fp-pass-error');
  if (np.length < 6) { if(errEl){errEl.style.display='block';errEl.textContent='⚠ Min 6 chars.';} return; }
  if (np !== cp)     { if(errEl){errEl.style.display='block';errEl.textContent='⚠ Passwords do not match.';} return; }

  if (_resetToken) {
    await apiFetch('/auth/reset-password', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ reset_token: _resetToken, new_password: np }) });
  } else if (typeof fpResetRole !== 'undefined' && users[fpResetRole]) {
    users[fpResetRole].pass = np;
  }
  if(errEl) errEl.style.display='none';
  fpGoStep(4);
  showToast('success', '🔑 Password Updated', 'Login with your new password.');
};

// ════════════════════════════════════════════════════════════
//  ADD ITEM
// ════════════════════════════════════════════════════════════
window.addItem = async function () {
  var name       = document.getElementById('newName').value.trim();
  var item_id    = document.getElementById('newSku').value.trim() || 'MED-' + Date.now().toString().slice(-4);
  var category   = document.getElementById('newCat').value;
  var stock      = parseInt(document.getElementById('newStock').value)     || 0;
  var reorder_pt = parseInt(document.getElementById('newThreshold').value) || 50;
  var expiry     = document.getElementById('newExpiry').value   || null;
  var location   = document.getElementById('newLocation').value || 'Unassigned';

  if (!name) { showToast('warn', '⚠️', 'Please enter an item name.'); return; }

  var catMap = { drug:'drug', equipment:'device', supply:'supply', critical:'critical' };
  var status = stock===0?'critical':stock<reorder_pt?'warn':'ok';
  var newItem = { name:name, id:item_id, item_id:item_id, cat:catMap[category]||category, category:category, stock:stock, max:stock*2||200, max_stock:stock*2||200, location:location, expiry:expiry||'N/A', status:status, dailyUse:5, daily_use:5, reorderPt:reorder_pt, reorder_pt:reorder_pt };
  inventoryData.unshift(newItem);
  currentData = [...inventoryData];
  renderTable(currentData);
  closeModal();
  ['newName','newSku','newStock','newThreshold','newLocation','newSupplier'].forEach(function(id){ var el=document.getElementById(id); if(el)el.value=''; });
  showToast('success', '✅ Item Added', name + ' added to inventory.');

  if (_backendOnline) {
    apiFetch('/inventory', { method:'POST', body: JSON.stringify({ item_id:item_id, name:name, category:category, stock:stock, max_stock:stock*2||200, reorder_pt:reorder_pt, daily_use:5, location:location, expiry:expiry }) })
      .then(function(d){ if(d.success) showToast('info','💾 Saved','Item saved to database.'); });
  }
};

// ════════════════════════════════════════════════════════════
//  STOCK IN / OUT
// ════════════════════════════════════════════════════════════
window.confirmStockAction = async function () {
  if (!selectedStockItem) { showToast('warn','⚠️','Select an item first.'); return; }
  var qty    = parseInt(document.getElementById('stockQty').value) || 0;
  var reason = document.getElementById('stockNote').value || '';
  if (qty <= 0) { showToast('warn','⚠️','Enter a valid quantity.'); return; }
  if (stockAction==='out' && qty > selectedStockItem.stock) {
    showToast('danger','🚨 Insufficient','Only ' + selectedStockItem.stock + ' units available.'); return;
  }

  var item = inventoryData.find(function(i){
    return i.id===selectedStockItem.id || i.item_id===selectedStockItem.item_id ||
           i.id===selectedStockItem.item_id || i.item_id===selectedStockItem.id;
  });
  if (item) {
    item.stock  = stockAction==='in' ? item.stock+qty : Math.max(0,item.stock-qty);
    item.status = item.stock===0?'critical':item.stock<(item.reorderPt||item.reorder_pt||50)?'warn':'ok';
  }
  currentData = [...inventoryData];
  renderTable(inventoryData);
  try { renderAlerts(); } catch(e) {}
  closeStockModal();

  var verb = stockAction==='in'?'received':'dispensed';
  var icon = stockAction==='in'?'📥':'📤';
  showToast(stockAction==='in'?'success':'info', icon+' Stock '+(stockAction==='in'?'In':'Out'), selectedStockItem.name+': '+qty+' units '+verb+'.');

  if (_backendOnline) {
    apiFetch('/inventory/' + (selectedStockItem.item_id||selectedStockItem.id) + '/stock', {
      method:'POST', body: JSON.stringify({ action:stockAction==='in'?'stock_in':'stock_out', quantity:qty, reason:reason })
    });
  }
};

// ════════════════════════════════════════════════════════════
//  HELPERS
// ════════════════════════════════════════════════════════════
function _updateCards(stats) {
  var map = { statTotal:stats.total_items, totalItems:stats.total_items, statCritical:stats.critical_items, criticalItems:stats.critical_items, statExpiring:stats.expiring_items, expiringItems:stats.expiring_items, statPending:stats.pending_pos, pendingPOs:stats.pending_pos };
  Object.keys(map).forEach(function(id){ var el=document.getElementById(id); if(el&&map[id]!==undefined) el.textContent=map[id]; });
}

function _patchAlerts(apiAlerts) {
  if (!Array.isArray(apiAlerts)) return;
  alerts = apiAlerts.map(function(a){
    return { type:a.severity==='critical'?'danger':a.severity==='warning'?'warn':'info', icon:a.type==='low_stock'?'📦':a.type==='expiry'?'⏰':'ℹ️', title:a.message, time:_ago(a.created_at), id:a.id, read:!!a.resolved };
  });
}

function _ago(ts) {
  if (!ts) return 'just now';
  var d = Math.floor((Date.now() - new Date(ts)) / 1000);
  if (d < 60) return 'just now';
  if (d < 3600) return Math.floor(d/60)+'m ago';
  if (d < 86400) return Math.floor(d/3600)+'h ago';
  return Math.floor(d/86400)+'d ago';
}

function _setBadge(online) {
  _backendOnline = online;
  var b = document.getElementById('backendBadge');
  if (!b) {
    b = document.createElement('div');
    b.id = 'backendBadge';
    b.style.cssText = 'position:fixed;bottom:18px;right:18px;z-index:8888;padding:6px 14px;border-radius:20px;font-size:11px;font-weight:700;cursor:pointer;box-shadow:0 2px 12px rgba(0,0,0,0.4);transition:all 0.3s;';
    b.title = 'Click to sync from database';
    b.onclick = function(){ window.refreshFromDB(); };
    document.body.appendChild(b);
  }
  b.textContent      = online ? '🟢 Backend Online' : '🔴 Offline Mode';
  b.style.background = online ? '#064e3b' : '#1c1c1c';
  b.style.color      = online ? '#6ee7b7' : '#f87171';
  b.style.border     = 'lsolid ' + (online ? '#065f46' : '#7f1d1d');
}

// Init ping
(async function(){
  try {
    var r = await fetch(API + '/health', { signal: AbortSignal.timeout(2000) });
    _backendOnline = r.ok; _setBadge(r.ok);
  } catch(e) { _setBadge(false); }
})();

console.log('%c✅ MedAI Pro — Fixed (Field Mapping)', 'color:#00b4d8;font-weight:bold;font-size:13px');
