/* ================================================================
   MedAI Pro v9 — Application Logic
   Medical Inventory Intelligence System
   ================================================================ */

// ===== DATA =====
const users = {
  admin:      { name:'Dr. Admin', role:'System Administrator', initials:'DA', email:'admin@hospital.com', pass:'medai2024' },
  pharmacist: { name:'Mary Patel', role:'Senior Pharmacist', initials:'MP', email:'pharmacist@hospital.com', pass:'pharma123' },
  nurse:      { name:'Nurse Kumar', role:'Ward Nurse', initials:'NK', email:'nurse@hospital.com', pass:'nurse2024' },
  viewer:     { name:'Dr. Viewer', role:'Read-Only Access', initials:'DV', email:'viewer@hospital.com', pass:'view1234' },
};

let currentUser = null;
let selectedRole = 'admin';

const inventoryData = [
  { name:'Paracetamol 500mg', id:'MED-0042', cat:'drug', stock:48, max:500, location:'Pharmacy Main', expiry:'2025-08-15', status:'critical', dailyUse:15, reorderPt:100 },
  { name:'Saline 500ml IV', id:'MED-0187', cat:'critical', stock:112, max:800, location:'ICU Store', expiry:'2025-12-01', status:'warn', dailyUse:28, reorderPt:200 },
  { name:'Surgical Gloves (L)', id:'MED-0334', cat:'supply', stock:240, max:1000, location:'OT Store', expiry:'2027-01-01', status:'warn', dailyUse:16, reorderPt:300 },
  { name:'Insulin Syringes 1ml', id:'MED-0219', cat:'critical', stock:8, max:500, location:'Diabetic Ward', expiry:'2025-05-10', status:'critical', dailyUse:4, reorderPt:100 },
  { name:'Amoxicillin 250mg', id:'MED-0056', cat:'drug', stock:380, max:600, location:'Pharmacy B', expiry:'2025-11-20', status:'ok', dailyUse:12, reorderPt:80 },
  { name:'Bandage Roll 5cm', id:'MED-0471', cat:'supply', stock:654, max:800, location:'Dressing Room', expiry:'N/A', status:'ok', dailyUse:20, reorderPt:100 },
  { name:'BP Monitor Digital', id:'DEV-0012', cat:'device', stock:22, max:50, location:'Cardio Ward', expiry:'N/A', status:'ok', dailyUse:0, reorderPt:10 },
  { name:'Glucose Test Strips', id:'MED-0308', cat:'critical', stock:15, max:300, location:'Diabetic Ward', expiry:'2025-05-30', status:'critical', dailyUse:8, reorderPt:60 },
  { name:'Morphine 10mg/ml', id:'MED-0093', cat:'critical', stock:89, max:200, location:'Controlled Drugs', expiry:'2025-10-15', status:'ok', dailyUse:3, reorderPt:30 },
  { name:'Latex-free Gloves (M)', id:'MED-0335', cat:'supply', stock:78, max:500, location:'OT Store', expiry:'2026-06-01', status:'warn', dailyUse:25, reorderPt:150 },
];

const reorderItems = [
  { icon:'💊', name:'Paracetamol 500mg', meta:'Est. 3 days stock · 5,000 units needed', urgency:'URGENT', qty:5000, price:'₹2,500' },
  { icon:'💉', name:'Insulin Syringes 1ml', meta:'Est. 2 days stock · 2,000 units needed', urgency:'URGENT', qty:2000, price:'₹1,800' },
  { icon:'🧴', name:'Saline 500ml IV', meta:'Est. 4 days stock · 200 bags needed', urgency:'HIGH', qty:200, price:'₹6,000' },
  { icon:'🩸', name:'Glucose Test Strips', meta:'Expiring in 30d · 500 units needed', urgency:'HIGH', qty:500, price:'₹3,200' },
];

const alerts = [
  { type:'danger', icon:'🚨', title:'CRITICAL: Insulin Syringes 1ml — 8 units remaining', time:'2 min ago' },
  { type:'danger', icon:'⏰', title:'EXPIRY: Blood Glucose Strips expire in 15 days', time:'10 min ago' },
  { type:'warn', icon:'📉', title:'LOW STOCK: Saline 500ml — 112 units (threshold: 200)', time:'24 min ago' },
  { type:'warn', icon:'📦', title:'REORDER: Paracetamol 500mg auto-reorder triggered', time:'1 hr ago' },
  { type:'info', icon:'📥', title:'STOCK IN: Amoxicillin 250mg — 200 units received', time:'2 hr ago' },
  { type:'success', icon:'✅', title:'ORDER: Purchase Order PO-2024-0183 approved', time:'3 hr ago' },
  { type:'info', icon:'🤖', title:'AI: Seasonal demand spike predicted next 2 weeks', time:'4 hr ago' },
];

const chartData = [
  { day:'Mon', consumed:82, restocked:0, predicted:0 },
  { day:'Tue', consumed:67, restocked:150, predicted:0 },
  { day:'Wed', consumed:91, restocked:0, predicted:0 },
  { day:'Thu', consumed:55, restocked:0, predicted:0 },
  { day:'Fri', consumed:110, restocked:200, predicted:0 },
  { day:'Sat', consumed:44, restocked:100, predicted:0 },
  { day:'Sun', consumed:76, restocked:55, predicted:0 },
  { day:'Mon*', consumed:0, restocked:0, predicted:88 },
  { day:'Tue*', consumed:0, restocked:0, predicted:72 },
];

const aiResponses = [
  "Based on current usage trends, I recommend ordering Paracetamol 500mg within the next 24 hours to avoid a stockout.",
  "Your IV Fluid consumption is 34% above the weekly average. This could indicate higher patient admissions — pre-stock recommended.",
  "Blood Glucose Strips: only 8 units remain and expire May 10. Immediate reorder from BioMed Supplies is recommended.",
  "AI analysis shows Friday has the highest consumption day. Consider pre-stocking items every Thursday evening.",
  "3 items in the OT Store are expiring within 30 days. Would you like me to generate a disposal report?",
  "Based on seasonal patterns, antibiotic demand typically increases 25% next month. Pre-order is recommended.",
  "Running predictive model... Surgical Gloves (L) will hit reorder threshold in 5 days at current usage rate.",
  "I've detected an anomaly: Morphine usage is 40% below last month's average. Please verify dispensing logs.",
];

let currentData = [...inventoryData];
let msgCount = 0;
let selectedStockItem = null;
let stockAction = 'in';
let currentBarcode = null;

// ===== FORGOT PASSWORD =====
let fpCurrentOTP = '';
let fpResetEmail = '';
let fpResetRole = '';

function openForgotModal() {
  document.getElementById('forgotModal').classList.add('open');
  document.getElementById('fp-email').value = '';
  document.getElementById('fp-email-error').style.display = 'none';
  fpGoStep(1);
  setTimeout(() => document.getElementById('fp-email').focus(), 100);
}

function closeForgotModal() {
  document.getElementById('forgotModal').classList.remove('open');
  fpGoStep(1);
}

function fpGoStep(n) {
  document.querySelectorAll('.forgot-step').forEach(s => s.classList.remove('active'));
  document.getElementById('fp-step'+n).classList.add('active');
}

function fpSendOTP() {
  const email = document.getElementById('fp-email').value.trim();
  const errEl = document.getElementById('fp-email-error');
  const role = Object.keys(users).find(k => users[k].email === email);
  if (!role) { errEl.style.display = 'block'; return; }
  errEl.style.display = 'none';
  fpResetEmail = email;
  fpResetRole = role;
  fpCurrentOTP = String(Math.floor(100000 + Math.random() * 900000));
  document.getElementById('fp-email-display').textContent = email;
  for (let i = 0; i < 6; i++) {
    const el = document.getElementById('otp'+i);
    el.value = '';
    el.classList.remove('filled');
  }
  document.getElementById('fp-otp-error').style.display = 'none';
  fpGoStep(2);
  setTimeout(() => document.getElementById('otp0').focus(), 100);
  showToast('info', '📨 OTP Sent', `Demo OTP: <strong style="font-size:16px;letter-spacing:3px;color:var(--accent)">${fpCurrentOTP}</strong>`, 12000);
}

function fpOTPInput(idx) {
  const el = document.getElementById('otp'+idx);
  const val = el.value.replace(/\D/g,'');
  el.value = val;
  if (val) {
    el.classList.add('filled');
    if (idx < 5) document.getElementById('otp'+(idx+1)).focus();
  } else {
    el.classList.remove('filled');
  }
}

function fpOTPKey(idx, e) {
  if (e.key === 'Backspace' && !document.getElementById('otp'+idx).value && idx > 0) {
    document.getElementById('otp'+(idx-1)).focus();
  }
}

function fpGetOTPValue() {
  return [0,1,2,3,4,5].map(i => document.getElementById('otp'+i).value).join('');
}

function fpVerifyOTP() {
  const entered = fpGetOTPValue();
  const errEl = document.getElementById('fp-otp-error');
  if (entered.length < 6) { errEl.style.display = 'block'; errEl.textContent = '⚠ Please enter all 6 digits.'; return; }
  if (entered !== fpCurrentOTP) { errEl.style.display = 'block'; errEl.textContent = '⚠ Invalid OTP. Please try again.'; return; }
  errEl.style.display = 'none';
  document.getElementById('fp-newpass').value = '';
  document.getElementById('fp-confirmpass').value = '';
  document.getElementById('fp-pass-error').style.display = 'none';
  fpGoStep(3);
  setTimeout(() => document.getElementById('fp-newpass').focus(), 100);
}

function fpResendOTP() {
  fpCurrentOTP = String(Math.floor(100000 + Math.random() * 900000));
  for (let i = 0; i < 6; i++) {
    const el = document.getElementById('otp'+i);
    el.value = '';
    el.classList.remove('filled');
  }
  document.getElementById('fp-otp-error').style.display = 'none';
  document.getElementById('otp0').focus();
  showToast('info', '📨 OTP Resent', `New Demo OTP: <strong style="font-size:16px;letter-spacing:3px;color:var(--accent)">${fpCurrentOTP}</strong>`, 12000);
}

function fpResetPassword() {
  const np = document.getElementById('fp-newpass').value;
  const cp = document.getElementById('fp-confirmpass').value;
  const errEl = document.getElementById('fp-pass-error');
  if (np.length < 6) { errEl.style.display = 'block'; errEl.textContent = '⚠ Password must be at least 6 characters.'; return; }
  if (np !== cp) { errEl.style.display = 'block'; errEl.textContent = '⚠ Passwords do not match.'; return; }
  errEl.style.display = 'none';
  users[fpResetRole].pass = np;
  fpGoStep(4);
  showToast('success', '🔑 Password Updated', `Password for ${fpResetEmail} has been reset successfully.`);
}

// ===== LOGIN =====
function selectRole(el, role) {
  document.querySelectorAll('.role-tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  selectedRole = role;
  document.getElementById('loginEmail').value = '';
  document.getElementById('loginPass').value = '';
  clearFieldError('emailError', 'loginEmail');
  clearFieldError('passError', 'loginPass');
  document.getElementById('loginPass').type = 'password';
  document.getElementById('eyeIcon').style.display = 'block';
  document.getElementById('eyeOffIcon').style.display = 'none';
}

function quickLogin(role) {
  // Quick login disabled - manual entry required
}

function showFieldError(errorId, inputId, msg) {
  const errEl = document.getElementById(errorId);
  const inputEl = document.getElementById(inputId);
  if (errEl) { errEl.style.display = 'flex'; errEl.innerHTML = '⚠ ' + msg; }
  if (inputEl) { inputEl.classList.add('input-error'); }
}

function clearFieldError(errorId, inputId) {
  const errEl = document.getElementById(errorId);
  const inputEl = document.getElementById(inputId);
  if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }
  if (inputEl) { inputEl.classList.remove('input-error'); }
}

function togglePassVisibility() {
  const passInput = document.getElementById('loginPass');
  const eyeIcon = document.getElementById('eyeIcon');
  const eyeOffIcon = document.getElementById('eyeOffIcon');
  if (passInput.type === 'password') {
    passInput.type = 'text';
    eyeIcon.style.display = 'none';
    eyeOffIcon.style.display = 'block';
  } else {
    passInput.type = 'password';
    eyeIcon.style.display = 'block';
    eyeOffIcon.style.display = 'none';
  }
}

function doLogin() {
  const email = document.getElementById('loginEmail').value.trim();
  const pass = document.getElementById('loginPass').value;
  const errEl = document.getElementById('loginError');

  // Clear all previous errors
  if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }
  clearFieldError('emailError', 'loginEmail');
  clearFieldError('passError', 'loginPass');

  // Validation — per field
  if (!email && !pass) {
    showFieldError('emailError', 'loginEmail', 'Email address is required.');
    showFieldError('passError', 'loginPass', 'Password is required.');
    document.getElementById('loginEmail').focus(); return;
  }
  if (!email) {
    showFieldError('emailError', 'loginEmail', 'Email address is required.');
    document.getElementById('loginEmail').focus(); return;
  }
  if (!pass) {
    showFieldError('passError', 'loginPass', 'Password is required.');
    document.getElementById('loginPass').focus(); return;
  }

  const emailOnly = Object.values(users).find(u => u.email === email);
  const user = Object.values(users).find(u => u.email === email && u.pass === pass);
  if (!user) {
    if (emailOnly) {
      showFieldError('passError', 'loginPass', 'Incorrect password. Please try again.');
    } else {
      showFieldError('emailError', 'loginEmail', 'Email not found. Check your credentials.');
    }
    document.getElementById('loginPass').value = '';
    // Reset eye icon to hidden state
    document.getElementById('loginPass').type = 'password';
    document.getElementById('eyeIcon').style.display = 'block';
    document.getElementById('eyeOffIcon').style.display = 'none';
    document.getElementById('loginPass').focus();
    return;
  }
  currentUser = user;
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('appShell').style.display = 'block';
  document.getElementById('sidebarAvatar').textContent = user.initials;
  document.getElementById('sidebarName').textContent = user.name;
  document.getElementById('sidebarRole').textContent = user.role;
  document.getElementById('topbarAvatar').textContent = user.initials;
  document.getElementById('topbarAvatar').title = user.name;
  renderTable(currentData);
  renderAlerts();
  renderChart();
  renderReorder();
  setTimeout(() => { showToast('success', '✅ Logged In', `Welcome back, ${user.name.split(' ')[0]}! 7 alerts need attention.`); }, 600);
  setTimeout(() => { showToast('danger', '🚨 Critical Alert', 'Insulin Syringes 1ml: only 8 units remaining — reorder now!'); }, 2200);
  setTimeout(() => { showToast('warn', '⚠️ Low Stock', 'Paracetamol 500mg will run out in ~3 days based on AI forecast.'); }, 3800);
}

function doLogout() {
  document.getElementById('appShell').style.display = 'none';
  document.getElementById('loginScreen').style.display = 'flex';
  showToast('info', '👋 Logged Out', 'You have been securely logged out.');
}

// ===== TOAST =====
function showToast(type, title, msg, duration=5000) {
  const icons = { danger:'🚨', warn:'⚠️', success:'✅', info:'ℹ️' };
  const tc = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<div class="toast-icon">${icons[type]||'ℹ️'}</div>
    <div class="toast-content"><div class="toast-title">${title}</div><div class="toast-msg">${msg}</div></div>
    <div class="toast-close" onclick="this.parentElement.remove()">✕</div>`;
  tc.appendChild(toast);
  setTimeout(() => { toast.style.animation = 'toastOut 0.4s ease forwards'; setTimeout(() => toast.remove(), 400); }, duration);
}

// ===== RENDER TABLE =====
function renderTable(data) {
  const body = document.getElementById('inventoryBody');
  if (!data.length) {
    body.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:28px;color:var(--muted)">No items found</td></tr>`;
    return;
  }
  body.innerHTML = data.map(item => {
    const pct = Math.round((item.stock / item.max) * 100);
    const fillClass = item.status === 'critical' ? 'low' : item.status === 'warn' ? 'warn' : 'ok';
    const catLabel = { drug:'💊 Drug', device:'🔬 Device', supply:'🧤 Supply', critical:'🚨 Critical' }[item.cat];
    const catClass = { drug:'cat-drug', device:'cat-device', supply:'cat-supply', critical:'cat-critical' }[item.cat];
    const now = new Date();
    const exp = new Date(item.expiry);
    const daysLeft = item.expiry === 'N/A' ? 999 : Math.ceil((exp - now) / 86400000);
    const expiryClass = daysLeft < 30 ? 'urgent' : daysLeft < 90 ? 'soon' : 'ok';
    const expiryText = item.expiry === 'N/A' ? '—' : item.expiry;
    const statusDot = { critical:'critical', warn:'warn', ok:'ok' }[item.status];
    const statusLabel = { critical:'Critical', warn:'Low Stock', ok:'In Stock' }[item.status];
    const daysToOut = item.dailyUse > 0 ? Math.ceil(item.stock / item.dailyUse) : 999;
    const forecastColor = daysToOut < 5 ? 'var(--danger)' : daysToOut < 14 ? 'var(--warning)' : 'var(--success)';
    const forecastLabel = daysToOut >= 999 ? '—' : daysToOut < 5 ? `⚠️ ${daysToOut}d` : `${daysToOut}d`;
    const stockColor = fillClass === 'ok' ? 'var(--success)' : fillClass === 'warn' ? 'var(--warning)' : 'var(--danger)';
    return `<tr onclick="viewItem('${item.id}')">
      <td>
        <div class="item-name">${item.name}</div>
        <div class="item-id">${item.id}</div>
      </td>
      <td><span class="category-pill ${catClass}">${catLabel}</span></td>
      <td>
        <div class="stock-bar">
          <span class="stock-num" style="color:${stockColor}">${item.stock}</span>
          <div class="stock-progress"><div class="stock-fill ${fillClass}" style="width:${pct}%"></div></div>
          <span style="font-size:10px;color:var(--muted)">${pct}%</span>
        </div>
      </td>
      <td style="font-size:11px;color:var(--muted)">${item.location}</td>
      <td><span class="expiry-date ${expiryClass}">${expiryText}${daysLeft < 60 && item.expiry !== 'N/A' ? `<br><span style="font-size:10px">(${daysLeft}d left)</span>` : ''}</span></td>
      <td><span style="font-family:'Syne',sans-serif;font-size:12px;font-weight:700;color:${forecastColor}">${forecastLabel}</span></td>
      <td><span class="status-dot"><span class="dot ${statusDot}"></span>${statusLabel}</span></td>
    </tr>`;
  }).join('');
}

function renderAlerts() {
  const list = document.getElementById('alertList');
  list.innerHTML = alerts.map(a => `
    <div class="alert-item">
      <div class="alert-icon ${a.type}">${a.icon}</div>
      <div class="alert-text">
        <div class="alert-title">${a.title}</div>
        <div class="alert-time">${a.time}</div>
      </div>
    </div>
  `).join('');
}

function renderChart() {
  const area = document.getElementById('chartArea');
  const maxVal = Math.max(...chartData.map(d => Math.max(d.consumed, d.restocked, d.predicted)));
  area.innerHTML = chartData.map(d => {
    const cH = d.consumed ? Math.round((d.consumed / maxVal) * 110) : 0;
    const rH = d.restocked ? Math.round((d.restocked / maxVal) * 110) : 0;
    const pH = d.predicted ? Math.round((d.predicted / maxVal) * 110) : 0;
    return `<div class="bar-group">
      <div class="bar-wrap">
        ${rH ? `<div class="bar restocked" style="height:${rH}px" data-tip="${d.restocked} restocked"></div>` : ''}
        ${cH ? `<div class="bar consumed" style="height:${cH}px" data-tip="${d.consumed} consumed"></div>` : ''}
        ${pH ? `<div class="bar predicted" style="height:${pH}px" data-tip="AI: ${d.predicted} predicted"></div>` : ''}
      </div>
      <div class="bar-label">${d.day}</div>
    </div>`;
  }).join('');
}

function renderReorder() {
  const list = document.getElementById('reorderList');
  const colors = { URGENT:'var(--accent3)', HIGH:'var(--warning)', MED:'var(--accent)' };
  list.innerHTML = reorderItems.map((r, i) => `
    <div class="reorder-item">
      <div class="reorder-icon">${r.icon}</div>
      <div class="reorder-info">
        <div class="reorder-name">${r.name}</div>
        <div class="reorder-meta">${r.meta} · <span style="color:${colors[r.urgency]};font-weight:600">${r.urgency}</span> · ${r.price}</div>
      </div>
      <div class="reorder-action" onclick="approveOrder(${i}, event)">Order</div>
    </div>
  `).join('');
}

// ===== MODALS =====
function openModal() { document.getElementById('addModal').classList.add('open'); }
function closeModal() { document.getElementById('addModal').classList.remove('open'); }

function addItem() {
  const name = document.getElementById('newName').value.trim();
  const sku = document.getElementById('newSku').value.trim();
  const cat = document.getElementById('newCat').value;
  const stock = parseInt(document.getElementById('newStock').value) || 0;
  const threshold = parseInt(document.getElementById('newThreshold').value) || 50;
  const expiry = document.getElementById('newExpiry').value || 'N/A';
  const location = document.getElementById('newLocation').value || 'Unassigned';
  if (!name) { showToast('warn', '⚠️ Missing Field', 'Please enter an item name.'); return; }
  const status = stock === 0 ? 'critical' : stock < threshold ? 'warn' : 'ok';
  const newItem = { name, id: sku || 'MED-'+String(Math.random()).slice(2,6).toUpperCase(), cat, stock, max: stock*2||200, location, expiry, status, dailyUse:5, reorderPt:threshold };
  inventoryData.unshift(newItem);
  currentData = [...inventoryData];
  renderTable(currentData);
  closeModal();
  ['newName','newSku','newStock','newThreshold','newLocation','newSupplier'].forEach(id => document.getElementById(id).value = '');
  showToast('success', '✅ Item Added', `${name} has been added to inventory.`);
  if (status === 'critical') { showToast('danger', '🚨 Critical Stock', `${name} was added with zero/critical stock — reorder recommended.`); }
}

// ===== STOCK IN / OUT =====
function openStockModal(action) {
  stockAction = action || 'in';
  setStockTab(stockAction);
  document.getElementById('stockModal').classList.add('open');
}

function closeStockModal() {
  document.getElementById('stockModal').classList.remove('open');
  selectedStockItem = null;
  _aiSuggestedQty = 0;
  document.getElementById('stockItemName').value = '';
  document.getElementById('stockQty').value = '';
  document.getElementById('stockNote').value = '';
  document.getElementById('stockBatch').value = '';
  document.getElementById('stockCurrentInfo').style.display = 'none';
  document.getElementById('stockItemDropdown').style.display = 'none';
  const sb = document.getElementById('aiSuggestBtn');
  const sd = document.getElementById('aiQtySuggestion');
  if (sb) sb.style.display = 'none';
  if (sd) sd.style.display = 'none';
}

function setStockTab(action) {
  stockAction = action;
  document.getElementById('tabIn').classList.toggle('active', action === 'in');
  document.getElementById('tabOut').classList.toggle('active', action === 'out');
  document.getElementById('stockConfirmBtn').textContent = action === 'in' ? '✓ Confirm Stock In' : '✓ Confirm Stock Out';
  document.getElementById('stockConfirmBtn').className = 'btn ' + (action === 'in' ? 'btn-success' : 'btn-danger');
  if (selectedStockItem) showAISuggestedQty(selectedStockItem);
  updateStockPreview();
}

function filterStockItems(q) {
  const dd = document.getElementById('stockItemDropdown');
  if (!q) { dd.style.display = 'none'; return; }
  const matches = inventoryData.filter(i => i.name.toLowerCase().includes(q.toLowerCase()) || i.id.toLowerCase().includes(q.toLowerCase())).slice(0, 5);
  if (!matches.length) { dd.style.display = 'none'; return; }
  dd.style.display = 'block';
  dd.innerHTML = matches.map(i => `
    <div style="padding:10px 14px;cursor:pointer;border-bottom:1px solid var(--border);font-size:12px;transition:background 0.15s" onmouseover="this.style.background='rgba(0,212,255,0.05)'" onmouseout="this.style.background=''" onclick="selectStockItem('${i.id}')">
      <span style="font-weight:500">${i.name}</span>
      <span style="color:var(--muted);margin-left:8px">${i.id}</span>
      <span style="float:right;color:${i.status==='critical'?'var(--danger)':i.status==='warn'?'var(--warning)':'var(--success)'};font-weight:600">${i.stock} units</span>
    </div>`).join('');
}

function selectStockItem(id) {
  selectedStockItem = inventoryData.find(i => i.id === id);
  document.getElementById('stockItemSearch').value = selectedStockItem.name;
  document.getElementById('stockItemName').value = selectedStockItem.name;
  document.getElementById('stockItemDropdown').style.display = 'none';
  // Auto-calculate AI suggested quantity
  showAISuggestedQty(selectedStockItem);
  updateStockPreview();
}

let _aiSuggestedQty = 0;

function showAISuggestedQty(item) {
  const suggestBtn = document.getElementById('aiSuggestBtn');
  const suggestionDiv = document.getElementById('aiQtySuggestion');
  if (!item) { suggestBtn.style.display='none'; suggestionDiv.style.display='none'; return; }

  let suggestedQty = 0;
  let reason = '';

  if (stockAction === 'in') {
    // Stock In: suggest how much to restock to fill up to max
    const deficit = item.max - item.stock;
    const daysOfSupply = item.dailyUse > 0 ? Math.ceil(item.stock / item.dailyUse) : 999;
    if (item.status === 'critical' || daysOfSupply <= 3) {
      suggestedQty = item.max - item.stock; // full restock
      reason = `🚨 Critical! Only ${daysOfSupply <= 999 ? daysOfSupply + ' days' : 'enough'} left. Fill to max.`;
    } else if (item.status === 'warn' || daysOfSupply <= 7) {
      suggestedQty = Math.ceil((item.max - item.stock) * 0.75);
      reason = `⚠️ Low stock (${daysOfSupply} days left). 75% restock recommended.`;
    } else {
      suggestedQty = Math.max(item.reorderPt, Math.ceil(item.dailyUse * 30));
      reason = `✅ Stock OK. Routine 30-day top-up suggested.`;
    }
    suggestedQty = Math.max(1, suggestedQty);
  } else {
    // Stock Out: suggest typical daily usage amount
    suggestedQty = item.dailyUse > 0 ? item.dailyUse : 1;
    reason = `📊 Average daily usage: ${item.dailyUse} units.`;
  }

  _aiSuggestedQty = suggestedQty;
  suggestBtn.style.display = 'inline';
  suggestionDiv.style.display = 'block';
  suggestionDiv.innerHTML = `<span style="color:var(--accent);font-weight:700">🤖 AI Suggests: ${suggestedQty} units</span><br><span style="color:var(--muted)">${reason} Current: ${item.stock}/${item.max}</span>`;
}

function applyAISuggestedQty() {
  if (_aiSuggestedQty > 0) {
    document.getElementById('stockQty').value = _aiSuggestedQty;
    updateStockPreview();
    showToast('success', '🤖 AI Quantity Applied', `Suggested ${_aiSuggestedQty} units filled in.`);
  }
}

function updateStockPreview() {
  if (!selectedStockItem) return;
  const qty = parseInt(document.getElementById('stockQty').value) || 0;
  const after = stockAction === 'in' ? selectedStockItem.stock + qty : selectedStockItem.stock - qty;
  document.getElementById('stockCurrentQty').textContent = selectedStockItem.stock;
  document.getElementById('stockAfterQty').textContent = after;
  document.getElementById('stockCurrentInfo').style.display = 'block';
  const warn = document.getElementById('stockWarningMsg');
  warn.style.display = (stockAction === 'out' && after < selectedStockItem.reorderPt) ? 'inline' : 'none';
}

document.addEventListener('input', e => { if (e.target.id === 'stockQty') updateStockPreview(); });

function confirmStockAction() {
  if (!selectedStockItem) { showToast('warn', '⚠️', 'Please select an item first.'); return; }
  const qty = parseInt(document.getElementById('stockQty').value) || 0;
  if (qty <= 0) { showToast('warn', '⚠️', 'Please enter a valid quantity.'); return; }
  const item = inventoryData.find(i => i.id === selectedStockItem.id);
  if (stockAction === 'out' && qty > item.stock) { showToast('danger', '🚨 Insufficient Stock', `Only ${item.stock} units available.`); return; }
  const prev = item.stock;
  item.stock = stockAction === 'in' ? item.stock + qty : item.stock - qty;
  item.status = item.stock === 0 ? 'critical' : item.stock < item.reorderPt ? 'warn' : 'ok';
  const verb = stockAction === 'in' ? 'received' : 'dispensed';
  const icon = stockAction === 'in' ? '📥' : '📤';
  alerts.unshift({ type: stockAction === 'in' ? 'success' : 'info', icon, title: `${icon.toUpperCase()} STOCK ${stockAction.toUpperCase()}: ${item.name} — ${qty} units ${verb} (${prev} → ${item.stock})`, time: 'just now' });
  renderTable(inventoryData);
  renderAlerts();
  closeStockModal();
  showToast(stockAction === 'in' ? 'success' : 'info', `${icon} Stock ${stockAction === 'in' ? 'In' : 'Out'} Confirmed`, `${item.name}: ${qty} units ${verb}. New total: ${item.stock}.`);
  if (item.status === 'critical') { showToast('danger', '🚨 Critical Alert', `${item.name} is now critically low! Auto-reorder triggered.`); }
}

// ===== BARCODE =====
let barcodeAutoTimer = null;
let cameraStream = null;
let scanLoopActive = false;
let facingMode = 'environment';
let torchOn = false;
let nativeBarcodeDetector = null;
let zxingReader = null;

function barcodeAutoScan(val) {
  clearTimeout(barcodeAutoTimer);
  const inp = document.getElementById('barcodeInput');
  inp.style.borderColor = '';
  inp.style.boxShadow = '';
  document.getElementById('barcodeResult').classList.remove('show');
  if (!val || val.trim().length < 3) return;

  const exact = inventoryData.find(i => i.id.toLowerCase() === val.trim().toLowerCase());
  if (exact) {
    inp.style.borderColor = 'var(--accent2)';
    inp.style.boxShadow = '0 0 0 3px rgba(0,201,167,0.25)';
    const vf = document.getElementById('scannerViewfinder');
    vf.classList.add('active');
    setTimeout(() => {
      vf.classList.remove('active');
      inp.style.borderColor = '';
      inp.style.boxShadow = '';
      showBarcodeResult(exact);
    }, 500);
    return;
  }
  barcodeAutoTimer = setTimeout(() => {
    const item = inventoryData.find(i =>
      i.id.toLowerCase().includes(val.trim().toLowerCase()) ||
      i.name.toLowerCase().includes(val.trim().toLowerCase())
    );
    if (item) {
      inp.style.borderColor = 'var(--accent)';
      inp.style.boxShadow = '0 0 0 3px rgba(0,212,255,0.15)';
    }
  }, 300);
}

async function startCamera() {
  const vf = document.getElementById('scannerViewfinder');
  const ph = document.getElementById('scanPlaceholder');
  const sa = document.getElementById('scanActive');
  const video = document.getElementById('cameraFeed');
  const errDiv = document.getElementById('cameraError');
  const errMsg = document.getElementById('cameraErrorMsg');
  const controls = document.getElementById('cameraControls');
  const scanLine = document.getElementById('scanLine');

  ph.innerHTML = `<div style="font-size:28px;animation:pulse 1s infinite">⏳</div><div style="font-size:12px;color:var(--accent);font-weight:600">Starting camera...</div>`;

  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: facingMode }, width: { ideal: 1280 }, height: { ideal: 720 } }
    });
    video.srcObject = cameraStream;
    await video.play();

    video.style.display = 'block';
    ph.style.display = 'none';
    errDiv.style.display = 'none';
    sa.style.display = 'block';
    scanLine.style.display = 'block';
    controls.style.display = 'flex';
    vf.classList.add('camera-active');

    // Torch support
    try {
      const caps = cameraStream.getVideoTracks()[0].getCapabilities?.() || {};
      if (caps.torch) document.getElementById('torchBtn').style.display = 'inline-flex';
    } catch(e) {}

    // Try ZXing first (works on file:// and http://)
    if (typeof ZXing !== 'undefined') {
      try {
        zxingReader = new ZXing.BrowserMultiFormatReader();
        scanLoopActive = true;
        sa.innerHTML = `<div style="background:rgba(0,0,0,0.7);backdrop-filter:blur(4px);padding:8px 14px;border-radius:20px;display:inline-flex;align-items:center;gap:8px;font-size:12px;">
          <div style="width:8px;height:8px;background:var(--accent2);border-radius:50%;animation:pulse 1s infinite;"></div>
          <span style="color:var(--accent2);font-weight:600;">🔍 Auto-scanning for barcodes...</span>
        </div>`;
        zxingReader.decodeFromVideoElementContinuously(video, (result, err) => {
          if (!scanLoopActive) return;
          if (result) { _onBarcodeDetected(result.getText()); }
        });
        return;
      } catch(e) { zxingReader = null; }
    }

    // Try native BarcodeDetector (Chrome 88+ on https)
    if ('BarcodeDetector' in window) {
      try {
        const fmts = await BarcodeDetector.getSupportedFormats().catch(() => ['qr_code','ean_13','code_128','upc_a','upc_e','ean_8','code_39','data_matrix','pdf417','aztec','itf']);
        nativeBarcodeDetector = new BarcodeDetector({ formats: fmts });
        scanLoopActive = true;
        _nativeScanLoop();
        return;
      } catch(e) { nativeBarcodeDetector = null; }
    }

    // Final fallback: manual capture mode
    _showCaptureMode(sa);

  } catch(err) {
    ph.style.display = 'none';
    errDiv.style.display = 'flex';
    errMsg.textContent = err.name === 'NotAllowedError' ? '🚫 Camera permission denied — click the lock icon in the address bar to allow'
      : err.name === 'NotFoundError' ? '📷 No camera found on this device'
      : '⚠️ ' + (err.message || 'Camera unavailable');
  }
}

function _showCaptureMode(saEl) {
  saEl.innerHTML = `
    <div style="background:rgba(0,0,0,0.7);backdrop-filter:blur(4px);padding:8px 14px;border-radius:20px;display:inline-flex;align-items:center;gap:8px;font-size:12px;">
      <div style="width:8px;height:8px;background:var(--accent2);border-radius:50%;animation:pulse 1s infinite;"></div>
      <span style="color:var(--accent2);font-weight:600;">Camera live — 📸 Capture barcode to read</span>
    </div>`;
  const ctrl = document.getElementById('cameraControls');
  if (!document.getElementById('captureBtn')) {
    const btn = document.createElement('button');
    btn.id = 'captureBtn'; btn.className = 'btn btn-primary'; btn.style.fontSize = '11px';
    btn.textContent = '📸 Capture & Read'; btn.onclick = captureAndRead;
    ctrl.insertBefore(btn, ctrl.firstChild);
  }
}

function _nativeScanLoop() {
  const video = document.getElementById('cameraFeed');
  if (!scanLoopActive || !nativeBarcodeDetector) return;
  if (video.readyState < 2) { setTimeout(_nativeScanLoop, 100); return; }
  nativeBarcodeDetector.detect(video).then(results => {
    if (results.length > 0) {
      _onBarcodeDetected(results[0].rawValue);
      scanLoopActive = false;
      setTimeout(() => { scanLoopActive = true; _nativeScanLoop(); }, 2500);
    } else if (scanLoopActive) {
      setTimeout(_nativeScanLoop, 150);
    }
  }).catch(() => { if (scanLoopActive) setTimeout(_nativeScanLoop, 200); });
}

async function captureAndRead() {
  const video = document.getElementById('cameraFeed');
  const canvas = document.getElementById('cameraCanvas');
  canvas.width = video.videoWidth || 640;
  canvas.height = video.videoHeight || 480;
  canvas.getContext('2d').drawImage(video, 0, 0);

  // Try native detector on still frame
  if (nativeBarcodeDetector || 'BarcodeDetector' in window) {
    try {
      const det = nativeBarcodeDetector || new BarcodeDetector();
      const results = await det.detect(canvas);
      if (results.length > 0) { _onBarcodeDetected(results[0].rawValue); return; }
    } catch(e) {}
  }

  // Show captured frame + input overlay
  const vf = document.getElementById('scannerViewfinder');
  video.style.display = 'none';
  let prev = document.getElementById('capturePreview');
  if (!prev) { prev = document.createElement('img'); prev.id = 'capturePreview'; prev.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:12px;z-index:3;'; vf.appendChild(prev); }
  prev.src = canvas.toDataURL('image/jpeg', 0.85);

  let ov = document.getElementById('captureOverlay');
  if (!ov) {
    ov = document.createElement('div'); ov.id = 'captureOverlay';
    ov.style.cssText = 'position:absolute;bottom:0;left:0;right:0;background:rgba(0,0,0,0.85);backdrop-filter:blur(4px);padding:10px 14px;border-radius:0 0 12px 12px;z-index:10;display:flex;flex-direction:column;gap:8px;';
    ov.innerHTML = `<div style="font-size:11px;color:var(--accent2);font-weight:600;">📸 Captured — type the barcode number visible in the image:</div>
      <div style="display:flex;gap:6px;">
        <input id="captureInput" class="barcode-input" placeholder="e.g. 8901234567890 or MED-0042..." style="flex:1;font-size:13px;padding:7px 10px;" onkeydown="if(event.key==='Enter')confirmCapture()">
        <button class="btn btn-primary" onclick="confirmCapture()" style="font-size:11px;padding:6px 12px;">✓ Confirm</button>
        <button class="btn btn-ghost" onclick="dismissCapture()" style="font-size:11px;padding:6px 10px;">✕</button>
      </div>`;
    vf.appendChild(ov);
  }
  setTimeout(() => { const ci = document.getElementById('captureInput'); if (ci) ci.focus(); }, 100);
}

function confirmCapture() {
  const val = (document.getElementById('captureInput')?.value || '').trim();
  dismissCapture();
  if (val) { document.getElementById('barcodeInput').value = val; lookupBarcode(); }
}

function dismissCapture() {
  ['capturePreview','captureOverlay'].forEach(id => { const el = document.getElementById(id); if (el) el.remove(); });
  const video = document.getElementById('cameraFeed');
  if (cameraStream) video.style.display = 'block';
}

function _onBarcodeDetected(code) {
  if (!code) return;
  document.getElementById('barcodeInput').value = code;
  const vf = document.getElementById('scannerViewfinder');
  vf.style.borderColor = 'var(--accent2)'; vf.style.boxShadow = '0 0 0 4px rgba(0,201,167,0.25)';
  setTimeout(() => { vf.style.borderColor = ''; vf.style.boxShadow = ''; }, 800);
  const item = inventoryData.find(i => i.id.toLowerCase() === code.toLowerCase() || i.name.toLowerCase().includes(code.toLowerCase()));
  if (item) { showBarcodeResult(item); showToast('success', '✅ Barcode Scanned!', `Found: <strong>${item.name}</strong> — ${item.stock} units`); }
  else { showToast('warn', '🔍 Barcode Scanned', `Code: <strong>${code}</strong> — not in inventory`); }
}

function stopCamera() {
  scanLoopActive = false;
  nativeBarcodeDetector = null;
  if (zxingReader) { try { zxingReader.reset(); } catch(e) {} zxingReader = null; }
  if (cameraStream) { cameraStream.getTracks().forEach(t => t.stop()); cameraStream = null; }
  const video = document.getElementById('cameraFeed');
  video.style.display = 'none'; video.srcObject = null;
  ['capturePreview','captureOverlay','captureBtn'].forEach(id => { const el = document.getElementById(id); if (el) el.remove(); });
  const ph = document.getElementById('scanPlaceholder');
  ph.style.display = 'flex';
  ph.innerHTML = `<div style="font-size:36px">📷</div>
    <button class="btn btn-primary" onclick="startCamera()" style="font-size:12px;padding:8px 18px">📷 Start Camera Scan</button>
    <div style="font-size:11px;color:var(--muted);text-align:center;max-width:200px">Auto-detect QR & barcodes, or capture to read</div>`;
  document.getElementById('scanActive').innerHTML = '';
  document.getElementById('scanActive').style.display = 'none';
  document.getElementById('scanLine').style.display = 'none';
  document.getElementById('cameraControls').style.display = 'none';
  document.getElementById('scannerViewfinder').classList.remove('camera-active');
  document.getElementById('torchBtn').style.display = 'none';
  torchOn = false;
}

async function switchCamera() { facingMode = facingMode === 'environment' ? 'user' : 'environment'; stopCamera(); setTimeout(startCamera, 400); }

async function toggleTorch() {
  if (!cameraStream) return;
  torchOn = !torchOn;
  try {
    await cameraStream.getVideoTracks()[0].applyConstraints({ advanced: [{ torch: torchOn }] });
    const btn = document.getElementById('torchBtn');
    btn.textContent = torchOn ? '🔦 ON' : '🔦 Torch'; btn.style.color = torchOn ? 'var(--accent2)' : '';
  } catch(e) { showToast('warn','⚠️','Torch not supported'); torchOn = false; }
}

// ===== SCAN TAB SWITCHING =====
let currentScanTab = 'camera';
function switchScanTab(tab) {
  currentScanTab = tab;
  ['camera','physical','manual'].forEach(t => {
    document.getElementById('scanTab-'+t).style.display = t === tab ? 'block' : 'none';
    document.getElementById('stab-'+t).classList.toggle('active', t === tab);
  });
  document.getElementById('barcodeResult').classList.remove('show');
  if (tab !== 'camera') stopCamera();
  if (tab === 'physical') { setTimeout(() => { const el = document.getElementById('physicalScanInput'); if (el) el.focus(); }, 100); }
  if (tab === 'manual') renderQuickPick();
}

// ===== PHYSICAL SCANNER =====
let physicalScanBuffer = '';
let physicalScanTimer = null;
let physicalScanHistory = [];
let physicalActive = false;

function activatePhysicalScanner() {
  physicalActive = true;
  document.getElementById('physicalScannerInactive').style.display = 'none';
  document.getElementById('physicalScannerActive').style.display = 'block';
  setPhysicalStatus('active');
  setTimeout(() => {
    const inp = document.getElementById('physicalScanInput');
    if (inp) { inp.focus(); inp.value = ''; }
  }, 50);
}

function deactivatePhysicalScanner() {
  physicalActive = false;
  document.getElementById('physicalScannerInactive').style.display = 'block';
  document.getElementById('physicalScannerActive').style.display = 'none';
  setPhysicalStatus('standby');
}

function setPhysicalStatus(state) {
  const el = document.getElementById('physicalScannerStatus');
  if (!el) return;
  const states = {
    active:   { dot: 'var(--accent2)', text: '● Live', color: 'var(--accent2)' },
    scanning: { dot: 'var(--accent)',  text: '⚡ Scanning...', color: 'var(--accent)' },
    success:  { dot: 'var(--success)', text: '✅ Found!', color: 'var(--success)' },
    notfound: { dot: 'var(--warning)', text: '⚠ Not Found', color: 'var(--warning)' },
    standby:  { dot: 'var(--muted)',   text: 'Standby', color: 'var(--muted)' },
  };
  const s = states[state] || states.standby;
  el.innerHTML = `<div style="width:8px;height:8px;border-radius:50%;background:${s.dot};"></div>`;
  el.innerHTML += `<span style="color:${s.color}">${s.text}</span>`;
}

function onPhysicalInput(val) {
  // Physical scanners type rapidly — collect chars then process
  clearTimeout(physicalScanTimer);
  physicalScanBuffer = val;
  setPhysicalStatus('scanning');
  // Physical scanners typically send Enter after the code
  // If not, auto-process after 120ms silence (fast typing = scanner)
  physicalScanTimer = setTimeout(() => {
    if (physicalScanBuffer.trim().length >= 3) {
      processPhysicalScan(physicalScanBuffer.trim());
    }
  }, 120);
}

function onPhysicalKey(e) {
  if (e.key === 'Enter') {
    clearTimeout(physicalScanTimer);
    const val = document.getElementById('physicalScanInput').value.trim();
    if (val.length >= 2) processPhysicalScan(val);
    e.preventDefault();
  }
}

function onPhysicalBlur() {
  // Keep re-focusing if still active (so scanner input always works)
  if (physicalActive && currentScanTab === 'physical') {
    setTimeout(() => {
      const inp = document.getElementById('physicalScanInput');
      if (inp && physicalActive) inp.focus();
    }, 200);
  }
}

function processPhysicalScan(code) {
  const inp = document.getElementById('physicalScanInput');
  const item = inventoryData.find(i =>
    i.id.toLowerCase() === code.toLowerCase() ||
    i.name.toLowerCase().includes(code.toLowerCase())
  );

  // Flash input
  if (inp) {
    inp.style.borderColor = item ? 'var(--accent2)' : 'var(--warning)';
    inp.style.boxShadow = item ? '0 0 0 3px rgba(0,201,167,0.25)' : '0 0 0 3px rgba(255,170,0,0.2)';
    setTimeout(() => { inp.style.borderColor = 'var(--accent2)'; inp.style.boxShadow = '0 0 0 3px rgba(0,201,167,0.20)'; inp.value = ''; inp.focus(); }, 800);
  }

  // Update last scan time
  const now = new Date();
  const timeStr = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  document.getElementById('lastScanTime').textContent = timeStr;

  // Add to history
  physicalScanHistory.unshift({ code, item: item || null, time: timeStr });
  if (physicalScanHistory.length > 10) physicalScanHistory.pop();
  renderPhysicalHistory();

  if (item) {
    setPhysicalStatus('success');
    showBarcodeResult(item);
    showToast('success', '✅ Scanned!', `<strong>${item.name}</strong> — ${item.stock} units in stock`);
  } else {
    setPhysicalStatus('notfound');
    showToast('warn', '🔍 Not Found', `Code <strong>${code}</strong> not in inventory`);
  }

  physicalScanBuffer = '';
  setTimeout(() => setPhysicalStatus('active'), 2000);
}

function renderPhysicalHistory() {
  const el = document.getElementById('physicalScanHistory');
  if (!el) return;
  if (!physicalScanHistory.length) {
    el.innerHTML = '<div style="font-size:12px;color:var(--muted);text-align:center;padding:10px;">No scans yet</div>';
    return;
  }
  el.innerHTML = physicalScanHistory.map(h => {
    const statusColor = h.item ? 'var(--success)' : 'var(--warning)';
    const statusIcon = h.item ? '✅' : '⚠️';
    return `<div style="display:flex;align-items:center;gap:10px;padding:7px 10px;background:var(--surface);border:1px solid var(--border);border-radius:8px;">
      <span style="font-size:14px;">${statusIcon}</span>
      <div style="flex:1;min-width:0;">
        <div style="font-size:12px;font-weight:600;color:${statusColor};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${h.item ? h.item.name : h.code}</div>
        <div style="font-size:10px;color:var(--muted);font-family:'JetBrains Mono',monospace;">${h.item ? h.item.id : 'Not found'}</div>
      </div>
      <div style="font-size:10px;color:var(--muted);white-space:nowrap;">${h.time}</div>
      ${h.item ? `<button class="btn btn-ghost" style="font-size:10px;padding:3px 7px;" onclick="showBarcodeResult(physicalScanHistory.find(x=>x.code==='${h.code}').item)">View</button>` : ''}
    </div>`;
  }).join('');
}

// ===== QUICK PICK (Manual tab) =====
function renderQuickPick() {
  const el = document.getElementById('quickPickList');
  if (!el) return;
  const items = inventoryData.slice(0, 8);
  el.innerHTML = items.map(item => {
    const col = item.status === 'critical' ? 'var(--danger)' : item.status === 'warn' ? 'var(--warning)' : 'var(--success)';
    const icon = { drug:'💊', device:'🔬', supply:'🧤', critical:'🚨' }[item.cat];
    return `<div onclick="quickPickItem('${item.id}')" style="display:flex;align-items:center;gap:8px;padding:8px 10px;background:var(--surface);border:1px solid var(--border);border-radius:8px;cursor:pointer;transition:border-color 0.15s;" onmouseover="this.style.borderColor='var(--accent)'" onmouseout="this.style.borderColor='var(--border)'">
      <span style="font-size:16px;">${icon}</span>
      <div style="flex:1;min-width:0;">
        <div style="font-size:11px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${item.name}</div>
        <div style="font-size:10px;color:var(--muted);font-family:'JetBrains Mono',monospace;">${item.id}</div>
      </div>
      <span style="font-size:11px;font-weight:700;color:${col};">${item.stock}</span>
    </div>`;
  }).join('');
}

function quickPickItem(id) {
  const item = inventoryData.find(i => i.id === id);
  if (item) { showBarcodeResult(item); document.getElementById('barcodeInput').value = item.id; }
}

function openBarcodeScannerForBilling() {
  // Open barcode scanner in billing context — scanned item goes to bill
  window._billingBarcodeScanMode = true;
  openBarcodeScanner();
}

function openBarcodeScanner() {
  document.getElementById('barcodeModal').style.display = 'flex';
  document.getElementById('barcodeInput').value = '';
  document.getElementById('barcodeResult').classList.remove('show');
  // Switch to camera tab and auto-start camera
  switchScanTab('camera');
  setTimeout(() => startCamera(), 200);
}

function closeBarcodeScanner() {
  clearTimeout(barcodeAutoTimer);
  clearTimeout(physicalScanTimer);
  physicalActive = false;
  stopCamera();
  document.getElementById('barcodeModal').style.display = 'none';
  window._billingBarcodeScanMode = false;
}

function lookupBarcode() {
  const code = document.getElementById('barcodeInput').value.trim();
  if (!code) { showToast('warn', '⚠️', 'Please enter a barcode or SKU.'); return; }
  const item = inventoryData.find(i => i.id.toLowerCase() === code.toLowerCase() || i.name.toLowerCase().includes(code.toLowerCase()));
  if (!item) {
    showToast('warn', '🔍 Not Found', `No item found for "${code}".`);
    return;
  }
  showBarcodeResult(item);
}

function simulateScan() {
  const item = inventoryData[Math.floor(Math.random() * inventoryData.length)];
  document.getElementById('barcodeInput').value = item.id;
  const vf = document.getElementById('scannerViewfinder');
  const sp = document.getElementById('scanPlaceholder');
  const sa = document.getElementById('scanActive');
  vf.classList.add('active');
  sp.style.display = 'none';
  sa.style.display = 'block';
  setTimeout(() => {
    vf.classList.remove('active'); sp.style.display = 'flex'; sa.style.display = 'none';
    showBarcodeResult(item);
  }, 1800);
}

function showBarcodeResult(item) {
  currentBarcode = item;
  document.getElementById('br-name').textContent = item.name;
  document.getElementById('br-id').textContent = item.id;
  document.getElementById('br-stock').textContent = item.stock;
  document.getElementById('br-loc').textContent = item.location;
  document.getElementById('br-exp').textContent = item.expiry === 'N/A' ? '—' : item.expiry;
  const pill = document.getElementById('br-status-pill');
  const colors = { critical:'rgba(255,68,68,0.15)', warn:'rgba(255,170,0,0.15)', ok:'rgba(0,204,129,0.15)' };
  const textCol = { critical:'var(--danger)', warn:'var(--warning)', ok:'var(--success)' };
  const labels = { critical:'⚠️ Critical', warn:'Low Stock', ok:'In Stock' };
  pill.style.background = colors[item.status];
  pill.style.color = textCol[item.status];
  pill.textContent = labels[item.status];
  document.getElementById('barcodeResult').classList.add('show');

  // Scroll result into view so user can see it
  setTimeout(() => {
    const res = document.getElementById('barcodeResult');
    if (res) res.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, 100);

  // If opened from billing, show "Add to Bill" button and hide stock buttons
  const stockBtns = document.getElementById('br-stock-btns');
  const billBtn   = document.getElementById('br-bill-btn');
  if (window._billingBarcodeScanMode) {
    if (stockBtns) stockBtns.style.display = 'none';
    if (billBtn)   billBtn.style.display = 'block';
  } else {
    if (stockBtns) stockBtns.style.display = 'flex';
    if (billBtn)   billBtn.style.display = 'none';
  }
}


function barcodeAddToBill() {
  if (!currentBarcode) return;
  const itemToAdd = currentBarcode; // Save ref before closing scanner resets state
  window._billingBarcodeScanMode = false;
  closeBarcodeScanner();
  // Make sure billing page is open
  document.getElementById('billingPage').classList.add('open');
  setTimeout(() => {
    billAddItem(itemToAdd.id);
  }, 200);
}

function barcodeStockIn() {
  if (!currentBarcode) return;
  closeBarcodeScanner();
  stockAction = 'in';
  selectedStockItem = currentBarcode;
  document.getElementById('stockItemSearch').value = currentBarcode.name;
  document.getElementById('stockItemName').value = currentBarcode.name;
  setStockTab('in');
  document.getElementById('stockModal').classList.add('open');
  updateStockPreview();
}

function barcodeStockOut() {
  if (!currentBarcode) return;
  closeBarcodeScanner();
  stockAction = 'out';
  selectedStockItem = currentBarcode;
  document.getElementById('stockItemSearch').value = currentBarcode.name;
  document.getElementById('stockItemName').value = currentBarcode.name;
  setStockTab('out');
  document.getElementById('stockModal').classList.add('open');
  updateStockPreview();
}

// ===== SEARCH =====
function handleSearch(q) {
  const filtered = inventoryData.filter(i =>
    i.name.toLowerCase().includes(q.toLowerCase()) ||
    i.id.toLowerCase().includes(q.toLowerCase()) ||
    i.location.toLowerCase().includes(q.toLowerCase())
  );
  renderTable(filtered);
}

// ===== TABS =====
function setTab(el, type) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  if (type === 'all') renderTable(inventoryData);
  else if (type === 'low') renderTable(inventoryData.filter(i => i.status === 'warn'));
  else if (type === 'critical') renderTable(inventoryData.filter(i => i.status === 'critical'));
}

// ===== AI CHAT =====
function sendAIMessage() {
  const input = document.getElementById('aiInputField');
  const msg = input.value.trim();
  if (!msg) return;
  const chat = document.getElementById('aiChat');
  const userDiv = document.createElement('div');
  userDiv.className = 'msg user';
  userDiv.innerHTML = `<div class="msg-icon">👤</div><div class="msg-bubble">${msg}</div>`;
  chat.appendChild(userDiv);
  input.value = '';
  chat.scrollTop = chat.scrollHeight;
  setTimeout(() => {
    const aiDiv = document.createElement('div');
    aiDiv.className = 'msg ai';
    const response = aiResponses[msgCount % aiResponses.length];
    msgCount++;
    aiDiv.innerHTML = `<div class="msg-icon">🤖</div><div class="msg-bubble">${response}</div>`;
    chat.appendChild(aiDiv);
    chat.scrollTop = chat.scrollHeight;
  }, 900);
}

// ===== ACTIONS =====
function approveOrder(i, e) {
  e.stopPropagation();
  const items = document.querySelectorAll('.reorder-item');
  if (items[i]) {
    items[i].style.opacity = '0.4';
    const btn = items[i].querySelector('.reorder-action');
    btn.textContent = '✓ Ordered';
    btn.style.color = 'var(--success)';
    btn.style.borderColor = 'var(--success)';
  }
  showToast('success', '📦 Order Placed', `Purchase order for ${reorderItems[i].name} has been submitted.`);
}

function approveAll() {
  document.querySelectorAll('.reorder-action').forEach((btn, i) => {
    btn.textContent = '✓ Ordered';
    btn.style.color = 'var(--success)';
    btn.style.borderColor = 'var(--success)';
    btn.parentElement.style.opacity = '0.4';
  });
  showToast('success', '✅ All Orders Placed', `${reorderItems.length} purchase orders have been submitted automatically.`);
}

function autoOrderAll() {
  approveAll();
  showToast('success', '🤖 AI Auto-Order Executed', 'All 4 critical items have been automatically ordered based on AI recommendations.');
}

function markAllRead() {
  document.querySelectorAll('.alert-item').forEach(a => a.style.opacity = '0.4');
  document.getElementById('alertBadge').style.display = 'none';
  document.getElementById('notifBadge').style.display = 'none';
}

function toggleNotifPanel() {
  showToast('info', '🔔 Alerts', `You have ${alerts.length} active alerts. Check the Alerts panel on the right.`);
}

function exportData() {
  const csv = ['Item,ID,Category,Stock,Location,Expiry,Status,DailyUse,ForecastDays',
    ...inventoryData.map(i => {
      const daysToOut = i.dailyUse > 0 ? Math.ceil(i.stock / i.dailyUse) : 'N/A';
      return `"${i.name}",${i.id},${i.cat},${i.stock},"${i.location}",${i.expiry},${i.status},${i.dailyUse},${daysToOut}`;
    })
  ].join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], {type:'text/csv'}));
  a.download = 'medai_pro_inventory.csv';
  a.click();
  showToast('success', '📊 Export Ready', 'Inventory data with AI forecast exported to CSV.');
}

function viewItem(id) {
  const item = inventoryData.find(i => i.id === id);
  if (!item) return;
  const daysToOut = item.dailyUse > 0 ? Math.ceil(item.stock / item.dailyUse) : 'N/A';
  selectedStockItem = item;
  document.getElementById('stockItemName').value = item.name;
  document.getElementById('stockItemSearch').value = item.name;
  updateStockPreview();
  openStockModal('in');
}

function showAIForecast() {
  showToast('info', '🤖 AI Forecast Active', 'Forecast based on 30-day rolling average. Items marked with asterisk (*) in chart are projected.');
}

// Save dashboard HTML on first load so we can restore it when user navigates back
let _dashboardSnapshot = null;
document.addEventListener('DOMContentLoaded', () => {
  const mc = document.getElementById('mainContent');
  if (mc) _dashboardSnapshot = mc.innerHTML;
});

function closeAllOverlayPages() {
  // Close all overlay pages (classList-based)
  ['forecastPage','reorderPage','alertsPage','inventoryPage','poPage','suppliersPage','reportsPage','settingsPage'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('open');
  });
  // Close expiry page (display-based)
  const ep = document.getElementById('expiryPage');
  if (ep) ep.style.display = 'none';
  // NOTE: billingPage is NOT closed here — it has its own close button and persists across nav
}

function switchPage(el, page) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  el.classList.add('active');
  const titles = { dashboard:'Dashboard', inventory:'Inventory', alerts:'Alerts & Notifications', orders:'Purchase Orders', suppliers:'Suppliers', expiry:'Expiry Tracker', forecast:'AI Forecast', reorder:'Auto Reorder', reports:'Reports', settings:'Settings' };
  document.getElementById('pageTitle').textContent = titles[page] || page;

  // Always close all overlays first, then open the requested one
  closeAllOverlayPages();

  if (page === 'dashboard') {
    // Restore dashboard content
    const mc = document.getElementById('mainContent');
    if (mc && _dashboardSnapshot) {
      mc.innerHTML = _dashboardSnapshot;
      if (typeof renderTable === 'function') renderTable(inventoryData || []);
      if (typeof renderAlerts === 'function') renderAlerts();
      if (typeof renderChart === 'function') renderChart();
      if (typeof renderReorderList === 'function') renderReorderList();
    }
  } else if (page === 'expiry') { openExpiryTracker(); }
  else if (page === 'alerts') { openAlertsPage(); }
  else if (page === 'inventory') { openInventoryPage(); }
  else if (page === 'forecast') { openForecastPage(); }
  else if (page === 'reorder') { openReorderPage(); }
  else if (page === 'orders') { openPurchaseOrders(); }
  else if (page === 'suppliers') { openSuppliersPage(); }
  else if (page === 'reports') { openReportsPage(); }
  else if (page === 'settings') { openSettingsPage(); }
}

function filterByAll() { setTab(document.querySelectorAll('.tab')[0], 'all'); }
function filterByOk() { renderTable(inventoryData.filter(i => i.status === 'ok')); }
function filterByLow() { setTab(document.querySelectorAll('.tab')[1], 'low'); }
function filterByCritical() { setTab(document.querySelectorAll('.tab')[2], 'critical'); }

// Close modals on overlay click
document.getElementById('addModal').addEventListener('click', e => { if (e.target === document.getElementById('addModal')) closeModal(); });
document.getElementById('stockModal').addEventListener('click', e => { if (e.target === document.getElementById('stockModal')) closeStockModal(); });
document.getElementById('barcodeModal').addEventListener('click', e => { if (e.target === document.getElementById('barcodeModal')) closeBarcodeScanner(); });

// Keyboard shortcut: Ctrl+B for barcode
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'b' && currentUser) { e.preventDefault(); openBarcodeScanner(); }
  if (e.key === 'Escape') { closeModal(); closeStockModal(); closeBarcodeScanner(); closeReceipt(); }
});

// ===== BILLING SYSTEM =====
let billItems = [];
let billCounter = Math.floor(Math.random()*9000)+1000;
let selectedPayMethod = 'cash';

// Pricing map (unit price per item)
const itemPrices = {
  'MED-0042': 8.50,   // Paracetamol
  'MED-0187': 45.00,  // Saline 500ml
  'MED-0334': 12.00,  // Surgical Gloves
  'MED-0219': 18.00,  // Insulin Syringes
  'MED-0056': 22.00,  // Amoxicillin
  'MED-0471': 6.00,   // Bandage Roll
  'DEV-0012': 1200.00,// BP Monitor
  'MED-0308': 3.50,   // Glucose Strips
  'MED-0093': 85.00,  // Morphine
  'MED-0335': 14.00,  // Latex Gloves
};

function openBillingPage() {
  document.getElementById('billingPage').classList.add('open');
  document.getElementById('billDate').value = new Date().toISOString().split('T')[0];
  document.getElementById('billIdDisplay').textContent = 'Bill #BILL-' + (billCounter);
  setTimeout(() => document.getElementById('billPatientName').focus(), 100);
  setTimeout(() => _showBillQuickChips(), 300);
}

function closeBillingPage() {
  document.getElementById('billingPage').classList.remove('open');
}

function clearBill() {
  billItems = [];
  document.getElementById('billPatientName').value = '';
  document.getElementById('billPatientAge').value = '';
  document.getElementById('billDoctor').value = '';
  document.getElementById('billWard').value = '';
  document.getElementById('billPhone').value = '';
  document.getElementById('billScanInput').value = '';
  document.getElementById('billNotes').value = '';
  document.getElementById('discountVal').value = '';
  renderBillTable();
  recalcBill();
  showToast('info', '🗑 Bill Cleared', 'All items have been removed from the bill.');
}


// ── AI-Powered Billing Search ──────────────────────────────────────
function billAISearch(q) {
  const dd = document.getElementById('billSearchDropdown');
  const sugBox = document.getElementById('billAISuggestions');
  if (!q || q.length < 1) {
    dd.style.display = 'none';
    // Show top-selling / critical quick-add chips when empty
    _showBillQuickChips();
    return;
  }

  // Parse natural language: "add paracetamol 2" or "paracetamol x3"
  const qLower = q.toLowerCase().trim();
  const qtyMatch = qLower.match(/(\d+)\s*(?:qty|x|units?)?$/) || qLower.match(/(?:add|give|put)?\s*(\d+)\s+/);
  let parsedQty = null;
  let searchTerm = qLower
    .replace(/^(add|give|put|include)\s+/i, '')
    .replace(/\s+\d+\s*(qty|x|units?)?$/i, '')
    .replace(/\d+\s+(qty|x|units?)/i, '')
    .trim();
  if (qtyMatch) parsedQty = parseInt(qtyMatch[1]);

  const matches = inventoryData
    .filter(i => i.name.toLowerCase().includes(searchTerm) || i.id.toLowerCase().includes(searchTerm) || (i.cat && i.cat.toLowerCase().includes(searchTerm)))
    .slice(0, 6);

  if (!matches.length) {
    dd.style.display = 'none';
    if (sugBox) { sugBox.style.display = 'none'; }
    return;
  }

  dd.style.display = 'block';
  const stockColor = s => s === 'critical' ? 'var(--danger)' : s === 'warn' ? 'var(--warning)' : 'var(--success)';
  const price = id => itemPrices[id] || 10;

  dd.innerHTML = matches.map(item => `
    <div class="bill-search-item" onclick="billAIAddItem('${item.id}', ${parsedQty || 1})">
      <div style="display:flex;align-items:center;gap:10px;flex:1">
        <div>
          <div class="bill-search-item-name">${item.name}</div>
          <div class="bill-search-item-id">${item.id} · ${item.location}</div>
        </div>
      </div>
      <span class="bill-search-item-stock" style="color:${stockColor(item.status)};background:${stockColor(item.status).replace('var(','rgba(').replace(')',',0.12)')}">
        ${item.stock} left
      </span>
      <div class="bill-search-item-price">₹${price(item.id).toFixed(2)}${parsedQty ? ' · <b>×'+parsedQty+'</b>' : ''}</div>
    </div>`).join('');

  // Hide suggestions when dropdown shows
  if (sugBox) sugBox.style.display = 'none';
}

function billAIEnter(e) {
  // If one match, auto-add; else let dropdown handle
  const q = document.getElementById('billScanInput').value.trim();
  const qLower = q.toLowerCase();
  let searchTerm = qLower.replace(/^(add|give|put|include)\s+/i,'').replace(/\s+\d+.*$/,'').trim();
  const qtyMatch = qLower.match(/(\d+)\s*(?:qty|x|units?)?$/);
  const parsedQty = qtyMatch ? parseInt(qtyMatch[1]) : 1;
  const matches = inventoryData.filter(i =>
    i.name.toLowerCase().includes(searchTerm) || i.id.toLowerCase() === searchTerm
  );
  if (matches.length === 1) {
    billAIAddItem(matches[0].id, parsedQty);
  } else if (matches.length > 1) {
    // First result auto-add
    billAIAddItem(matches[0].id, parsedQty);
  }
}

function billAIAddItem(id, qty) {
  qty = Math.max(1, parseInt(qty) || 1);
  const item = inventoryData.find(i => i.id === id);
  if (!item) return;
  document.getElementById('billSearchDropdown').style.display = 'none';
  document.getElementById('billScanInput').value = '';
  const existing = billItems.find(b => b.id === id);
  if (existing) {
    const newQty = Math.min(existing.qty + qty, item.stock);
    existing.qty = newQty;
    showToast('info', '➕ Qty Updated', `${item.name} → ${newQty} units`);
  } else {
    const price = itemPrices[id] || 10.00;
    billItems.push({
      id, name: item.name, cat: item.cat, sku: item.id,
      expiry: item.expiry, stock: item.stock,
      qty: Math.min(qty, item.stock), price,
      batch: 'BATCH-' + String(Math.random()).slice(2,8).toUpperCase()
    });
    showToast('success', '🤖 AI Added', `${item.name} × ${qty} — ₹${(itemPrices[id]||10).toFixed(2)}/unit`);
  }
  renderBillTable();
  recalcBill();
  _showBillQuickChips();
}

function _showBillQuickChips() {
  const sugBox = document.getElementById('billAISuggestions');
  if (!sugBox) return;
  // Show top 5 available items as quick-add chips
  const top = inventoryData.filter(i => i.stock > 0).slice(0, 5);
  sugBox.style.display = top.length ? 'flex' : 'none';
  sugBox.innerHTML = top.map(i =>
    `<span onclick="billAIAddItem('${i.id}',1)" style="cursor:pointer;font-size:11px;padding:4px 10px;border-radius:20px;background:rgba(0,119,255,0.10);border:1px solid rgba(0,119,255,0.2);color:var(--accent);font-weight:500;transition:all 0.15s" onmouseover="this.style.background='rgba(0,119,255,0.2)'" onmouseout="this.style.background='rgba(0,119,255,0.10)'">+ ${i.name.split(' ').slice(0,2).join(' ')}</span>`
  ).join('');
}

function billSearchItems(q) {
  const dd = document.getElementById('billSearchDropdown');
  if (!q || q.length < 1) { dd.style.display = 'none'; return; }
  const matches = inventoryData.filter(i =>
    i.name.toLowerCase().includes(q.toLowerCase()) ||
    i.id.toLowerCase().includes(q.toLowerCase())
  ).slice(0, 8);
  if (!matches.length) { dd.style.display = 'none'; return; }
  dd.style.display = 'block';
  dd.innerHTML = matches.map(item => {
    const price = itemPrices[item.id] || 10.00;
    const stockColor = item.status === 'critical' ? 'var(--danger)' : item.status === 'warn' ? 'var(--warning)' : 'var(--success)';
    const stockBg = item.status === 'critical' ? 'rgba(255,68,68,0.12)' : item.status === 'warn' ? 'rgba(255,170,0,0.12)' : 'rgba(0,204,119,0.12)';
    return `<div class="bill-search-item" onclick="billAddItem('${item.id}')">
      <div style="width:30px;height:30px;background:var(--card);border:1px solid var(--border);border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:14px">
        ${ {drug:'💊',device:'🔬',supply:'🧤',critical:'🚨'}[item.cat] }
      </div>
      <div style="flex:1">
        <div class="bill-search-item-name">${item.name}</div>
        <div class="bill-search-item-id">${item.id} · ${item.location}</div>
      </div>
      <span class="bill-search-item-stock" style="color:${stockColor};background:${stockBg}">${item.stock} in stock</span>
      <div class="bill-search-item-price">₹${price.toFixed(2)}</div>
    </div>`;
  }).join('');
}

function billAddByBarcode() {
  const q = document.getElementById('billScanInput').value.trim();
  if (!q) return;
  const item = inventoryData.find(i => i.id.toLowerCase() === q.toLowerCase() || i.name.toLowerCase().includes(q.toLowerCase()));
  if (!item) { showToast('warn', '🔍 Not Found', `No item found for "${q}".`); return; }
  billAddItem(item.id);
}

function billAddItem(id) {
  const item = inventoryData.find(i => i.id === id);
  if (!item) return;
  document.getElementById('billSearchDropdown').style.display = 'none';
  document.getElementById('billScanInput').value = '';
  // If already exists, increment qty
  const existing = billItems.find(b => b.id === id);
  if (existing) {
    existing.qty = Math.min(existing.qty + 1, item.stock);
    showToast('info', '➕ Quantity Updated', `${item.name} qty increased to ${existing.qty}`);
  } else {
    const price = itemPrices[id] || 10.00;
    billItems.push({ id, name: item.name, cat: item.cat, sku: item.id, expiry: item.expiry, stock: item.stock, qty: 1, price, batch: 'BATCH-' + String(Math.random()).slice(2,8).toUpperCase() });
    showToast('success', '✅ Added to Bill', `${item.name} added — ₹${price.toFixed(2)} per unit`);
  }
  renderBillTable();
  recalcBill();
}

function billSimulateScan() {
  const item = inventoryData.filter(i => i.stock > 0)[Math.floor(Math.random() * 7)];
  document.getElementById('billScanInput').value = item.id;
  // animate
  const inp = document.getElementById('billScanInput');
  inp.style.borderColor = 'var(--accent2)';
  inp.style.boxShadow = '0 0 0 3px rgba(0,201,167,0.25)';
  setTimeout(() => { inp.style.borderColor = ''; inp.style.boxShadow = ''; }, 800);
  setTimeout(() => billAddItem(item.id), 300);
}

function billRemoveItem(idx) {
  const removed = billItems.splice(idx, 1)[0];
  showToast('info', '🗑 Removed', `${removed.name} removed from bill.`);
  renderBillTable();
  recalcBill();
}

function renderBillTable() {
  const empty = document.getElementById('billEmptyState');
  const table = document.getElementById('billTable');
  const tbody = document.getElementById('billTableBody');
  const count = document.getElementById('billItemCount');

  if (!billItems.length) {
    empty.style.display = 'block';
    table.style.display = 'none';
    count.textContent = '0 items added';
    return;
  }

  empty.style.display = 'none';
  table.style.display = 'table';
  count.textContent = `${billItems.length} item${billItems.length > 1 ? 's' : ''} added`;

  tbody.innerHTML = billItems.map((b, i) => `
    <tr>
      <td style="color:var(--muted);font-size:11px">${i+1}</td>
      <td>
        <div style="font-weight:500;font-size:13px">${b.name}</div>
        <div style="font-size:10px;color:var(--muted)">${b.cat}</div>
      </td>
      <td style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--muted)">${b.sku}</td>
      <td style="font-size:11px;color:var(--muted)">${b.batch}</td>
      <td style="font-size:11px;color:${b.expiry==='N/A'?'var(--muted)':new Date(b.expiry)<new Date(Date.now()+30*86400000)?'var(--danger)':'var(--muted)'}">${b.expiry==='N/A'?'—':b.expiry}</td>
      <td><input class="bill-qty-input" type="number" value="${b.qty}" min="1" max="${b.stock}" onchange="updateBillQty(${i},this.value)"></td>
      <td><input class="bill-price-input" type="number" value="${b.price.toFixed(2)}" step="0.01" min="0" onchange="updateBillPrice(${i},this.value)"></td>
      <td style="font-family:'Syne',sans-serif;font-weight:700;color:var(--accent4)">₹${(b.qty*b.price).toFixed(2)}</td>
      <td><button class="bill-remove" onclick="billRemoveItem(${i})">✕</button></td>
    </tr>`).join('');

  // Update quick total in header
  const subtotal = billItems.reduce((s, b) => s + b.qty * b.price, 0);
  document.getElementById('billItemsTotal').textContent = `Subtotal: ₹${subtotal.toFixed(2)}`;
}

function updateBillQty(idx, val) {
  billItems[idx].qty = Math.max(1, Math.min(parseInt(val)||1, billItems[idx].stock));
  renderBillTable();
  recalcBill();
}

function updateBillPrice(idx, val) {
  billItems[idx].price = Math.max(0, parseFloat(val)||0);
  renderBillTable();
  recalcBill();
}

function recalcBill() {
  const subtotal = billItems.reduce((s, b) => s + b.qty * b.price, 0);
  const gst = subtotal * 0.12;
  const discVal = parseFloat(document.getElementById('discountVal').value) || 0;
  const discType = document.getElementById('discountType').value;
  const discAmount = discType === 'pct' ? subtotal * (discVal / 100) : Math.min(discVal, subtotal);
  const total = Math.max(0, subtotal + gst - discAmount);

  document.getElementById('summarySubtotal').textContent = '₹' + subtotal.toFixed(2);
  document.getElementById('summaryGST').textContent = '₹' + gst.toFixed(2);
  document.getElementById('summaryDiscount').textContent = '-₹' + discAmount.toFixed(2);
  document.getElementById('summaryTotal').textContent = '₹' + total.toFixed(2);
}

function selectPayMethod(el, method) {
  document.querySelectorAll('.pay-method').forEach(m => m.classList.remove('selected'));
  el.classList.add('selected', method);
  selectedPayMethod = method;
}

function generateBill() {
  if (!billItems.length) { showToast('warn', '⚠️ Empty Bill', 'Please add at least one item to generate a bill.'); return; }

  const subtotal = billItems.reduce((s, b) => s + b.qty * b.price, 0);
  const gst = subtotal * 0.12;
  const discVal = parseFloat(document.getElementById('discountVal').value) || 0;
  const discType = document.getElementById('discountType').value;
  const discAmount = discType === 'pct' ? subtotal * (discVal / 100) : Math.min(discVal, subtotal);
  const total = Math.max(0, subtotal + gst - discAmount);

  const billNo = 'BILL-' + billCounter;
  billCounter++;

  // Populate receipt
  document.getElementById('r-billno').textContent = billNo;
  document.getElementById('r-date').textContent = document.getElementById('billDate').value || new Date().toLocaleDateString('en-IN');
  document.getElementById('r-patient').textContent = document.getElementById('billPatientName').value || 'Walk-in Patient';
  document.getElementById('r-age').textContent = document.getElementById('billPatientAge').value || '—';
  document.getElementById('r-doctor').textContent = document.getElementById('billDoctor').value || '—';
  document.getElementById('r-ward').textContent = document.getElementById('billWard').value || '—';
  document.getElementById('r-phone').textContent = document.getElementById('billPhone').value || '—';
  document.getElementById('r-payment').textContent = { cash:'💵 Cash', upi:'📱 UPI', card:'💳 Card', credit:'🏦 Credit' }[selectedPayMethod] || 'Cash';

  // Items
  document.getElementById('r-items').innerHTML = billItems.map((b, i) => `
    <tr>
      <td>${i+1}</td>
      <td><strong>${b.name}</strong></td>
      <td style="font-size:10px;color:#888">${b.batch}</td>
      <td style="font-size:10px">${b.expiry==='N/A'?'—':b.expiry}</td>
      <td>${b.qty}</td>
      <td>₹${b.price.toFixed(2)}</td>
      <td>₹${(b.qty*b.price).toFixed(2)}</td>
    </tr>`).join('');

  document.getElementById('r-subtotal').textContent = '₹' + subtotal.toFixed(2);
  document.getElementById('r-gst').textContent = '₹' + gst.toFixed(2);
  document.getElementById('r-discount').textContent = '-₹' + discAmount.toFixed(2);
  document.getElementById('r-total').textContent = '₹' + total.toFixed(2);

  // Amount in words
  document.getElementById('r-words').textContent = amountToWords(total) + ' Only';

  // Notes
  const notes = document.getElementById('billNotes').value;
  if (notes) {
    document.getElementById('r-notes-block').style.display = 'block';
    document.getElementById('r-notes').textContent = notes;
  } else {
    document.getElementById('r-notes-block').style.display = 'none';
  }

  // Barcode visual
  generateVisualBarcode(billNo);
  document.getElementById('r-barcode-num').textContent = billNo;

  // Stamp
  document.getElementById('r-stamp').textContent = selectedPayMethod === 'credit' ? 'CREDIT' : 'PAID';
  document.getElementById('r-stamp').style.borderColor = selectedPayMethod === 'credit' ? '#e55' : '#00b368';
  document.getElementById('r-stamp').style.color = selectedPayMethod === 'credit' ? '#e55' : '#00b368';

  document.getElementById('printReceipt').classList.add('open');
  showToast('success', '✅ Bill Generated', `${billNo} — Total: ₹${total.toFixed(2)}`);

  // Deduct stock
  billItems.forEach(b => {
    const inv = inventoryData.find(i => i.id === b.id);
    if (inv) {
      inv.stock = Math.max(0, inv.stock - b.qty);
      inv.status = inv.stock === 0 ? 'critical' : inv.stock < inv.reorderPt ? 'warn' : 'ok';
    }
  });
  renderTable(inventoryData);
}

function generateVisualBarcode(code) {
  const bars = document.getElementById('r-barcode-bars');
  bars.innerHTML = '';
  // Simple visual barcode using code chars
  const pattern = Array.from(code).flatMap(c => {
    const n = c.charCodeAt(0) % 7;
    return [n+1, 2, n+2, 1, 3, n+1, 2];
  });
  pattern.slice(0, 70).forEach(w => {
    const bar = document.createElement('div');
    bar.className = 'receipt-barcode-bar';
    bar.style.width = (w < 3 ? 1 : 2) + 'px';
    bar.style.height = (20 + (w * 3)) + 'px';
    bars.appendChild(bar);
  });
}

function amountToWords(amount) {
  const ones = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'];
  const tens = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
  const n = Math.floor(amount);
  if (n === 0) return 'Zero';
  if (n < 20) return ones[n];
  if (n < 100) return tens[Math.floor(n/10)] + (n%10 ? ' ' + ones[n%10] : '');
  if (n < 1000) return ones[Math.floor(n/100)] + ' Hundred' + (n%100 ? ' ' + amountToWords(n%100) : '');
  if (n < 100000) return amountToWords(Math.floor(n/1000)) + ' Thousand' + (n%1000 ? ' ' + amountToWords(n%1000) : '');
  return amountToWords(Math.floor(n/100000)) + ' Lakh' + (n%100000 ? ' ' + amountToWords(n%100000) : '');
}

function closeReceipt() { document.getElementById('printReceipt').classList.remove('open'); }

function downloadReceipt() {
  showToast('info', '📄 PDF Download', 'Use your browser\'s Print → Save as PDF option.');
  window.print();
}

function saveBillDraft() {
  showToast('success', '💾 Draft Saved', `Bill #BILL-${billCounter} saved as draft.`);
}

// ===== EXPIRY TRACKER =====
let expiryFilter = 'all';

function getExpiryInfo(expiry) {
  if (!expiry || expiry === 'N/A') return { days: null, status: 'na', label: 'No Expiry', color: 'var(--muted)' };
  const now = new Date(); now.setHours(0,0,0,0);
  const exp = new Date(expiry);
  const days = Math.ceil((exp - now) / 86400000);
  if (days < 0)  return { days, status: 'expired', label: 'EXPIRED',      color: '#ff2222', bg: 'rgba(255,34,34,0.12)' };
  if (days <= 30) return { days, status: 'soon',    label: `${days}d left`, color: 'var(--danger)', bg: 'rgba(255,68,68,0.1)' };
  if (days <= 90) return { days, status: 'warn',    label: `${days}d left`, color: 'var(--warning)', bg: 'rgba(255,170,0,0.1)' };
  return              { days, status: 'ok',      label: `${days}d left`, color: 'var(--success)', bg: 'rgba(0,204,119,0.08)' };
}

function openExpiryTracker() {
  document.getElementById('expiryPage').style.display = 'block';
  expiryFilter = 'all';
  renderExpirySummary();
  renderExpiryTable('');
  renderExpiryTimeline();
  renderExpiryDonut();
}

function closeExpiryTracker() {
  document.getElementById('expiryPage').style.display = 'none';
}

function filterExpiry(f, el) {
  expiryFilter = f;
  document.querySelectorAll('#expiryPage .tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  renderExpiryTable(document.getElementById('expirySearch').value || '');
  const disposalBtn = document.getElementById('disposalBtn');
  disposalBtn.style.display = (f === 'expired' || f === 'soon') ? 'inline-flex' : 'none';
}

function renderExpirySummary() {
  const now = new Date(); now.setHours(0,0,0,0);
  const withExpiry = inventoryData.filter(i => i.expiry && i.expiry !== 'N/A');
  const expired = withExpiry.filter(i => getExpiryInfo(i.expiry).status === 'expired').length;
  const soon    = withExpiry.filter(i => getExpiryInfo(i.expiry).status === 'soon').length;
  const warn    = withExpiry.filter(i => getExpiryInfo(i.expiry).status === 'warn').length;
  const ok      = withExpiry.filter(i => getExpiryInfo(i.expiry).status === 'ok').length;
  const na      = inventoryData.filter(i => !i.expiry || i.expiry === 'N/A').length;

  document.getElementById('expirySummaryCards').innerHTML = `
    <div class="stat-card red" style="cursor:pointer" onclick="filterExpiry('expired',document.getElementById('exTab-expired'))">
      <div class="stat-label">Expired</div>
      <div class="stat-value" style="font-size:26px">${expired}</div>
      <div class="stat-change down">⛔ Requires disposal</div>
      <div class="stat-icon">☠️</div>
    </div>
    <div class="stat-card red" style="cursor:pointer;opacity:0.85" onclick="filterExpiry('soon',document.getElementById('exTab-soon'))">
      <div class="stat-label">Expiring &lt; 30 Days</div>
      <div class="stat-value" style="font-size:26px">${soon}</div>
      <div class="stat-change down">🔴 Urgent action needed</div>
      <div class="stat-icon">⚡</div>
    </div>
    <div class="stat-card yellow" style="cursor:pointer" onclick="filterExpiry('warn',document.getElementById('exTab-warn'))">
      <div class="stat-label">Expiring 30–90 Days</div>
      <div class="stat-value" style="font-size:26px">${warn}</div>
      <div class="stat-change">🟡 Monitor closely</div>
      <div class="stat-icon">⏳</div>
    </div>
    <div class="stat-card green" style="cursor:pointer" onclick="filterExpiry('ok',document.getElementById('exTab-ok'))">
      <div class="stat-label">Safe (&gt; 90 Days)</div>
      <div class="stat-value" style="font-size:26px">${ok}</div>
      <div class="stat-change up">✅ No action needed</div>
      <div class="stat-icon">🛡️</div>
    </div>
    <div class="stat-card blue" style="cursor:pointer" onclick="filterExpiry('all',document.getElementById('exTab-all'))">
      <div class="stat-label">No Expiry / N/A</div>
      <div class="stat-value" style="font-size:26px">${na}</div>
      <div class="stat-change">Non-perishable items</div>
      <div class="stat-icon">♾️</div>
    </div>`;

  // Alert banner
  const banner = document.getElementById('expiryAlertBanner');
  if (expired > 0 || soon > 0) {
    banner.style.display = 'flex';
    document.getElementById('expiryBannerTitle').textContent = `${expired} Expired + ${soon} Expiring Within 30 Days!`;
    document.getElementById('expiryBannerDesc').textContent = `Immediate disposal and restocking required for ${expired + soon} item(s). Generate disposal report now.`;
  } else { banner.style.display = 'none'; }
}

function renderExpiryTable(search) {
  const tbody = document.getElementById('expiryTableBody');
  let items = inventoryData.filter(i => i.expiry && i.expiry !== 'N/A');

  if (expiryFilter !== 'all') {
    items = items.filter(i => getExpiryInfo(i.expiry).status === expiryFilter);
  }
  if (search) {
    const q = search.toLowerCase();
    items = items.filter(i => i.name.toLowerCase().includes(q) || i.id.toLowerCase().includes(q) || i.location.toLowerCase().includes(q));
  }

  // Sort by days left ascending
  items.sort((a, b) => {
    const da = getExpiryInfo(a.expiry).days ?? 9999;
    const db = getExpiryInfo(b.expiry).days ?? 9999;
    return da - db;
  });

  document.getElementById('expiryTableSubtitle').textContent = `${items.length} item${items.length !== 1 ? 's' : ''} · sorted by nearest expiry`;

  if (!items.length) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:32px;color:var(--muted)">No items found for this filter</td></tr>`;
    return;
  }

  tbody.innerHTML = items.map(item => {
    const ei = getExpiryInfo(item.expiry);
    const catIcon = { drug:'💊', device:'🔬', supply:'🧤', critical:'🚨' }[item.cat] || '📦';

    let statusBadge = '';
    if (ei.status === 'expired') statusBadge = `<span style="background:rgba(255,34,34,0.15);color:#ff2222;padding:3px 9px;border-radius:20px;font-size:10px;font-weight:700">⛔ EXPIRED</span>`;
    else if (ei.status === 'soon') statusBadge = `<span style="background:rgba(255,68,68,0.12);color:var(--danger);padding:3px 9px;border-radius:20px;font-size:10px;font-weight:700">🔴 CRITICAL</span>`;
    else if (ei.status === 'warn') statusBadge = `<span style="background:rgba(255,170,0,0.12);color:var(--warning);padding:3px 9px;border-radius:20px;font-size:10px;font-weight:600">🟡 WARNING</span>`;
    else statusBadge = `<span style="background:rgba(0,204,119,0.1);color:var(--success);padding:3px 9px;border-radius:20px;font-size:10px;font-weight:600">✅ SAFE</span>`;

    const daysText = ei.days === null ? '—' : ei.days < 0 ? `${Math.abs(ei.days)}d ago` : `${ei.days} days`;
    const daysColor = ei.days !== null && ei.days < 0 ? '#ff2222' : ei.color;

    const progressPct = ei.days === null ? 100 : Math.max(0, Math.min(100, (ei.days / 365) * 100));
    const progressColor = ei.status === 'expired' ? '#ff2222' : ei.status === 'soon' ? 'var(--danger)' : ei.status === 'warn' ? 'var(--warning)' : 'var(--success)';

    const actionBtn = ei.status === 'expired'
      ? `<button class="btn btn-danger" style="font-size:10px;padding:4px 10px" onclick="markForDisposal('${item.id}')">🗑 Dispose</button>`
      : ei.status === 'soon'
      ? `<button class="btn btn-primary" style="font-size:10px;padding:4px 10px" onclick="openStockModal('in');selectStockItem('${item.id}')">🔄 Reorder</button>`
      : `<button class="btn btn-ghost" style="font-size:10px;padding:4px 10px" onclick="openStockModal('in')">📥 Stock In</button>`;

    return `<tr style="background:${ei.status === 'expired' ? 'rgba(255,34,34,0.04)' : ei.status === 'soon' ? 'rgba(255,68,68,0.02)' : ''}">
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-size:16px">${catIcon}</span>
          <div>
            <div style="font-weight:500;font-size:13px">${item.name}</div>
            <div style="font-size:10px;color:var(--muted)">${item.location}</div>
          </div>
        </div>
      </td>
      <td style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--muted)">${item.id}</td>
      <td style="font-size:12px;color:var(--muted)">${item.location}</td>
      <td>
        <span style="font-family:'Syne',sans-serif;font-weight:700;color:${item.status==='critical'?'var(--danger)':item.status==='warn'?'var(--warning)':'var(--success)'}">${item.stock}</span>
        <span style="font-size:10px;color:var(--muted)"> units</span>
      </td>
      <td>
        <div style="font-size:13px;font-weight:600;color:${daysColor === 'var(--muted)' ? 'var(--text)' : daysColor}">${item.expiry}</div>
        <div style="margin-top:4px;height:3px;background:var(--border);border-radius:2px;width:80px;overflow:hidden">
          <div style="height:100%;width:${progressPct}%;background:${progressColor};border-radius:2px;transition:width 0.6s"></div>
        </div>
      </td>
      <td>
        <span style="font-family:'Syne',sans-serif;font-size:14px;font-weight:800;color:${daysColor}">${daysText}</span>
      </td>
      <td>${statusBadge}</td>
      <td>${actionBtn}</td>
    </tr>`;
  }).join('');
}

function renderExpiryTimeline() {
  const el = document.getElementById('expiryTimeline');
  const items = inventoryData
    .filter(i => i.expiry && i.expiry !== 'N/A')
    .map(i => ({ ...i, ei: getExpiryInfo(i.expiry) }))
    .filter(i => i.ei.days !== null && i.ei.days <= 180)
    .sort((a, b) => a.ei.days - b.ei.days)
    .slice(0, 8);

  if (!items.length) { el.innerHTML = `<div style="text-align:center;color:var(--muted);font-size:12px;padding:20px">No items expiring within 6 months</div>`; return; }

  el.innerHTML = items.map(item => {
    const { days, color, status, label } = item.ei;
    const icon = status === 'expired' ? '⛔' : status === 'soon' ? '🔴' : status === 'warn' ? '🟡' : '✅';
    const barW = status === 'expired' ? 100 : Math.max(4, Math.min(100, (days / 180) * 100));
    return `
      <div style="margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
          <div style="font-size:11px;font-weight:500;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${icon} ${item.name}</div>
          <div style="font-size:11px;color:${color};font-weight:700;font-family:'Syne',sans-serif;margin-left:8px;flex-shrink:0">${label}</div>
        </div>
        <div style="height:5px;background:var(--border);border-radius:3px;overflow:hidden">
          <div style="height:100%;width:${barW}%;background:${color};border-radius:3px;transition:width 0.8s ease"></div>
        </div>
        <div style="font-size:10px;color:var(--muted);margin-top:2px">${item.expiry} · ${item.location}</div>
      </div>`;
  }).join('');
}

function renderExpiryDonut() {
  const counts = { expired: 0, soon: 0, warn: 0, ok: 0 };
  inventoryData.filter(i => i.expiry && i.expiry !== 'N/A').forEach(i => {
    const s = getExpiryInfo(i.expiry).status;
    if (counts[s] !== undefined) counts[s]++;
  });
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  if (total === 0) return;

  const colors = { expired: '#ff2222', soon: 'var(--danger)', warn: 'var(--warning)', ok: 'var(--success)' };
  const labels = { expired: 'Expired', soon: '<30 days', warn: '30–90 days', ok: 'Safe' };

  const cx = 65, cy = 65, r = 50, strokeW = 16;
  const circumference = 2 * Math.PI * r;
  let offset = 0;
  let paths = '';

  Object.entries(counts).forEach(([key, val]) => {
    if (val === 0) return;
    const pct = val / total;
    const dash = pct * circumference;
    const gap = circumference - dash;
    // Convert offset to rotate from top
    const rotation = (offset / circumference) * 360 - 90;
    paths += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${colors[key]}" stroke-width="${strokeW}" stroke-dasharray="${dash} ${gap}" stroke-dashoffset="${-offset}" transform="rotate(-90 ${cx} ${cy})" style="transition:all 0.8s ease" />`;
    offset += dash;
  });

  document.getElementById('expiryDonut').innerHTML = `
    ${paths}
    <text x="${cx}" y="${cy-6}" text-anchor="middle" fill="var(--text)" font-family="Syne,sans-serif" font-size="18" font-weight="800">${total}</text>
    <text x="${cx}" y="${cy+10}" text-anchor="middle" fill="var(--muted)" font-family="DM Sans,sans-serif" font-size="10">items</text>`;

  document.getElementById('expiryDonutLegend').innerHTML = Object.entries(counts).map(([key, val]) => val > 0 ? `
    <div style="display:flex;align-items:center;justify-content:space-between;font-size:12px">
      <div style="display:flex;align-items:center;gap:8px">
        <div style="width:10px;height:10px;border-radius:2px;background:${colors[key]}"></div>
        <span style="color:var(--muted)">${labels[key]}</span>
      </div>
      <span style="font-family:'Syne',sans-serif;font-weight:700;color:${colors[key]}">${val}</span>
    </div>` : '').join('');
}

function markForDisposal(id) {
  const item = inventoryData.find(i => i.id === id);
  if (!item) return;
  showToast('warn', '🗑 Marked for Disposal', `${item.name} has been flagged for disposal. Generate disposal report to proceed.`);
}

function generateDisposalReport() {
  const expiredItems = inventoryData.filter(i => {
    if (!i.expiry || i.expiry === 'N/A') return false;
    const s = getExpiryInfo(i.expiry).status;
    return s === 'expired' || s === 'soon';
  });

  const now = new Date().toLocaleDateString('en-IN');
  const modal = document.getElementById('disposalModal');
  document.getElementById('disposalContent').innerHTML = `
    <div style="background:rgba(255,68,68,0.08);border:1px solid rgba(255,68,68,0.2);border-radius:10px;padding:14px 16px;margin-bottom:18px">
      <div style="font-family:'Syne',sans-serif;font-size:14px;font-weight:700;color:var(--danger)">⚠️ Pharmaceutical Disposal Report</div>
      <div style="font-size:11px;color:var(--muted);margin-top:3px">Generated: ${now} · MedAI Pro · Total items: ${expiredItems.length}</div>
    </div>
    <table style="width:100%;border-collapse:collapse;font-size:12px">
      <thead>
        <tr style="border-bottom:1px solid var(--border)">
          <th style="text-align:left;padding:7px 10px;color:var(--muted);font-size:10px;text-transform:uppercase">Item</th>
          <th style="text-align:left;padding:7px 10px;color:var(--muted);font-size:10px;text-transform:uppercase">SKU</th>
          <th style="text-align:left;padding:7px 10px;color:var(--muted);font-size:10px;text-transform:uppercase">Stock</th>
          <th style="text-align:left;padding:7px 10px;color:var(--muted);font-size:10px;text-transform:uppercase">Expiry</th>
          <th style="text-align:left;padding:7px 10px;color:var(--muted);font-size:10px;text-transform:uppercase">Status</th>
        </tr>
      </thead>
      <tbody>
        ${expiredItems.map(item => {
          const ei = getExpiryInfo(item.expiry);
          return `<tr style="border-bottom:1px solid var(--border)">
            <td style="padding:9px 10px;font-weight:500">${item.name}</td>
            <td style="padding:9px 10px;color:var(--muted);font-family:'JetBrains Mono',monospace;font-size:11px">${item.id}</td>
            <td style="padding:9px 10px;color:var(--danger);font-weight:700">${item.stock} units</td>
            <td style="padding:9px 10px">${item.expiry}</td>
            <td style="padding:9px 10px">
              <span style="background:${ei.status==='expired'?'rgba(255,34,34,0.15)':'rgba(255,68,68,0.1)'};color:${ei.status==='expired'?'#ff2222':'var(--danger)'};padding:2px 8px;border-radius:20px;font-size:10px;font-weight:700">
                ${ei.status === 'expired' ? '⛔ EXPIRED' : `⚡ ${ei.days}d left`}
              </span>
            </td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>
    <div style="margin-top:18px;padding:12px 14px;background:var(--card);border-radius:8px;font-size:11px;color:var(--muted);border:1px solid var(--border)">
      <strong style="color:var(--text)">Disposal Instructions:</strong> All expired pharmaceutical items must be disposed according to CPCB bio-medical waste guidelines. Segregate in yellow bag, contact licensed waste handler, and document in register. Obtain destruction certificate.
    </div>`;
  modal.style.display = 'flex';
}

function exportExpiryCSV() {
  const items = inventoryData.filter(i => i.expiry && i.expiry !== 'N/A');
  const csv = ['Item,SKU,Location,Stock,ExpiryDate,DaysLeft,ExpiryStatus',
    ...items.map(i => {
      const ei = getExpiryInfo(i.expiry);
      return `"${i.name}",${i.id},"${i.location}",${i.stock},${i.expiry},${ei.days ?? 'N/A'},${ei.status}`;
    })
  ].join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
  a.download = 'expiry_tracker_report.csv';
  a.click();
  showToast('success', '📊 Exported', 'Expiry tracker data exported to CSV.');
}

// Close disposal modal on outside click
document.getElementById('disposalModal').addEventListener('click', e => {
  if (e.target === document.getElementById('disposalModal')) document.getElementById('disposalModal').style.display = 'none';
});

// ===== AI FORECAST PAGE =====
const forecastData = [
  { name:'Paracetamol 500mg', id:'MED-0042', cat:'drug', stock:48, dailyUse:15, reorderPt:100, max:500, expiry:'2025-08-15', trend:'↑ High', risk:'critical', confidence:94, prediction7:105, prediction14:210, prediction30:450, insight:'Usage 28% above 30-day avg. Seasonal cold/flu surge detected. Reorder NOW.', action:'Order 5,000 units', supplier:'BioMed Supplies' },
  { name:'Insulin Syringes 1ml', id:'MED-0219', cat:'critical', stock:8, dailyUse:4, reorderPt:100, max:500, expiry:'2025-05-10', trend:'→ Stable', risk:'critical', confidence:97, prediction7:28, prediction14:56, prediction30:120, insight:'Critically low. Expires May 10. Dual risk: stockout + expiry. Emergency order required.', action:'Order 2,000 units', supplier:'MediCare Distributors' },
  { name:'Saline 500ml IV', id:'MED-0187', cat:'critical', stock:112, dailyUse:28, reorderPt:200, max:800, expiry:'2025-12-01', trend:'↑ Rising', risk:'warn', confidence:88, prediction7:196, prediction14:392, prediction30:840, insight:'IV Fluid usage 34% above average. Possible increased ICU admissions. Pre-stock recommended.', action:'Order 200 bags', supplier:'SterileSupply Co.' },
  { name:'Glucose Test Strips', id:'MED-0308', cat:'critical', stock:15, dailyUse:8, reorderPt:60, max:300, expiry:'2025-05-30', trend:'↑ High', risk:'critical', confidence:91, prediction7:56, prediction14:112, prediction30:240, insight:'Stock will last ~2 days. Expiry in 30 days compounds the risk. Urgent reorder.', action:'Order 500 units', supplier:'MediCare Distributors' },
  { name:'Surgical Gloves (L)', id:'MED-0334', cat:'supply', stock:240, dailyUse:16, reorderPt:300, max:1000, expiry:'2027-01-01', trend:'→ Stable', risk:'warn', confidence:82, prediction7:112, prediction14:224, prediction30:480, insight:'Below reorder point. OT schedule shows 3 major surgeries next week — pre-stock advised.', action:'Order 1,000 units', supplier:'SterileSupply Co.' },
  { name:'Amoxicillin 250mg', id:'MED-0056', cat:'drug', stock:380, dailyUse:12, reorderPt:80, max:600, expiry:'2025-11-20', trend:'↑ Rising', risk:'ok', confidence:78, prediction7:84, prediction14:168, prediction30:360, insight:'Seasonal antibiotic demand expected to rise 25% next month. Consider pre-ordering.', action:'Monitor — reorder in 10 days', supplier:'BioMed Supplies' },
  { name:'Latex-free Gloves (M)', id:'MED-0335', cat:'supply', stock:78, dailyUse:25, reorderPt:150, max:500, expiry:'2026-06-01', trend:'↑ Rising', risk:'warn', confidence:85, prediction7:175, prediction14:350, prediction30:750, insight:'High usage rate. At current pace, will hit zero in ~3 days. Reorder urgently.', action:'Order 500 units', supplier:'SterileSupply Co.' },
  { name:'Morphine 10mg/ml', id:'MED-0093', cat:'critical', stock:89, dailyUse:3, reorderPt:30, max:200, expiry:'2025-10-15', trend:'↓ Low', risk:'ok', confidence:72, prediction7:21, prediction14:42, prediction30:90, insight:'Usage 40% below last month. Verify dispensing logs. Stock level healthy.', action:'No action needed', supplier:'PharmaDirect India' },
];

const weeklyTrend = [
  { day:'Mon', usage:82, predicted:78 },
  { day:'Tue', usage:67, predicted:75 },
  { day:'Wed', usage:91, predicted:80 },
  { day:'Thu', usage:55, predicted:72 },
  { day:'Fri', usage:110, predicted:85 },
  { day:'Sat', usage:44, predicted:65 },
  { day:'Sun', usage:76, predicted:70 },
  { day:'Mon*', usage:null, predicted:88 },
  { day:'Tue*', usage:null, predicted:92 },
  { day:'Wed*', usage:null, predicted:86 },
];

function openForecastPage() {
  document.getElementById('forecastPage').classList.add('open');
  renderForecastCards();
  setTimeout(renderForecastTrendChart, 50);
}

function closeForecastPage() {
  document.getElementById('forecastPage').classList.remove('open');
}

function renderForecastCards() {
  const container = document.getElementById('forecastItemCards');
  container.innerHTML = forecastData.map(item => {
    const daysLeft = item.stock > 0 && item.dailyUse > 0 ? Math.ceil(item.stock / item.dailyUse) : 0;
    const riskBg = { critical:'rgba(255,68,68,0.08)', warn:'rgba(255,170,0,0.06)', ok:'rgba(0,204,119,0.05)' }[item.risk];
    const riskBorder = { critical:'rgba(255,68,68,0.3)', warn:'rgba(255,170,0,0.25)', ok:'rgba(0,204,119,0.2)' }[item.risk];
    const riskColor = { critical:'var(--danger)', warn:'var(--warning)', ok:'var(--success)' }[item.risk];
    const riskLabel = { critical:'🚨 Critical Risk', warn:'⚠️ Moderate Risk', ok:'✅ Low Risk' }[item.risk];
    const stockPct = Math.min(100, Math.round((item.stock / item.max) * 100));
    const stockFill = { critical:'var(--danger)', warn:'var(--warning)', ok:'var(--success)' }[item.risk];
    const trendColor = item.trend.startsWith('↑') ? 'var(--danger)' : item.trend.startsWith('↓') ? 'var(--accent)' : 'var(--muted)';
    return `
    <div style="background:var(--card);border:1px solid ${riskBorder};border-radius:14px;padding:18px;background:${riskBg}">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
        <div>
          <div style="font-weight:600;font-size:13px;margin-bottom:2px">${item.name}</div>
          <div style="font-size:10px;color:var(--muted);font-family:'JetBrains Mono',monospace">${item.id}</div>
        </div>
        <span style="background:${riskBg};color:${riskColor};padding:3px 9px;border-radius:20px;font-size:10px;font-weight:700;border:1px solid ${riskBorder}">${riskLabel}</span>
      </div>
      <!-- Stock bar -->
      <div style="margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:4px">
          <span style="color:var(--muted)">Current Stock</span>
          <span style="font-weight:700;color:${stockFill}">${item.stock} / ${item.max} units (${stockPct}%)</span>
        </div>
        <div style="height:6px;background:var(--border);border-radius:3px;overflow:hidden">
          <div style="height:100%;width:${stockPct}%;background:${stockFill};border-radius:3px;transition:width 0.8s ease"></div>
        </div>
      </div>
      <!-- Prediction Row -->
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:8px;margin-bottom:12px">
        <div style="background:var(--surface);border-radius:8px;padding:8px;text-align:center">
          <div style="font-size:9px;color:var(--muted);text-transform:uppercase;margin-bottom:3px">Days Left</div>
          <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:18px;color:${daysLeft < 5 ? 'var(--danger)' : daysLeft < 14 ? 'var(--warning)' : 'var(--success)'}">${daysLeft >= 999 ? '∞' : daysLeft}</div>
        </div>
        <div style="background:var(--surface);border-radius:8px;padding:8px;text-align:center">
          <div style="font-size:9px;color:var(--muted);text-transform:uppercase;margin-bottom:3px">7-Day Use</div>
          <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:18px;color:var(--accent)">${item.prediction7}</div>
        </div>
        <div style="background:var(--surface);border-radius:8px;padding:8px;text-align:center">
          <div style="font-size:9px;color:var(--muted);text-transform:uppercase;margin-bottom:3px">14-Day Use</div>
          <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:18px;color:var(--accent5)">${item.prediction14}</div>
        </div>
        <div style="background:var(--surface);border-radius:8px;padding:8px;text-align:center">
          <div style="font-size:9px;color:var(--muted);text-transform:uppercase;margin-bottom:3px">AI Confidence</div>
          <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:18px;color:var(--accent2)">${item.confidence}%</div>
        </div>
      </div>
      <!-- AI Insight -->
      <div style="background:rgba(0,212,255,0.05);border:1px solid rgba(0,212,255,0.15);border-radius:8px;padding:10px 12px;margin-bottom:10px">
        <div style="font-size:10px;color:var(--accent);font-weight:600;margin-bottom:3px">🤖 AI Insight</div>
        <div style="font-size:11px;color:var(--muted);line-height:1.5">${item.insight}</div>
      </div>
      <!-- Actions -->
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div style="font-size:11px;color:${trendColor};font-weight:600">${item.trend} · ${item.dailyUse}/day avg</div>
        ${item.risk !== 'ok' ? `<button class="btn btn-primary" style="font-size:10px;padding:5px 12px" onclick="forecastCreatePO('${item.id}')">📦 ${item.action}</button>` : `<span style="font-size:11px;color:var(--success)">✅ ${item.action}</span>`}
      </div>
    </div>`;
  }).join('');
}

function renderForecastTrendChart() {
  const canvas = document.getElementById('forecastTrendCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width = canvas.offsetWidth || 600;
  const H = canvas.height = 160;
  ctx.clearRect(0, 0, W, H);
  const maxVal = 140;
  const padL = 30, padR = 10, padT = 10, padB = 28;
  const chartW = W - padL - padR;
  const chartH = H - padT - padB;
  const xStep = chartW / (weeklyTrend.length - 1);
  // Grid lines
  ctx.strokeStyle = 'rgba(26,46,74,0.8)'; ctx.lineWidth = 1;
  [0,0.25,0.5,0.75,1].forEach(r => {
    const y = padT + chartH * (1 - r);
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
    ctx.fillStyle = 'rgba(90,122,154,0.7)'; ctx.font = '9px DM Sans'; ctx.textAlign = 'right';
    ctx.fillText(Math.round(maxVal * r), padL - 4, y + 3);
  });
  // Predicted line (dashed)
  ctx.setLineDash([4, 3]);
  ctx.strokeStyle = 'rgba(192,132,252,0.7)'; ctx.lineWidth = 2;
  ctx.beginPath();
  weeklyTrend.forEach((d, i) => {
    const x = padL + i * xStep;
    const y = padT + chartH * (1 - d.predicted / maxVal);
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.stroke();
  ctx.setLineDash([]);
  // Actual usage line
  const actualPoints = weeklyTrend.filter(d => d.usage !== null);
  ctx.strokeStyle = 'rgba(0,212,255,0.9)'; ctx.lineWidth = 2.5;
  ctx.beginPath();
  weeklyTrend.forEach((d, i) => {
    if (d.usage === null) return;
    const x = padL + i * xStep;
    const y = padT + chartH * (1 - d.usage / maxVal);
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.stroke();
  // Dots for actual
  weeklyTrend.forEach((d, i) => {
    if (d.usage === null) return;
    const x = padL + i * xStep;
    const y = padT + chartH * (1 - d.usage / maxVal);
    ctx.fillStyle = 'var(--bg)'; ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI*2); ctx.fill();
    ctx.strokeStyle = '#00d4ff'; ctx.lineWidth = 2; ctx.stroke();
  });
  // X Labels
  ctx.fillStyle = 'rgba(90,122,154,0.9)'; ctx.font = '9px DM Sans'; ctx.textAlign = 'center';
  weeklyTrend.forEach((d, i) => {
    ctx.fillStyle = d.day.includes('*') ? 'rgba(192,132,252,0.7)' : 'rgba(90,122,154,0.9)';
    ctx.fillText(d.day, padL + i * xStep, H - 6);
  });
}

function forecastCreatePO(itemId) {
  closeForecastPage();
  openPurchaseOrders();
  createNewPO();
  const item = forecastData.find(f => f.id === itemId);
  if (item) setTimeout(() => { document.getElementById('newPOSupplier').value = item.supplier; }, 150);
}

// ===== AUTO REORDER PAGE =====
let reorderQueue = [
  { id:'RO-001', itemId:'MED-0042', name:'Paracetamol 500mg', icon:'💊', supplier:'BioMed Supplies Pvt Ltd', currentStock:48, reorderPt:100, suggestedQty:5000, unitPrice:2.50, urgency:'URGENT', daysLeft:3, reason:'Stock critically low — AI predicts stockout in 3 days', status:'pending', autoApprove:true },
  { id:'RO-002', itemId:'MED-0219', name:'Insulin Syringes 1ml', icon:'💉', supplier:'MediCare Distributors', currentStock:8, reorderPt:100, suggestedQty:2000, unitPrice:4.50, urgency:'URGENT', daysLeft:2, reason:'Emergency — only 8 units. Expires May 10. Dual risk alert.', status:'pending', autoApprove:true },
  { id:'RO-003', itemId:'MED-0308', name:'Glucose Test Strips', icon:'🩸', supplier:'MediCare Distributors', currentStock:15, reorderPt:60, suggestedQty:500, unitPrice:32.00, urgency:'URGENT', daysLeft:2, reason:'2 days stock remaining and expiring in 30 days.', status:'pending', autoApprove:true },
  { id:'RO-004', itemId:'MED-0187', name:'Saline 500ml IV', icon:'🧴', supplier:'SterileSupply Co.', currentStock:112, reorderPt:200, suggestedQty:200, unitPrice:45.00, urgency:'HIGH', daysLeft:4, reason:'Below reorder threshold. Usage 34% above monthly average.', status:'pending', autoApprove:false },
  { id:'RO-005', itemId:'MED-0335', name:'Latex-free Gloves (M)', icon:'🧤', supplier:'SterileSupply Co.', currentStock:78, reorderPt:150, suggestedQty:500, unitPrice:14.00, urgency:'HIGH', daysLeft:3, reason:'High daily usage of 25/day will deplete stock in ~3 days.', status:'pending', autoApprove:false },
  { id:'RO-006', itemId:'MED-0334', name:'Surgical Gloves (L)', icon:'🧤', supplier:'SterileSupply Co.', currentStock:240, reorderPt:300, suggestedQty:1000, unitPrice:12.00, urgency:'MEDIUM', daysLeft:15, reason:'Below reorder point. OT schedule shows upcoming surgeries.', status:'pending', autoApprove:false },
];

function openReorderPage() {
  document.getElementById('reorderPage').classList.add('open');
  renderReorderQueue('all');
}

function closeReorderPage() {
  document.getElementById('reorderPage').classList.remove('open');
}

function renderReorderQueue(filter) {
  document.querySelectorAll('.ro-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.ro-tab').forEach(t => { if(t.dataset.filter===filter) t.classList.add('active'); });
  let items = reorderQueue;
  if (filter === 'pending') items = reorderQueue.filter(r => r.status === 'pending');
  else if (filter === 'approved') items = reorderQueue.filter(r => r.status === 'approved');
  else if (filter === 'URGENT') items = reorderQueue.filter(r => r.urgency === 'URGENT');
  const container = document.getElementById('reorderQueueList');
  const urgencyColors = { URGENT:'var(--danger)', HIGH:'var(--warning)', MEDIUM:'var(--accent)' };
  const urgencyBg = { URGENT:'rgba(255,68,68,0.08)', HIGH:'rgba(255,170,0,0.06)', MEDIUM:'rgba(0,212,255,0.05)' };
  const urgencyBorder = { URGENT:'rgba(255,68,68,0.25)', HIGH:'rgba(255,170,0,0.2)', MEDIUM:'rgba(0,212,255,0.15)' };
  // Totals
  const pending = reorderQueue.filter(r=>r.status==='pending').length;
  const approved = reorderQueue.filter(r=>r.status==='approved').length;
  const totalVal = reorderQueue.filter(r=>r.status==='pending').reduce((s,r)=>s+r.suggestedQty*r.unitPrice,0);
  document.getElementById('roStatPending').textContent = pending;
  document.getElementById('roStatApproved').textContent = approved;
  document.getElementById('roStatValue').textContent = '₹'+totalVal.toLocaleString('en-IN');
  container.innerHTML = items.length ? items.map(r => {
    const totalCost = (r.suggestedQty * r.unitPrice).toLocaleString('en-IN', {minimumFractionDigits:2});
    const isApproved = r.status === 'approved';
    return `
    <div id="ro-row-${r.id}" style="display:flex;gap:16px;padding:18px 22px;border-bottom:1px solid var(--border);background:${isApproved?'transparent':urgencyBg[r.urgency]};border-left:4px solid ${isApproved?'var(--success)':urgencyColors[r.urgency]};transition:all 0.2s">
      <div style="width:44px;height:44px;border-radius:10px;background:${isApproved?'rgba(0,204,119,0.1)':urgencyBg[r.urgency]};border:1px solid ${isApproved?'rgba(0,204,119,0.3)':urgencyBorder[r.urgency]};display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0">${r.icon}</div>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:5px;flex-wrap:wrap">
          <div style="font-weight:600;font-size:14px">${r.name}</div>
          <span style="background:${isApproved?'rgba(0,204,119,0.12)':urgencyBg[r.urgency]};color:${isApproved?'var(--success)':urgencyColors[r.urgency]};padding:2px 9px;border-radius:20px;font-size:10px;font-weight:700;border:1px solid ${isApproved?'rgba(0,204,119,0.3)':urgencyBorder[r.urgency]}">${isApproved?'✅ APPROVED':r.urgency}</span>
          ${r.autoApprove && !isApproved ? `<span style="background:rgba(192,132,252,0.1);color:var(--accent5);padding:2px 8px;border-radius:20px;font-size:10px;font-weight:600;border:1px solid rgba(192,132,252,0.2)">🤖 Auto-Approve</span>` : ''}
          <span style="margin-left:auto;font-size:11px;color:var(--muted)">⏱ ${r.daysLeft}d remaining · ${r.id}</span>
        </div>
        <div style="font-size:12px;color:var(--muted);margin-bottom:8px;line-height:1.4">📍 ${r.supplier} &nbsp;|&nbsp; Current: <strong style="color:var(--text)">${r.currentStock} units</strong> &nbsp;|&nbsp; Reorder Point: <strong style="color:var(--text)">${r.reorderPt}</strong></div>
        <div style="font-size:11px;background:rgba(0,212,255,0.04);border:1px solid rgba(0,212,255,0.12);border-radius:6px;padding:6px 10px;margin-bottom:10px;color:var(--muted)">🤖 <em>${r.reason}</em></div>
        <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
          <div style="display:flex;align-items:center;gap:6px">
            <span style="font-size:11px;color:var(--muted)">Suggested Qty:</span>
            <input type="number" value="${r.suggestedQty}" min="1" id="ro-qty-${r.id}" style="width:80px;background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:4px 8px;font-size:12px;color:var(--text);font-family:'Syne',sans-serif;font-weight:600;outline:none" onchange="updateROQty('${r.id}',this.value)">
          </div>
          <div style="font-size:12px;color:var(--muted)">Unit Price: <strong style="color:var(--accent4)">₹${r.unitPrice.toFixed(2)}</strong></div>
          <div style="font-size:13px;font-weight:700;font-family:'Syne',sans-serif;color:var(--accent4)" id="ro-total-${r.id}">Total: ₹${totalCost}</div>
          <div style="margin-left:auto;display:flex;gap:8px">
            ${!isApproved ? `
              <button class="btn btn-success" style="font-size:11px;padding:6px 14px" onclick="approveROItem('${r.id}')">✅ Approve & Order</button>
              <button class="btn btn-ghost" style="font-size:11px;padding:6px 10px" onclick="dismissROItem('${r.id}')">✕ Dismiss</button>
            ` : `<span style="font-size:12px;color:var(--success);font-weight:600">✅ Order Placed</span>`}
          </div>
        </div>
      </div>
    </div>`;
  }).join('') : `<div style="text-align:center;padding:60px;color:var(--muted)"><div style="font-size:40px;margin-bottom:12px">🎉</div><div>No items in this view</div></div>`;
}

function updateROQty(id, val) {
  const item = reorderQueue.find(r=>r.id===id);
  if (!item) return;
  item.suggestedQty = parseInt(val)||item.suggestedQty;
  const total = (item.suggestedQty * item.unitPrice).toLocaleString('en-IN',{minimumFractionDigits:2});
  const el = document.getElementById(`ro-total-${id}`);
  if (el) el.textContent = `Total: ₹${total}`;
}

function approveROItem(id) {
  const item = reorderQueue.find(r=>r.id===id);
  if (!item) return;
  item.status = 'approved';
  // Auto-create PO
  const poId = `PO-2024-0${poCounter++}`;
  const today = new Date().toISOString().split('T')[0];
  purchaseOrders.unshift({ id:poId, supplier:item.supplier, date:today, delivery:'TBD', status:'approved', items:[{name:item.name,qty:item.suggestedQty,unit:'Units',price:item.unitPrice}], total:item.suggestedQty*item.unitPrice, notes:`Auto-generated from Reorder Queue — ${item.reason}` });
  renderReorderQueue(document.querySelector('.ro-tab.active')?.dataset.filter||'all');
  showToast('success','✅ Order Approved',`${poId} created for ${item.name} — ${item.suggestedQty} units from ${item.supplier}.`);
}

function dismissROItem(id) {
  const idx = reorderQueue.findIndex(r=>r.id===id);
  if (idx>=0) reorderQueue.splice(idx,1);
  renderReorderQueue(document.querySelector('.ro-tab.active')?.dataset.filter||'all');
  showToast('info','✕ Dismissed',`Item removed from reorder queue.`);
}

function approveAllRO() {
  const pending = reorderQueue.filter(r=>r.status==='pending');
  pending.forEach(r => approveROItem(r.id));
  showToast('success','🚀 All Approved',`${pending.length} purchase orders created automatically.`);
}

// ===== ALERTS PAGE =====
const allAlerts = [
  { id:1, type:'danger', icon:'🚨', title:'CRITICAL: Insulin Syringes 1ml', desc:'Only 8 units remaining. Estimated stockout in 2 days based on current usage rate of 4 units/day.', time:'2 min ago', category:'Stock', read:false },
  { id:2, type:'danger', icon:'⏰', title:'EXPIRY: Blood Glucose Strips', desc:'15 units will expire on May 10, 2025. Immediate action required — mark for disposal or accelerate usage.', time:'10 min ago', category:'Expiry', read:false },
  { id:3, type:'warn', icon:'📉', title:'LOW STOCK: Saline 500ml IV', desc:'Current stock 112 units is below reorder threshold of 200 units. Recommend placing order for 200 bags from SterileSupply Co.', time:'24 min ago', category:'Stock', read:false },
  { id:4, type:'warn', icon:'📦', title:'REORDER: Paracetamol 500mg', desc:'AI auto-reorder triggered for 5,000 tablets. Purchase order PO-2024-0185 has been created and awaits approval.', time:'1 hr ago', category:'Reorder', read:false },
  { id:5, type:'warn', icon:'⏰', title:'EXPIRY WARNING: Insulin Syringes 1ml', desc:'Batch BATCH-2024-INS expires on May 10, 2025. 8 units affected.', time:'1 hr ago', category:'Expiry', read:false },
  { id:6, type:'info', icon:'📥', title:'STOCK IN: Amoxicillin 250mg', desc:'200 units received from BioMed Supplies Pvt Ltd. Stock updated from 180 to 380 units. Batch: BATCH-2024-AMX.', time:'2 hr ago', category:'Stock', read:true },
  { id:7, type:'success', icon:'✅', title:'ORDER APPROVED: PO-2024-0183', desc:'Purchase order for Paracetamol 500mg (5,000 units) and Amoxicillin 250mg (1,000 units) has been approved. Expected delivery: Mar 08.', time:'3 hr ago', category:'Orders', read:true },
  { id:8, type:'info', icon:'🤖', title:'AI PREDICTION: Seasonal demand spike', desc:'AI model predicts 25% increase in antibiotic demand over next 2 weeks based on seasonal patterns and regional health data.', time:'4 hr ago', category:'AI', read:true },
  { id:9, type:'warn', icon:'📉', title:'LOW STOCK: Latex-free Gloves (M)', desc:'Current stock 78 units approaching reorder threshold of 150. At current daily usage of 25/day, stockout in ~3 days.', time:'5 hr ago', category:'Stock', read:true },
  { id:10, type:'success', icon:'📥', title:'STOCK IN: Saline 500ml IV — Emergency Restock', desc:'50 emergency units received from MediCare Distributors. Ward ICU Store updated.', time:'6 hr ago', category:'Stock', read:true },
  { id:11, type:'info', icon:'🔬', title:'DEVICE CHECK: BP Monitor Digital', desc:'22 units in Cardio Ward are due for quarterly calibration check. Schedule maintenance before Apr 15.', time:'8 hr ago', category:'Device', read:true },
  { id:12, type:'danger', icon:'🚨', title:'CRITICAL: Glucose Test Strips', desc:'15 units left with expiry in 30 days. Both low stock AND imminent expiry — urgent dual-action required.', time:'Yesterday', category:'Stock', read:true },
];

let alertFilterCurrent = 'all';

function openAlertsPage() {
  document.getElementById('alertsPage').classList.add('open');
  // Update stat counters
  document.getElementById('alertStatCritical').textContent = allAlerts.filter(a=>a.type==='danger').length;
  document.getElementById('alertStatWarn').textContent = allAlerts.filter(a=>a.type==='warn').length;
  document.getElementById('alertStatTotal').textContent = allAlerts.length;
  document.getElementById('alertStatUnread').textContent = allAlerts.filter(a=>!a.read).length;
  renderAlertsPage('all');
}

function closeAlertsPage() {
  document.getElementById('alertsPage').classList.remove('open');
}

function renderAlertsPage(filter) {
  alertFilterCurrent = filter;
  document.querySelectorAll('.alert-page-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.alert-page-tab').forEach(t => { if(t.dataset.filter === filter) t.classList.add('active'); });
  let filtered = allAlerts;
  if (filter === 'unread') filtered = allAlerts.filter(a => !a.read);
  else if (filter === 'critical') filtered = allAlerts.filter(a => a.type === 'danger');
  else if (filter === 'warn') filtered = allAlerts.filter(a => a.type === 'warn');
  else if (filter !== 'all') filtered = allAlerts.filter(a => a.category === filter);
  const container = document.getElementById('alertsPageList');
  const typeColors = { danger:'rgba(255,68,68,0.08)', warn:'rgba(255,170,0,0.06)', success:'rgba(0,204,119,0.06)', info:'rgba(0,212,255,0.05)' };
  const typeBorder = { danger:'rgba(255,68,68,0.25)', warn:'rgba(255,170,0,0.2)', success:'rgba(0,204,119,0.2)', info:'rgba(0,212,255,0.15)' };
  const typeText = { danger:'var(--danger)', warn:'var(--warning)', success:'var(--success)', info:'var(--accent)' };
  container.innerHTML = filtered.length ? filtered.map(a => `
    <div id="alert-row-${a.id}" style="display:flex;gap:14px;padding:16px 20px;border-bottom:1px solid var(--border);background:${a.read?'transparent':typeColors[a.type]};transition:background 0.2s;cursor:pointer;border-left:3px solid ${a.read?'transparent':typeBorder[a.type]}" onclick="markAlertRead(${a.id})">
      <div style="width:40px;height:40px;border-radius:10px;background:${typeColors[a.type]};border:1px solid ${typeBorder[a.type]};display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0">${a.icon}</div>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
          <div style="font-size:13px;font-weight:${a.read?'400':'600'};color:${a.read?'var(--text)':'var(--text)'}">${a.title}</div>
          ${!a.read ? `<div style="width:7px;height:7px;border-radius:50%;background:${typeText[a.type]};flex-shrink:0"></div>` : ''}
          <span style="margin-left:auto;font-size:10px;color:var(--muted);white-space:nowrap">${a.time}</span>
        </div>
        <div style="font-size:12px;color:var(--muted);line-height:1.5">${a.desc}</div>
        <div style="margin-top:6px;display:flex;gap:6px;align-items:center">
          <span style="background:${typeColors[a.type]};color:${typeText[a.type]};padding:2px 8px;border-radius:20px;font-size:10px;font-weight:600;border:1px solid ${typeBorder[a.type]}">${a.category}</span>
          ${!a.read ? `<span style="font-size:10px;color:var(--muted)">Click to mark as read</span>` : `<span style="font-size:10px;color:var(--muted)">✓ Read</span>`}
        </div>
      </div>
    </div>`).join('') : `<div style="text-align:center;padding:60px;color:var(--muted)"><div style="font-size:40px;margin-bottom:12px">🔔</div><div>No alerts in this category</div></div>`;
  // Update unread count badge
  const unread = allAlerts.filter(a=>!a.read).length;
  document.getElementById('alertsPageBadge').textContent = unread > 0 ? `${unread} unread` : 'All read ✓';
  document.getElementById('alertsPageBadge').style.color = unread > 0 ? 'var(--danger)' : 'var(--success)';
  // Update stat cards
  if(document.getElementById('alertStatUnread')) {
    document.getElementById('alertStatCritical').textContent = allAlerts.filter(a=>a.type==='danger').length;
    document.getElementById('alertStatWarn').textContent = allAlerts.filter(a=>a.type==='warn').length;
    document.getElementById('alertStatTotal').textContent = allAlerts.length;
    document.getElementById('alertStatUnread').textContent = unread;
  }
}

function markAlertRead(id) {
  const a = allAlerts.find(x=>x.id===id);
  if(a) { a.read = true; renderAlertsPage(alertFilterCurrent); }
}

function markAllAlertsRead() {
  allAlerts.forEach(a => a.read = true);
  renderAlertsPage(alertFilterCurrent);
  showToast('success', '✅ All Read', 'All alerts marked as read.');
}

// ===== INVENTORY FULL PAGE =====
function openInventoryPage() {
  document.getElementById('inventoryPage').classList.add('open');
  // Update stat counters
  document.getElementById('invStatTotal').textContent = inventoryData.length;
  document.getElementById('invStatOk').textContent = inventoryData.filter(i=>i.status==='ok').length;
  document.getElementById('invStatWarn').textContent = inventoryData.filter(i=>i.status==='warn').length;
  document.getElementById('invStatCritical').textContent = inventoryData.filter(i=>i.status==='critical').length;
  renderInventoryFull(inventoryData, 'all');
}

function closeInventoryPage() {
  document.getElementById('inventoryPage').classList.remove('open');
}

function renderInventoryFull(data, filter) {
  document.querySelectorAll('.inv-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.inv-tab').forEach(t => { if(t.dataset.filter===filter) t.classList.add('active'); });
  const tbody = document.getElementById('invFullBody');
  if (!data.length) { tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:32px;color:var(--muted)">No items found</td></tr>`; return; }
  const catIcon = { drug:'💊', device:'🔬', supply:'🧤', critical:'🚨' };
  const catColors = { drug:'rgba(0,212,255,0.1)', device:'rgba(192,132,252,0.1)', supply:'rgba(255,209,102,0.1)', critical:'rgba(255,107,107,0.1)' };
  const catText = { drug:'var(--accent)', device:'var(--accent5)', supply:'var(--accent4)', critical:'var(--accent3)' };
  tbody.innerHTML = data.map(item => {
    const pct = Math.round((item.stock / item.max) * 100);
    const fillColor = item.status==='critical' ? 'var(--danger)' : item.status==='warn' ? 'var(--warning)' : 'var(--success)';
    const stockColor = item.status==='critical' ? 'var(--danger)' : item.status==='warn' ? 'var(--warning)' : 'var(--success)';
    const daysToOut = item.dailyUse > 0 ? Math.ceil(item.stock / item.dailyUse) : 999;
    const forecastColor = daysToOut < 5 ? 'var(--danger)' : daysToOut < 14 ? 'var(--warning)' : 'var(--success)';
    const forecastLabel = daysToOut >= 999 ? '—' : daysToOut < 5 ? `⚠️ ${daysToOut}d` : `${daysToOut}d`;
    const now = new Date(); const exp = new Date(item.expiry);
    const daysLeft = item.expiry==='N/A' ? 999 : Math.ceil((exp-now)/86400000);
    const expiryColor = daysLeft < 30 ? 'var(--danger)' : daysLeft < 90 ? 'var(--warning)' : 'var(--muted)';
    const statusBg = { critical:'rgba(255,68,68,0.12)', warn:'rgba(255,170,0,0.12)', ok:'rgba(0,204,119,0.1)' }[item.status];
    const statusTxt = { critical:'var(--danger)', warn:'var(--warning)', ok:'var(--success)' }[item.status];
    const statusLbl = { critical:'🚨 Critical', warn:'⚠️ Low Stock', ok:'✅ In Stock' }[item.status];
    return `<tr style="cursor:pointer" onclick="invViewItem('${item.id}')">
      <td>
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:34px;height:34px;border-radius:8px;background:${catColors[item.cat]};display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0">${catIcon[item.cat]}</div>
          <div><div style="font-weight:600;font-size:13px">${item.name}</div><div style="font-size:10px;color:var(--muted);font-family:'JetBrains Mono',monospace">${item.id}</div></div>
        </div>
      </td>
      <td><span style="background:${catColors[item.cat]};color:${catText[item.cat]};padding:3px 9px;border-radius:20px;font-size:11px;font-weight:600">${catIcon[item.cat]} ${item.cat.charAt(0).toUpperCase()+item.cat.slice(1)}</span></td>
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-family:'Syne',sans-serif;font-weight:700;color:${stockColor};font-size:15px">${item.stock}</span>
          <div style="flex:1;min-width:60px">
            <div style="height:4px;background:var(--border);border-radius:2px;overflow:hidden"><div style="height:100%;width:${pct}%;background:${fillColor};border-radius:2px"></div></div>
            <div style="font-size:9px;color:var(--muted);margin-top:2px">${pct}% of ${item.max}</div>
          </div>
        </div>
      </td>
      <td style="font-size:12px;color:var(--muted)">${item.location}</td>
      <td style="font-size:12px;color:${expiryColor}">${item.expiry==='N/A'?'—':item.expiry}${daysLeft<60&&item.expiry!=='N/A'?`<div style="font-size:10px">(${daysLeft}d left)</div>`:''}</td>
      <td><span style="font-family:'Syne',sans-serif;font-size:13px;font-weight:700;color:${forecastColor}">${forecastLabel}</span></td>
      <td style="font-size:11px;color:var(--muted)">${item.dailyUse}/day</td>
      <td>
        <span style="background:${statusBg};color:${statusTxt};padding:3px 9px;border-radius:20px;font-size:11px;font-weight:600">${statusLbl}</span>
      </td>
    </tr>`;
  }).join('');
}

function filterInvFull(filter) {
  let data;
  if (filter === 'all') data = inventoryData;
  else if (filter === 'critical') data = inventoryData.filter(i=>i.status==='critical');
  else if (filter === 'warn') data = inventoryData.filter(i=>i.status==='warn');
  else if (filter === 'ok') data = inventoryData.filter(i=>i.status==='ok');
  else data = inventoryData.filter(i=>i.cat===filter);
  renderInventoryFull(data, filter);
}

function searchInvFull(q) {
  const data = inventoryData.filter(i =>
    i.name.toLowerCase().includes(q.toLowerCase()) ||
    i.id.toLowerCase().includes(q.toLowerCase()) ||
    i.location.toLowerCase().includes(q.toLowerCase())
  );
  renderInventoryFull(data, alertFilterCurrent);
}

function invViewItem(id) {
  const item = inventoryData.find(i=>i.id===id);
  if (!item) return;
  selectedStockItem = item;
  document.getElementById('stockItemSearch').value = item.name;
  document.getElementById('stockItemName').value = item.name;
  updateStockPreview();
  openStockModal('in');
}

function exportInvFull() {
  exportData();
}

// ===== PURCHASE ORDERS =====
let purchaseOrders = [
  { id:'PO-2024-0183', supplier:'BioMed Supplies Pvt Ltd', date:'2024-03-01', delivery:'2024-03-08', status:'approved', items:[{name:'Paracetamol 500mg',qty:5000,unit:'Tablets',price:2.50},{name:'Amoxicillin 250mg',qty:1000,unit:'Capsules',price:8.00}], total:17500, notes:'Urgent restock — priority delivery requested' },
  { id:'PO-2024-0184', supplier:'MediCare Distributors', date:'2024-03-03', delivery:'2024-03-12', status:'pending', items:[{name:'Insulin Syringes 1ml',qty:2000,unit:'Pieces',price:4.50},{name:'Glucose Test Strips',qty:500,unit:'Box',price:32.00}], total:25000, notes:'Diabetic ward restocking' },
  { id:'PO-2024-0185', supplier:'SterileSupply Co.', date:'2024-03-05', delivery:'2024-03-15', status:'pending', items:[{name:'Saline 500ml IV',qty:200,unit:'Bags',price:45.00},{name:'Surgical Gloves (L)',qty:1000,unit:'Pairs',price:12.00}], total:21000, notes:'OT & ICU replenishment' },
  { id:'PO-2024-0182', supplier:'BioMed Supplies Pvt Ltd', date:'2024-02-20', delivery:'2024-02-27', status:'delivered', items:[{name:'Bandage Roll 5cm',qty:500,unit:'Rolls',price:6.00},{name:'Latex-free Gloves (M)',qty:300,unit:'Pairs',price:14.00}], total:7200, notes:'Routine monthly order' },
  { id:'PO-2024-0181', supplier:'PharmaDirect India', date:'2024-02-10', delivery:'2024-02-18', status:'cancelled', items:[{name:'Morphine 10mg/ml',qty:100,unit:'Vials',price:85.00}], total:8500, notes:'Cancelled — awaiting new licence clearance' },
];
let poCounter = 186;

const suppliers = [
  { id:'SUP-001', name:'BioMed Supplies Pvt Ltd', contact:'Ramesh Krishnan', phone:'+91 98400 11223', email:'ramesh@biomed.in', location:'Chennai, Tamil Nadu', category:'Pharmaceuticals', rating:4.8, activePOs:2, lastOrder:'2024-03-01', payTerms:'30 days', gst:'33AABCB1234F1Z5', status:'active' },
  { id:'SUP-002', name:'MediCare Distributors', contact:'Priya Nair', phone:'+91 98760 33445', email:'priya@medicare-dist.com', location:'Coimbatore, Tamil Nadu', category:'Critical Care', rating:4.5, activePOs:1, lastOrder:'2024-03-03', payTerms:'15 days', gst:'33AAFCM5678G1Z2', status:'active' },
  { id:'SUP-003', name:'SterileSupply Co.', contact:'Arun Kumar', phone:'+91 44 2345 6789', email:'arun@sterilesupply.in', location:'Chennai, Tamil Nadu', category:'Surgical Supplies', rating:4.2, activePOs:1, lastOrder:'2024-03-05', payTerms:'45 days', gst:'33AAHSS9012H1Z8', status:'active' },
  { id:'SUP-004', name:'PharmaDirect India', contact:'Sunita Rao', phone:'+91 80 9876 5432', email:'sunita@pharmadirect.in', location:'Bengaluru, Karnataka', category:'Controlled Drugs', rating:4.7, activePOs:0, lastOrder:'2024-02-10', payTerms:'60 days', gst:'29AADCP3456I1Z4', status:'inactive' },
  { id:'SUP-005', name:'HealthEquip Solutions', contact:'Mohammed Farhan', phone:'+91 98300 55667', email:'farhan@healthequip.com', location:'Mumbai, Maharashtra', category:'Medical Devices', rating:4.6, activePOs:0, lastOrder:'2024-01-15', payTerms:'30 days', gst:'27AABHH7890J1Z1', status:'active' },
];

function openPurchaseOrders() {
  const el = document.getElementById('poPage');
  el.classList.add('open');
  renderPOTable('all');
}

function closePOPage() {
  document.getElementById('poPage').classList.remove('open');
}

function renderPOTable(filter) {
  document.querySelectorAll('.po-filter-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.po-filter-tab').forEach(t => { if(t.dataset.filter === filter) t.classList.add('active'); });
  const filtered = filter === 'all' ? purchaseOrders : purchaseOrders.filter(p => p.status === filter);
  const tbody = document.getElementById('poTableBody');
  const statusColors = { approved:'rgba(0,204,119,0.15)', pending:'rgba(255,170,0,0.15)', delivered:'rgba(0,212,255,0.15)', cancelled:'rgba(255,68,68,0.1)' };
  const statusText = { approved:'var(--success)', pending:'var(--warning)', delivered:'var(--accent)', cancelled:'var(--danger)' };
  const statusLabel = { approved:'✅ Approved', pending:'⏳ Pending', delivered:'📦 Delivered', cancelled:'❌ Cancelled' };
  tbody.innerHTML = filtered.map(po => `
    <tr style="cursor:pointer" onclick="viewPO('${po.id}')">
      <td style="font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--accent)">${po.id}</td>
      <td><div style="font-weight:500;font-size:13px">${po.supplier}</div><div style="font-size:10px;color:var(--muted)">${po.items.length} item${po.items.length>1?'s':''}</div></td>
      <td style="font-size:12px;color:var(--muted)">${po.date}</td>
      <td style="font-size:12px;color:var(--muted)">${po.delivery}</td>
      <td style="font-family:'Syne',sans-serif;font-weight:700;color:var(--accent4)">₹${po.total.toLocaleString('en-IN')}</td>
      <td><span style="background:${statusColors[po.status]};color:${statusText[po.status]};padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600">${statusLabel[po.status]}</span></td>
      <td>
        ${po.status==='pending'?`<button class="btn btn-success" style="font-size:10px;padding:3px 9px;margin-right:4px" onclick="approvePO('${po.id}',event)">Approve</button>`:''}
        <button class="btn btn-ghost" style="font-size:10px;padding:3px 9px" onclick="viewPO('${po.id}')">View</button>
      </td>
    </tr>`).join('');
  if(!filtered.length) tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--muted)">No purchase orders found</td></tr>`;
}

function approvePO(id, e) {
  e && e.stopPropagation();
  const po = purchaseOrders.find(p=>p.id===id);
  if(!po) return;
  po.status = 'approved';
  renderPOTable(document.querySelector('.po-filter-tab.active')?.dataset.filter||'all');
  showToast('success','✅ PO Approved',`${id} has been approved and sent to ${po.supplier}.`);
}

function viewPO(id) {
  const po = purchaseOrders.find(p=>p.id===id);
  if(!po) return;
  const statusColors = { approved:'rgba(0,204,119,0.15)', pending:'rgba(255,170,0,0.15)', delivered:'rgba(0,212,255,0.15)', cancelled:'rgba(255,68,68,0.1)' };
  const statusText = { approved:'var(--success)', pending:'var(--warning)', delivered:'var(--accent)', cancelled:'var(--danger)' };
  const statusLabel = { approved:'✅ Approved', pending:'⏳ Pending', delivered:'📦 Delivered', cancelled:'❌ Cancelled' };
  const modal = document.getElementById('poDetailModal');
  document.getElementById('poDetailContent').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px">
      <div><div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:3px">PO Number</div><div style="font-family:'JetBrains Mono',monospace;font-size:15px;font-weight:700;color:var(--accent)">${po.id}</div></div>
      <div><div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:3px">Status</div><span style="background:${statusColors[po.status]};color:${statusText[po.status]};padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600">${statusLabel[po.status]}</span></div>
      <div><div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:3px">Supplier</div><div style="font-size:13px;font-weight:500">${po.supplier}</div></div>
      <div><div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:3px">Order Date</div><div style="font-size:13px">${po.date}</div></div>
      <div><div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:3px">Expected Delivery</div><div style="font-size:13px">${po.delivery}</div></div>
      <div><div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:3px">Total Value</div><div style="font-family:'Syne',sans-serif;font-size:15px;font-weight:700;color:var(--accent4)">₹${po.total.toLocaleString('en-IN')}</div></div>
    </div>
    <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:8px">Order Items</div>
    <table style="width:100%;border-collapse:collapse;font-size:12px;margin-bottom:14px">
      <thead><tr style="border-bottom:1px solid var(--border)">
        <th style="text-align:left;padding:7px 10px;color:var(--muted);font-size:10px;text-transform:uppercase">Item</th>
        <th style="text-align:right;padding:7px 10px;color:var(--muted);font-size:10px;text-transform:uppercase">Qty</th>
        <th style="text-align:right;padding:7px 10px;color:var(--muted);font-size:10px;text-transform:uppercase">Unit Price</th>
        <th style="text-align:right;padding:7px 10px;color:var(--muted);font-size:10px;text-transform:uppercase">Amount</th>
      </tr></thead>
      <tbody>${po.items.map(i=>`<tr style="border-bottom:1px solid var(--border)">
        <td style="padding:9px 10px;font-weight:500">${i.name}<div style="font-size:10px;color:var(--muted)">${i.unit}</div></td>
        <td style="padding:9px 10px;text-align:right;font-family:'Syne',sans-serif;font-weight:700">${i.qty.toLocaleString('en-IN')}</td>
        <td style="padding:9px 10px;text-align:right;font-family:'JetBrains Mono',monospace">₹${i.price.toFixed(2)}</td>
        <td style="padding:9px 10px;text-align:right;font-family:'Syne',sans-serif;font-weight:700;color:var(--accent4)">₹${(i.qty*i.price).toLocaleString('en-IN',{minimumFractionDigits:2})}</td>
      </tr>`).join('')}</tbody>
    </table>
    ${po.notes?`<div style="background:var(--card);border:1px solid var(--border);border-radius:8px;padding:10px 14px;font-size:12px;color:var(--muted)"><strong style="color:var(--text)">Notes:</strong> ${po.notes}</div>`:''}
    ${po.status==='pending'?`<div style="margin-top:14px;display:flex;gap:8px">
      <button class="btn btn-success" style="flex:1" onclick="approvePO('${po.id}');document.getElementById('poDetailModal').style.display='none'">✅ Approve PO</button>
      <button class="btn btn-danger" style="flex:1" onclick="cancelPO('${po.id}')">❌ Cancel PO</button>
    </div>`:''}`;
  modal.style.display = 'block';
}

function cancelPO(id) {
  const po = purchaseOrders.find(p=>p.id===id);
  if(!po) return;
  po.status = 'cancelled';
  document.getElementById('poDetailModal').style.display = 'none';
  renderPOTable(document.querySelector('.po-filter-tab.active')?.dataset.filter||'all');
  showToast('warn','❌ PO Cancelled',`${id} has been cancelled.`);
}

function createNewPO() {
  const modal = document.getElementById('newPOModal');
  document.getElementById('newPOSupplier').value = '';
  document.getElementById('newPODelivery').value = '';
  document.getElementById('newPONotes').value = '';
  document.getElementById('newPOItem').value = '';
  document.getElementById('newPOQty').value = '';
  document.getElementById('newPOPrice').value = '';
  document.getElementById('newPOItemsList').innerHTML = '';
  window._newPOItems = [];
  // Populate inventory datalist
  document.getElementById('inventoryItemsList').innerHTML = inventoryData.map(i=>`<option value="${i.name}">`).join('');
  modal.style.display = 'block';
}

function addPOLineItem() {
  const name = document.getElementById('newPOItem').value.trim();
  const qty = parseInt(document.getElementById('newPOQty').value)||0;
  const price = parseFloat(document.getElementById('newPOPrice').value)||0;
  if(!name||qty<=0||price<=0){ showToast('warn','⚠️','Please fill item name, quantity, and price.'); return; }
  if(!window._newPOItems) window._newPOItems = [];
  window._newPOItems.push({name,qty,unit:'Units',price});
  document.getElementById('newPOItem').value='';
  document.getElementById('newPOQty').value='';
  document.getElementById('newPOPrice').value='';
  const list = document.getElementById('newPOItemsList');
  list.innerHTML = window._newPOItems.map((i,idx)=>`
    <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 10px;background:var(--surface);border-radius:7px;font-size:12px;margin-bottom:5px">
      <span style="font-weight:500;flex:1">${i.name}</span>
      <span style="color:var(--muted);margin:0 10px">${i.qty} units × ₹${i.price.toFixed(2)}</span>
      <span style="color:var(--accent4);font-weight:600;margin-right:10px">₹${(i.qty*i.price).toLocaleString('en-IN',{minimumFractionDigits:2})}</span>
      <span style="cursor:pointer;color:var(--danger)" onclick="window._newPOItems.splice(${idx},1);addPOLineItem.call({skipAdd:true})">✕</span>
    </div>`).join('');
  showToast('success','➕ Item Added',`${name} added to PO.`);
}

function submitNewPO() {
  const supplier = document.getElementById('newPOSupplier').value.trim();
  const delivery = document.getElementById('newPODelivery').value;
  const notes = document.getElementById('newPONotes').value.trim();
  if(!supplier){ showToast('warn','⚠️','Please select or enter a supplier.'); return; }
  if(!window._newPOItems||!window._newPOItems.length){ showToast('warn','⚠️','Please add at least one item.'); return; }
  const total = window._newPOItems.reduce((s,i)=>s+i.qty*i.price,0);
  const id = `PO-2024-0${poCounter++}`;
  const today = new Date().toISOString().split('T')[0];
  purchaseOrders.unshift({id,supplier,date:today,delivery:delivery||'TBD',status:'pending',items:window._newPOItems,total,notes});
  document.getElementById('newPOModal').style.display='none';
  renderPOTable('all');
  showToast('success','📦 Purchase Order Created',`${id} created for ${supplier} — ₹${total.toLocaleString('en-IN')}`);
}

// ===== SUPPLIERS =====
function openSuppliersPage() {
  document.getElementById('suppliersPage').classList.add('open');
  renderSuppliersGrid('all');
}

function closeSuppliersPage() {
  document.getElementById('suppliersPage').classList.remove('open');
}

function renderSuppliersGrid(filter) {
  document.querySelectorAll('.sup-filter-tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.sup-filter-tab').forEach(t=>{ if(t.dataset.filter===filter) t.classList.add('active'); });
  const filtered = filter==='all' ? suppliers : suppliers.filter(s=>s.status===filter);
  const grid = document.getElementById('suppliersGrid');
  grid.innerHTML = filtered.map(s=>`
    <div class="sup-card" onclick="viewSupplier('${s.id}')">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
        <div style="width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:#000;font-family:'Syne',sans-serif">${s.name.charAt(0)}</div>
        <span style="background:${s.status==='active'?'rgba(0,204,119,0.15)':'rgba(255,68,68,0.1)'};color:${s.status==='active'?'var(--success)':'var(--danger)'};padding:3px 9px;border-radius:20px;font-size:10px;font-weight:600">${s.status==='active'?'● Active':'● Inactive'}</span>
      </div>
      <div style="font-family:'Syne',sans-serif;font-size:14px;font-weight:700;margin-bottom:2px">${s.name}</div>
      <div style="font-size:11px;color:var(--accent5);margin-bottom:10px">${s.category}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:11px;color:var(--muted);margin-bottom:12px">
        <div>📍 ${s.location.split(',')[0]}</div>
        <div>👤 ${s.contact.split(' ')[0]}</div>
        <div>📦 ${s.activePOs} active POs</div>
        <div>💳 ${s.payTerms}</div>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between">
        <div style="display:flex;gap:1px">${[1,2,3,4,5].map(n=>`<span style="color:${n<=Math.round(s.rating)?'var(--accent4)':'var(--border)'};font-size:12px">★</span>`).join('')}<span style="font-size:11px;color:var(--muted);margin-left:4px">${s.rating}</span></div>
        <button class="btn btn-ghost" style="font-size:10px;padding:4px 10px" onclick="createPOForSupplier('${s.id}',event)">+ New PO</button>
      </div>
    </div>`).join('');
  if(!filtered.length) grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--muted)">No suppliers found</div>`;
}

function viewSupplier(id) {
  const s = suppliers.find(x=>x.id===id);
  if(!s) return;
  const supPOs = purchaseOrders.filter(p=>p.supplier===s.name);
  const modal = document.getElementById('supplierDetailModal');
  document.getElementById('supplierDetailContent').innerHTML = `
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:18px">
      <div style="width:52px;height:52px;border-radius:12px;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:800;color:#000;font-family:'Syne',sans-serif">${s.name.charAt(0)}</div>
      <div>
        <div style="font-family:'Syne',sans-serif;font-size:16px;font-weight:700">${s.name}</div>
        <div style="font-size:11px;color:var(--accent5)">${s.category}</div>
        <span style="background:${s.status==='active'?'rgba(0,204,119,0.15)':'rgba(255,68,68,0.1)'};color:${s.status==='active'?'var(--success)':'var(--danger)'};padding:2px 8px;border-radius:20px;font-size:10px;font-weight:600">${s.status==='active'?'● Active':'● Inactive'}</span>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px">
      ${[['👤 Contact',s.contact],['📞 Phone',s.phone],['✉️ Email',s.email],['📍 Location',s.location],['💳 Payment Terms',s.payTerms],['🏷 GST',s.gst],['⭐ Rating',s.rating+'/5'],['📅 Last Order',s.lastOrder]].map(([l,v])=>`
        <div style="background:var(--card);border:1px solid var(--border);border-radius:8px;padding:10px 12px">
          <div style="font-size:10px;color:var(--muted);margin-bottom:3px">${l.split(' ')[0]}&nbsp;${l.split(' ').slice(1).join(' ')}</div>
          <div style="font-size:12px;font-weight:500">${v}</div>
        </div>`).join('')}
    </div>
    ${supPOs.length?`
    <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:8px">Recent Purchase Orders (${supPOs.length})</div>
    <div style="display:flex;flex-direction:column;gap:6px">
      ${supPOs.slice(0,4).map(po=>{
        const sc={approved:'var(--success)',pending:'var(--warning)',delivered:'var(--accent)',cancelled:'var(--danger)'};
        return `<div style="display:flex;justify-content:space-between;align-items:center;background:var(--card);border:1px solid var(--border);border-radius:8px;padding:9px 12px;font-size:12px">
          <span style="font-family:'JetBrains Mono',monospace;color:var(--accent)">${po.id}</span>
          <span style="color:var(--muted)">${po.date}</span>
          <span style="color:var(--accent4);font-weight:600">₹${po.total.toLocaleString('en-IN')}</span>
          <span style="color:${sc[po.status]};font-weight:600;font-size:10px">${po.status.toUpperCase()}</span>
        </div>`;
      }).join('')}
    </div>`:'<div style="text-align:center;color:var(--muted);padding:16px;font-size:12px">No purchase orders yet</div>'}
    <button class="btn btn-primary" style="width:100%;margin-top:14px" onclick="createPOForSupplier('${s.id}');document.getElementById('supplierDetailModal').style.display='none'">📦 Create New Purchase Order</button>`;
  modal.style.display = 'block';
}

function createPOForSupplier(id, e) {
  e && e.stopPropagation();
  const s = suppliers.find(x=>x.id===id);
  if(!s) return;
  // Close supplier pages and open PO creation
  document.getElementById('suppliersPage').classList.remove('open');
  document.getElementById('supplierDetailModal').style.display='none';
  document.getElementById('poPage').classList.add('open');
  createNewPO();
  setTimeout(()=>{ document.getElementById('newPOSupplier').value = s.name; }, 100);
}

function searchSuppliers(q) {
  if(!q) { renderSuppliersGrid('all'); return; }
  const filtered = suppliers.filter(s=>s.name.toLowerCase().includes(q.toLowerCase())||s.category.toLowerCase().includes(q.toLowerCase())||s.location.toLowerCase().includes(q.toLowerCase()));
  const grid = document.getElementById('suppliersGrid');
  grid.innerHTML = filtered.map(s=>`
    <div class="sup-card" onclick="viewSupplier('${s.id}')">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
        <div style="width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:#000;font-family:'Syne',sans-serif">${s.name.charAt(0)}</div>
        <span style="background:${s.status==='active'?'rgba(0,204,119,0.15)':'rgba(255,68,68,0.1)'};color:${s.status==='active'?'var(--success)':'var(--danger)'};padding:3px 9px;border-radius:20px;font-size:10px;font-weight:600">${s.status==='active'?'● Active':'● Inactive'}</span>
      </div>
      <div style="font-family:'Syne',sans-serif;font-size:14px;font-weight:700;margin-bottom:2px">${s.name}</div>
      <div style="font-size:11px;color:var(--accent5);margin-bottom:10px">${s.category}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:11px;color:var(--muted);margin-bottom:12px">
        <div>📍 ${s.location.split(',')[0]}</div>
        <div>👤 ${s.contact.split(' ')[0]}</div>
        <div>📦 ${s.activePOs} active POs</div>
        <div>💳 ${s.payTerms}</div>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between">
        <div style="display:flex;gap:1px">${[1,2,3,4,5].map(n=>`<span style="color:${n<=Math.round(s.rating)?'var(--accent4)':'var(--border)'};font-size:12px">★</span>`).join('')}<span style="font-size:11px;color:var(--muted);margin-left:4px">${s.rating}</span></div>
        <button class="btn btn-ghost" style="font-size:10px;padding:4px 10px" onclick="createPOForSupplier('${s.id}',event)">+ New PO</button>
      </div>
    </div>`).join('');
}
// ===== REPORTS PAGE =====
function openReportsPage() {
  document.getElementById('reportsPage').classList.add('open');
  renderReportsSummary();
}
function closeReportsPage() {
  document.getElementById('reportsPage').classList.remove('open');
}
function renderReportsSummary() {
  // Consumption by category
  const cats = { drug:0, critical:0, supply:0, device:0 };
  inventoryData.forEach(i => { if(cats[i.cat]!==undefined) cats[i.cat] += i.dailyUse * 7; });
  const catNames = { drug:'💊 Drugs', critical:'🚨 Critical Care', supply:'🧤 Supplies', device:'🔬 Devices' };
  const catColors2 = { drug:'var(--accent)', critical:'var(--danger)', supply:'var(--accent4)', device:'var(--accent5)' };
  const totalConsumption = Object.values(cats).reduce((a,b)=>a+b,0);
  document.getElementById('reportCatBars').innerHTML = Object.entries(cats).map(([cat, val]) => {
    const pct = totalConsumption > 0 ? Math.round((val/totalConsumption)*100) : 0;
    return `<div style="margin-bottom:12px">
      <div style="display:flex;justify-content:space-between;margin-bottom:4px;font-size:12px">
        <span>${catNames[cat]}</span>
        <span style="font-weight:600;color:${catColors2[cat]}">${val} units (${pct}%)</span>
      </div>
      <div style="height:8px;background:var(--border);border-radius:4px;overflow:hidden">
        <div style="height:100%;width:${pct}%;background:${catColors2[cat]};border-radius:4px;transition:width 0.8s ease"></div>
      </div>
    </div>`;
  }).join('');
  // Top consumed items
  const topItems = [...inventoryData].sort((a,b)=>b.dailyUse-a.dailyUse).slice(0,5);
  document.getElementById('reportTopItems').innerHTML = topItems.map((item,i) => `
    <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border)">
      <div style="width:24px;height:24px;border-radius:6px;background:rgba(0,212,255,0.1);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:var(--accent)">${i+1}</div>
      <div style="flex:1">
        <div style="font-size:13px;font-weight:500">${item.name}</div>
        <div style="font-size:10px;color:var(--muted)">${item.location}</div>
      </div>
      <div style="text-align:right">
        <div style="font-family:'Syne',sans-serif;font-weight:700;color:var(--accent)">${item.dailyUse}/day</div>
        <div style="font-size:10px;color:var(--muted)">${item.dailyUse*30}/month est.</div>
      </div>
    </div>`).join('');
  // Stock value estimate
  const stockValue = inventoryData.reduce((s,i) => {
    const prices = {'MED-0042':8.50,'MED-0187':45,'MED-0334':12,'MED-0219':18,'MED-0056':22,'MED-0471':6,'DEV-0012':1200,'MED-0308':3.50,'MED-0093':85,'MED-0335':14};
    return s + i.stock * (prices[i.id]||10);
  }, 0);
  document.getElementById('reportStockValue').textContent = '₹' + stockValue.toLocaleString('en-IN',{minimumFractionDigits:2});
  document.getElementById('reportTotalItems').textContent = inventoryData.length;
  document.getElementById('reportCriticalCount').textContent = inventoryData.filter(i=>i.status==='critical').length;
  document.getElementById('reportExpiryCount').textContent = inventoryData.filter(i => {
    if(!i.expiry||i.expiry==='N/A') return false;
    return Math.ceil((new Date(i.expiry)-new Date())/86400000) <= 90;
  }).length;
}
function downloadReport(type) {
  if (type === 'inventory') { exportData(); return; }
  if (type === 'expiry') { if(typeof exportExpiryCSV==='function') exportExpiryCSV(); return; }
  const csvData = {
    consumption: ['Item,Daily Usage,Weekly Est,Monthly Est,Location\n', ...inventoryData.map(i=>`"${i.name}",${i.dailyUse},${i.dailyUse*7},${i.dailyUse*30},"${i.location}"`)].join('\n'),
    lowstock: ['Item,SKU,Stock,Max,Threshold,Status\n', ...inventoryData.filter(i=>i.status!=='ok').map(i=>`"${i.name}",${i.id},${i.stock},${i.max},${i.reorderPt},${i.status}`)].join('\n'),
    po: ['PO ID,Supplier,Date,Delivery,Total,Status\n', ...purchaseOrders.map(p=>`${p.id},"${p.supplier}",${p.date},${p.delivery},${p.total},${p.status}`)].join('\n'),
  };
  if (!csvData[type]) { showToast('info','📊 Report','Generating...'); return; }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csvData[type]], {type:'text/csv'}));
  a.download = `medai_${type}_report.csv`;
  a.click();
  showToast('success','📥 Downloaded',`${type} report exported to CSV.`);
}

// ===== SETTINGS PAGE =====
let appSettings = {
  hospitalName: 'City Hospital',
  hospitalLocation: 'Madurai, Tamil Nadu',
  gstin: '33AAAXX0000X1Z5',
  phone: '+91 98765 43210',
  lowStockThreshold: 20,
  criticalThreshold: 10,
  autoReorder: true,
  emailAlerts: true,
  smsAlerts: false,
  aiAssist: true,
  darkMode: true,
  language: 'English',
  currency: '₹ INR',
  dateFormat: 'DD/MM/YYYY',
  gstRate: 12,
  backupFreq: 'Daily',
};
function openSettingsPage() {
  document.getElementById('settingsPage').classList.add('open');
  loadSettings();
  checkApiKeyStatus();
  // Populate users table
  const tbody = document.getElementById('settingsUsersTable');
  if (tbody) {
    tbody.innerHTML = Object.entries(users).map(([role,u]) => `
      <tr style="border-bottom:1px solid var(--border)">
        <td style="padding:9px 12px"><span style="background:rgba(0,212,255,0.1);color:var(--accent);padding:2px 8px;border-radius:20px;font-size:10px;font-weight:600">${role}</span></td>
        <td style="padding:9px 12px;font-weight:500">${u.name}</td>
        <td style="padding:9px 12px;font-family:'JetBrains Mono',monospace;color:var(--muted)">${u.email}</td>
        <td style="padding:9px 12px;font-family:'JetBrains Mono',monospace;color:var(--muted)">${u.pass}</td>
      </tr>`).join('');
  }
}
function closeSettingsPage() {
  document.getElementById('settingsPage').classList.remove('open');
}
function loadSettings() {
  // Load persisted settings (localStorage or cookie)
  const saved = _loadSettingsFromDisk();
  if (saved) Object.assign(appSettings, saved);

  Object.keys(appSettings).forEach(key => {
    const el = document.getElementById('set-'+key);
    if (!el) return;
    if (el.type === 'checkbox') {
      el.checked = appSettings[key];
    } else if (el.tagName === 'SELECT') {
      // Match option by value first, then text content
      const val = String(appSettings[key]);
      let matched = false;
      for (let i = 0; i < el.options.length; i++) {
        const opt = el.options[i];
        if (opt.value === val || opt.text === val || opt.text.trim() === val.trim()) {
          el.selectedIndex = i;
          matched = true;
          break;
        }
      }
      if (!matched && val) {
        // Try partial match for currency symbols etc.
        for (let i = 0; i < el.options.length; i++) {
          if (el.options[i].text.includes(val) || val.includes(el.options[i].text)) {
            el.selectedIndex = i;
            break;
          }
        }
      }
    } else {
      el.value = appSettings[key];
    }
  });

  // Apply dark mode on load
  applyDarkMode(appSettings.darkMode !== false);

  // Explicitly sync language and backupFreq after load
  ['language','backupFreq'].forEach(key => {
    const el = document.getElementById('set-'+key);
    if (!el) return;
    const val = String(appSettings[key] || '');
    for (let i = 0; i < el.options.length; i++) {
      if (el.options[i].value === val || el.options[i].text === val) {
        el.selectedIndex = i;
        break;
      }
    }
  });
}
// ===== TRANSLATIONS =====
const translations = {
  'தமிழ்': {
    'Dashboard':'டாஷ்போர்டு', 'Inventory':'சரக்கு பட்டியல்', 'Alerts & Notifications':'எச்சரிக்கைகள்',
    'Purchase Orders':'கொள்முதல் ஆர்டர்கள்', 'Suppliers':'சப்ளையர்கள்', 'Expiry Tracker':'காலாவதி கண்காணிப்பு',
    'AI Forecast':'AI முன்கணிப்பு', 'Auto Reorder':'தானியங்கி மறுஆர்டர்', 'Reports':'அறிக்கைகள்', 'Settings':'அமைப்புகள்',
    'Total SKUs':'மொத்த பொருட்கள்', 'In Stock':'கையிருப்பில்', 'Low Stock':'குறைந்த கையிருப்பு',
    'Critical':'அவசரம்', 'Save Settings':'அமைப்புகளை சேமி', 'Reset Defaults':'இயல்புநிலைக்கு மீட்டமை',
    'Language':'மொழி', 'Auto Backup Frequency':'தானியங்கி காப்புப்பிரதி', 'Dark Mode':'இருண்ட முறை',
    'Hospital Information':'மருத்துவமனை தகவல்', 'Stock Thresholds & Alerts':'கையிருப்பு வரம்புகள்',
    'AI & Forecasting':'AI மற்றும் முன்கணிப்பு', 'Billing & Finance':'பில்லிங் மற்றும் நிதி',
    'System':'கணினி', 'Search inventory...':'சரக்கு தேடு...',
    'New Bill':'புதிய பில்', 'Generate Bill':'பில் உருவாக்கு'
  },
  'हिंदी': {
    'Dashboard':'डैशबोर्ड', 'Inventory':'इन्वेंटरी', 'Alerts & Notifications':'अलर्ट और सूचनाएं',
    'Purchase Orders':'खरीद ऑर्डर', 'Suppliers':'आपूर्तिकर्ता', 'Expiry Tracker':'समाप्ति ट्रैकर',
    'AI Forecast':'AI पूर्वानुमान', 'Auto Reorder':'ऑटो री-ऑर्डर', 'Reports':'रिपोर्ट', 'Settings':'सेटिंग्स',
    'Total SKUs':'कुल SKU', 'In Stock':'स्टॉक में', 'Low Stock':'कम स्टॉक',
    'Critical':'गंभीर', 'Save Settings':'सेटिंग्स सहेजें', 'Reset Defaults':'डिफ़ॉल्ट रीसेट करें',
    'Language':'भाषा', 'Auto Backup Frequency':'ऑटो बैकअप', 'Dark Mode':'डार्क मोड',
    'Hospital Information':'अस्पताल जानकारी', 'Stock Thresholds & Alerts':'स्टॉक सीमाएं',
    'AI & Forecasting':'AI और पूर्वानुमान', 'Billing & Finance':'बिलिंग और वित्त',
    'System':'सिस्टम', 'Search inventory...':'इन्वेंटरी खोजें...',
    'New Bill':'नया बिल', 'Generate Bill':'बिल बनाएं'
  }
};

function applyLanguage(lang) {
  const t = translations[lang];
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (!t) {
      // Restore English — use the data-i18n key itself as the original text
      el.textContent = key;
    } else if (t[key]) {
      el.textContent = t[key];
    }
  });
  // Update page title
  const pt = document.getElementById('pageTitle');
  if (pt) {
    const titleMap = { dashboard:'Dashboard', inventory:'Inventory', alerts:'Alerts & Notifications', orders:'Purchase Orders', suppliers:'Suppliers', expiry:'Expiry Tracker', forecast:'AI Forecast', reorder:'Auto Reorder', reports:'Reports', settings:'Settings' };
    const currentKey = Object.values(titleMap).find(v => v === pt.textContent) || pt.textContent;
    if (!t) {
      // Restore English
    } else if (t[pt.textContent]) {
      pt.textContent = t[pt.textContent];
    }
  }
  // toast handled by saveSettings caller
}

// ===== AUTO BACKUP =====
let backupTimer = null;
const backupIntervals = { 'Daily': 86400000, 'Weekly': 604800000, 'Monthly': 2592000000 };

function scheduleAutoBackup(freq) {
  if (backupTimer) clearInterval(backupTimer);
  const interval = backupIntervals[freq];
  if (!interval) return;
  backupTimer = setInterval(() => triggerAutoBackup(), interval);
}

function triggerAutoBackup() {
  const data = {
    timestamp: new Date().toISOString(),
    settings: appSettings,
    inventory: inventoryData,
    alerts: allAlerts
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `MedAI_Backup_${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  showToast('success', '✅ Backup Complete', `Auto backup downloaded successfully.`);
}

function applyDarkMode(isDark) {
  if (isDark) {
    document.body.classList.add('dark-mode');
  } else {
    document.body.classList.remove('dark-mode');
  }
  const el = document.getElementById('set-darkMode');
  if (el) el.checked = isDark;
  appSettings.darkMode = isDark;
}

function saveSettings() {
  // Read all values from DOM into appSettings
  Object.keys(appSettings).forEach(key => {
    const el = document.getElementById('set-'+key);
    if (!el) return;
    if (el.type === 'checkbox') {
      appSettings[key] = el.checked;
    } else if (el.tagName === 'SELECT') {
      const selected = el.options[el.selectedIndex];
      if (selected) appSettings[key] = selected.value !== '' ? selected.value : selected.text;
    } else if (el.type === 'number') {
      appSettings[key] = parseFloat(el.value) || 0;
    } else {
      appSettings[key] = el.value;
    }
  });
  // Ensure language and backupFreq are never empty
  if (!appSettings.language) appSettings.language = 'English';
  if (!appSettings.backupFreq) appSettings.backupFreq = 'Daily';

  // Update receipt address
  const addr = document.getElementById('receiptAddress');
  if(addr) addr.innerHTML = `${appSettings.hospitalName}, ${appSettings.hospitalLocation}<br>📞 ${appSettings.phone} &nbsp;|&nbsp; GSTIN: ${appSettings.gstin}`;

  // Always persist to localStorage (works on http) + cookie fallback (file://)
  _saveSettingsToDisk();

  // Always apply language (even if same — ensures UI reflects correctly)
  applyLanguage(appSettings.language);

  // Apply dark mode
  applyDarkMode(appSettings.darkMode);

  // Always re-schedule backup with current frequency
  scheduleAutoBackup(appSettings.backupFreq);

  showToast('success','✅ Settings Saved','All settings have been saved and applied.');
}

function _saveSettingsToDisk() {
  const json = JSON.stringify(appSettings);
  try {
    localStorage.setItem('medai_settings', json);
    return;
  } catch(e) {}
  // Fallback: store in cookie (works on file://)
  try {
    document.cookie = 'medai_settings=' + encodeURIComponent(json) + '; max-age=31536000; path=/';
  } catch(e) {}
}

function _loadSettingsFromDisk() {
  // Try localStorage first
  try {
    const ls = localStorage.getItem('medai_settings');
    if (ls) return JSON.parse(ls);
  } catch(e) {}
  // Fallback: cookie
  try {
    const match = document.cookie.match(/medai_settings=([^;]+)/);
    if (match) return JSON.parse(decodeURIComponent(match[1]));
  } catch(e) {}
  return null;
}
function resetSettings() {
  if(!confirm('Reset all settings to defaults?')) return;
  appSettings = { hospitalName:'City Hospital', hospitalLocation:'Madurai, Tamil Nadu', gstin:'33AAAXX0000X1Z5', phone:'+91 98765 43210', lowStockThreshold:20, criticalThreshold:10, autoReorder:true, emailAlerts:true, smsAlerts:false, aiAssist:true, darkMode:true, language:'English', currency:'₹ INR', dateFormat:'DD/MM/YYYY', gstRate:12, backupFreq:'Daily' };
  loadSettings();
  showToast('info','🔄 Reset','Settings restored to defaults.');
}

// ================================================================
//   REAL AI INTEGRATION — OpenRouter API (FREE - No Credit Card!)
//   Features: Forecast, Reorder, Expiry Risk, Natural Language Search
// ================================================================

// ── API Key Management ──────────────────────────────────────────
function getApiKey() {
  return localStorage.getItem('medai_groq_api_key') || '';
}
function setApiKey(key) {
  if (key) localStorage.setItem('medai_groq_api_key', key.trim());
  else localStorage.removeItem('medai_groq_api_key');
}
function hasApiKey() {
  return !!getApiKey();
}

// ── Core OpenRouter API caller ─────────────────────────────────────────
// OpenRouter API — Completely Free, Works in India!
// ── AI Provider config ─────────────────────────────────────────────
// Change AI_PROVIDER to switch between providers:
//   'anthropic'   → Direct Anthropic API (claude-haiku-4-5) — recommended, no rate limits on free tier daily cap
//   'openrouter'  → OpenRouter with a specific model (set AI_MODEL below)
const AI_PROVIDER = 'openrouter';
const AI_MODEL    = 'deepseek/deepseek-chat-v3-0324:free'; // free, reliable, works in India
// If you switch back to OpenRouter, change AI_PROVIDER to 'openrouter' and set AI_MODEL to e.g.:
//   'google/gemini-flash-1.5'  (free, generous limits)
//   'meta-llama/llama-3.1-8b-instruct:free'  (free)
//   'anthropic/claude-haiku'   (paid, fast)

async function callClaude(systemPrompt, userMessage, maxTokens = 1000) {
  const key = getApiKey();
  if (!key) { showApiKeyPrompt(); throw new Error('NO_API_KEY'); }

  let res;

  if (AI_PROVIDER === 'anthropic') {
    // ── Direct Anthropic API ──────────────────────────────────────
    res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model: AI_MODEL,
        max_tokens: maxTokens,
        system: systemPrompt,
        messages: [{ role: 'user', content: userMessage }],
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      if (res.status === 401) throw new Error('INVALID_KEY');
      if (res.status === 429) throw new Error('Rate limit hit — wait a minute and try again');
      throw new Error(err?.error?.message || 'Anthropic API error ' + res.status);
    }

    const data = await res.json();
    return data?.content?.[0]?.text || '';

  } else {
    // ── OpenRouter API ────────────────────────────────────────────
    res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${key}`,
        'HTTP-Referer': 'http://localhost',
        'X-Title': 'MedAI Pro',
      },
      body: JSON.stringify({
        model: AI_MODEL,
        max_tokens: maxTokens,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userMessage },
        ],
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      if (res.status === 401) throw new Error('INVALID_KEY');
      if (res.status === 429) throw new Error('Rate limit exceeded — switch model or wait till midnight UTC');
      throw new Error(err?.error?.message || 'OpenRouter API error ' + res.status);
    }

    const data = await res.json();
    return data?.choices?.[0]?.message?.content || '';
  }
}

// ── API Key Setup UI ─────────────────────────────────────────────
function showApiKeyPrompt() {
  showToast('warn', '🔑 API Key Required',
    `<span style="cursor:pointer;text-decoration:underline;color:var(--accent)" onclick="openSettingsPage();closeToastById && closeToastById(this)">Click here to add your OpenRouter API key in Settings</span>`);
}

function saveApiKey() {
  const val = (document.getElementById('apiKeyInput')?.value || '').trim();
  if (!val) { showToast('warn', '⚠️', 'Please enter a valid API key'); return; }
  setApiKey(val);
  document.getElementById('apiKeyInput').value = '';
  document.getElementById('apiKeyStatus').innerHTML =
    `<span style="color:var(--success);font-weight:600">✅ API Key saved — AI features enabled!</span>`;
  showToast('success', '✅ API Key Saved', 'OpenRouter AI features are now active!');
}

function clearApiKey() {
  setApiKey('');
  const status = document.getElementById('apiKeyStatus');
  if (status) status.innerHTML = `<span style="color:var(--muted)">No API key set</span>`;
  showToast('info', '🗑️ API Key Removed', 'AI features disabled.');
}

function checkApiKeyStatus() {
  const status = document.getElementById('apiKeyStatus');
  if (status) {
    status.innerHTML = hasApiKey()
      ? `<span style="color:var(--success);font-weight:600">✅ API Key saved — OpenRouter AI ready</span>`
      : `<span style="color:var(--muted)">No API key — enter below to enable AI features</span>`;
  }

  // Show server mode banner
  const banner = document.getElementById('serverModeBanner');
  if (!banner) return;
  const port = location.port;
  const isNode = port === '3000';
  const isLive = port === '5500' || port === '5501';
  const isFile = location.protocol === 'file:';

  if (isNode) {
    banner.style.cssText = 'background:rgba(0,255,157,0.08);border:1px solid rgba(0,255,157,0.25);border-radius:10px;padding:10px 14px;margin-bottom:12px;font-size:12px;';
    banner.innerHTML = '🟢 <b style="color:var(--accent2)">node server.js mode</b> — Local proxy active. All AI features work perfectly!';
  } else if (isLive) {
    banner.style.cssText = 'background:rgba(255,170,0,0.08);border:1px solid rgba(255,170,0,0.25);border-radius:10px;padding:10px 14px;margin-bottom:12px;font-size:12px;';
    banner.innerHTML = `⚠️ <b style="color:var(--warning)">Live Server mode (port ${port})</b> — AI features may be CORS-blocked by Chrome.<br>
      <span style="color:var(--muted)">For best results: VS Code Terminal → <code style="background:var(--surface);padding:2px 6px;border-radius:4px;">node server.js</code> → open <a href="http://localhost:3000" target="_blank" style="color:var(--accent)">localhost:3000</a></span>`;
  } else if (isFile) {
    banner.style.cssText = 'background:rgba(255,68,68,0.08);border:1px solid rgba(255,68,68,0.25);border-radius:10px;padding:10px 14px;margin-bottom:12px;font-size:12px;';
    banner.innerHTML = `❌ <b style="color:var(--danger)">File:// mode</b> — AI features will not work.<br>
      <span style="color:var(--muted)">Run: <code style="background:var(--surface);padding:2px 6px;border-radius:4px;">node server.js</code> → <a href="http://localhost:3000" target="_blank" style="color:var(--accent)">localhost:3000</a></span>`;
  } else {
    banner.style.cssText = 'background:rgba(0,212,255,0.07);border:1px solid rgba(0,212,255,0.2);border-radius:10px;padding:10px 14px;margin-bottom:12px;font-size:12px;';
    banner.innerHTML = `ℹ️ Running on port <b>${port || 'unknown'}</b> — <span style="color:var(--muted)">For AI features, run <code style="background:var(--surface);padding:2px 6px;border-radius:4px;">node server.js</code> and open <a href="http://localhost:3000" target="_blank" style="color:var(--accent)">localhost:3000</a></span>`;
  }
}

// ── 1. AI FORECAST (JS Logic — no API needed) ───────────────────
async function runAIForecast() {
  const btn = document.getElementById('aiForecastBtn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Analyzing...'; }

  await new Promise(r => setTimeout(r, 1200)); // realistic loading

  try {
    const today = new Date();
    const results = inventoryData.map(item => {
      const daysToOut = item.dailyUse > 0 ? Math.floor(item.stock / item.dailyUse) : 999;
      const expDays = item.expiry && item.expiry !== 'N/A'
        ? Math.ceil((new Date(item.expiry) - today) / 86400000) : 999;

      let risk = 'ok', action = 'Stock level healthy', trend = 'stable';
      if (item.stock === 0) { risk = 'critical'; action = 'Immediate reorder required'; trend = 'critical'; }
      else if (daysToOut < 5 || item.status === 'critical') { risk = 'critical'; action = 'Reorder urgently within 24hrs'; trend = 'declining fast'; }
      else if (daysToOut < 14 || item.status === 'warn') { risk = 'warn'; action = 'Plan reorder this week'; trend = 'declining'; }
      else if (expDays < 30) { risk = 'warn'; action = 'Near expiry — use first or transfer'; trend = 'expiry risk'; }

      const forecastItem = forecastData.find(f => f.id === item.id);
      if (forecastItem) {
        forecastItem.risk = risk;
        forecastItem.action = action;
        forecastItem.trend = trend;
        forecastItem.daysLeft = daysToOut < 999 ? daysToOut : forecastItem.daysLeft;
      }
      return { id: item.id, risk, action };
    });

    const critical = results.filter(r => r.risk === 'critical').length;
    const warn = results.filter(r => r.risk === 'warn').length;

    renderForecastCards();
    showToast('success', '🤖 AI Forecast Updated', `${critical} critical, ${warn} warning items detected`);
  } catch (e) {
    showToast('danger', '❌ Forecast Error', e.message);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '🤖 Run AI Forecast'; }
  }
}

// ── 2. SMART REORDER SUGGESTIONS (JS Logic — no API needed) ──────
async function runSmartReorder() {
  const btn = document.getElementById('aiReorderBtn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Thinking...'; }

  await new Promise(r => setTimeout(r, 1500)); // realistic loading

  try {
    const today = new Date();
    const lowItems = inventoryData.filter(i => i.status === 'critical' || i.status === 'warn');

    if (lowItems.length === 0) {
      showToast('success', '✅ All Good', 'No items need reordering right now.');
      return;
    }

    const suggestions = lowItems.map(item => {
      const daysToOut = item.dailyUse > 0 ? Math.floor(item.stock / item.dailyUse) : 999;
      const expDays = item.expiry && item.expiry !== 'N/A'
        ? Math.ceil((new Date(item.expiry) - today) / 86400000) : 999;

      // Smart qty calculation: fill to max, account for expiry
      let recommendedQty = item.max - item.stock;
      if (expDays < 60 && expDays > 0) {
        // If expiring soon, order only what can be used before expiry
        recommendedQty = Math.min(recommendedQty, item.dailyUse * expDays);
      }
      recommendedQty = Math.max(recommendedQty, item.reorderPt);

      let priority = 'MEDIUM';
      let reason = 'Stock below reorder point';
      if (item.stock === 0) { priority = 'URGENT'; reason = 'Out of stock — critical shortage'; }
      else if (daysToOut < 3) { priority = 'URGENT'; reason = `Only ${daysToOut} days of stock remaining`; }
      else if (daysToOut < 7) { priority = 'HIGH'; reason = `${daysToOut} days of stock — reorder this week`; }
      else if (expDays < 30) { priority = 'HIGH'; reason = `Expires in ${expDays} days — use current stock first`; }

      const unitCost = item.cat === 'critical' ? 85 : item.cat === 'drug' ? 12 : item.cat === 'device' ? 2500 : 8;
      const estimatedCost = '₹' + (recommendedQty * unitCost).toLocaleString('en-IN');

      return { id: item.id, name: item.name, recommendedQty, reason, priority, estimatedCost };
    });

    // Sort by priority
    const order = { URGENT: 0, HIGH: 1, MEDIUM: 2 };
    suggestions.sort((a, b) => order[a.priority] - order[b.priority]);

    const html = suggestions.map(s =>
      `<div style="padding:8px 0;border-bottom:1px solid var(--border)">
        <b style="color:var(--accent)">${s.name}</b>
        <span style="float:right;color:${s.priority==='URGENT'?'var(--danger)':s.priority==='HIGH'?'var(--warning)':'var(--success)'};">${s.priority}</span><br>
        <span style="font-size:12px;color:var(--muted)">${s.reason}</span><br>
        <span style="font-size:12px">Order: <b>${s.recommendedQty} units</b> · Est. ${s.estimatedCost}</span>
      </div>`
    ).join('');

    showAIPanel('📦 Smart Reorder Suggestions', html);
    showToast('success', '✅ Reorder Analysis Done', `${suggestions.length} items need attention`);
  } catch (e) {
    showToast('danger', '❌', e.message);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '🤖 Smart Reorder'; }
  }
}

// ── 3. EXPIRY RISK ANALYSIS (JS Logic — no API needed) ───────────
async function runExpiryRisk() {
  const btn = document.getElementById('aiExpiryBtn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Analyzing...'; }

  await new Promise(r => setTimeout(r, 1400)); // realistic loading

  try {
    const today = new Date();
    const expiryItems = inventoryData.filter(i => i.expiry && i.expiry !== 'N/A');

    const categorized = { urgent: [], moderate: [], lowRisk: [] };
    expiryItems.forEach(item => {
      const days = Math.ceil((new Date(item.expiry) - today) / 86400000);
      const obj = {
        name: item.name,
        daysLeft: days,
        action: days < 0 ? 'Dispose immediately — already expired'
          : days < 15 ? 'Quarantine and arrange disposal'
          : days < 30 ? 'Use immediately or transfer to high-usage ward'
          : days < 60 ? 'Prioritize usage — monitor closely'
          : days < 90 ? 'Schedule reorder review'
          : 'Continue monitoring',
        dispose: days < 0
      };
      if (days < 30) categorized.urgent.push(obj);
      else if (days < 90) categorized.moderate.push(obj);
      else categorized.lowRisk.push(obj);
    });

    const totalUrgent = categorized.urgent.length;
    const totalModerate = categorized.moderate.length;
    const riskSummary = totalUrgent > 0
      ? `${totalUrgent} item(s) expiring within 30 days require immediate action. ${totalModerate} item(s) in moderate risk zone need close monitoring.`
      : totalModerate > 0
      ? `No critical expiry items found. ${totalModerate} item(s) expiring within 90 days — plan reorders accordingly.`
      : 'All items have healthy expiry dates. Continue routine monitoring and restocking.';

    const recommendations = [
      'Use FIFO (First In, First Out) method for all stock rotation',
      'Set monthly expiry review meetings for pharmacy team',
      totalUrgent > 0 ? `Immediately quarantine ${totalUrgent} near-expiry item(s)` : 'Maintain current inventory levels for stable items',
    ];

    const section = (title, items, color) => items?.length ? `
      <div style="margin-bottom:10px">
        <div style="font-weight:700;color:${color};margin-bottom:6px">${title}</div>
        ${items.map(i => `<div style="padding:6px 8px;background:var(--surface);border-radius:6px;margin-bottom:4px;font-size:12px">
          <b>${i.name}</b> — ${i.daysLeft < 0 ? 'EXPIRED' : i.daysLeft + ' days left'}<br>
          <span style="color:var(--muted)">${i.action}</span>
          ${i.dispose ? '<span style="color:var(--danger);font-weight:700"> · DISPOSE</span>' : ''}
        </div>`).join('')}
      </div>` : '';

    const html = `
      <div style="font-size:13px;color:var(--muted);margin-bottom:12px">${riskSummary}</div>
      ${section('🚨 Urgent (< 30 days)', categorized.urgent, 'var(--danger)')}
      ${section('⚠️ Moderate (30–90 days)', categorized.moderate, 'var(--warning)')}
      ${section('✅ Low Risk (> 90 days)', categorized.lowRisk, 'var(--success)')}
      <div style="margin-top:10px;padding:10px;background:rgba(0,212,255,0.05);border-radius:8px;border:1px solid rgba(0,212,255,0.15)">
        <div style="font-weight:700;color:var(--accent);margin-bottom:6px">💡 Recommendations</div>
        ${recommendations.map(r => `<div style="font-size:12px;color:var(--muted);margin-bottom:4px">• ${r}</div>`).join('')}
      </div>`;

    showAIPanel('⏱️ Expiry Risk Analysis', html);
    showToast('success', '✅ Expiry Analysis Complete', `${totalUrgent} urgent, ${totalModerate} moderate risk items`);
  } catch (e) {
    showToast('danger', '❌', e.message);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '🤖 Expiry Risk AI'; }
  }
}

// ── 4. NATURAL LANGUAGE SEARCH (JS Logic — no API needed) ──────
// ── Natural Language Search (Settings Page — no navigation) ────
function runNLSearchSettings() {
  const input = document.getElementById('nlSearchInput');
  const query = (input?.value || '').trim();
  const answerEl = document.getElementById('nlSearchAnswer');
  const btn = document.getElementById('nlSearchBtn');

  if (!query || query.length < 2) {
    if (answerEl) {
      answerEl.style.display = 'block';
      answerEl.innerHTML = '<span style="color:var(--warning)">⚠ Please enter at least 2 characters to search.</span>';
    }
    return;
  }

  if (btn) { btn.disabled = true; btn.textContent = '⏳'; }
  if (answerEl) { answerEl.style.display = 'block'; answerEl.innerHTML = '<span style="color:var(--muted)">🔍 Searching...</span>'; }

  setTimeout(() => {
    try {
      const q = query.toLowerCase();
      const today = new Date();
      let matched = [];
      let answer = '';
      let suggestion = '';
      let matchedIds = [];

      // keyword matching
      if (/out.?of.?stock|zero|empty|இல்லை/.test(q)) {
        matched = inventoryData.filter(i => i.stock === 0);
        answer = matched.length > 0
          ? `🚫 <b>${matched.length} item(s) out of stock:</b><br>` + matched.map(i => `• <b>${i.name}</b> (${i.id}) — ${i.location}`).join('<br>')
          : '✅ No items are currently out of stock.';
        suggestion = matched.length > 0 ? 'Go to Auto Reorder to place orders.' : '';
      }
      else if (/critical|urgent|அவசர|முக்கியம்/.test(q)) {
        matched = inventoryData.filter(i => i.status === 'critical' || i.risk === 'critical');
        answer = matched.length > 0
          ? `🚨 <b>${matched.length} critical item(s):</b><br>` + matched.map(i => `• <b>${i.name}</b> — only <b>${i.stock} units</b> (${i.location})`).join('<br>')
          : '✅ No critical stock items right now.';
        suggestion = matched.length > 0 ? 'Use Smart Reorder to generate purchase orders.' : '';
      }
      else if (/expir|காலாவதி|கெட்டு/.test(q)) {
        matched = inventoryData.filter(i => {
          if (!i.expiry || i.expiry === 'N/A') return false;
          const d = new Date(i.expiry);
          return (d - today) / 86400000 < 90;
        });
        answer = matched.length > 0
          ? `⏰ <b>${matched.length} item(s) expiring within 90 days:</b><br>` + matched.map(i => `• <b>${i.name}</b> — expires ${i.expiry}`).join('<br>')
          : '✅ No items expiring within 90 days.';
        suggestion = matched.length > 0 ? 'Run Expiry Risk AI for detailed analysis.' : '';
      }
      else if (/low|warn|குறைவு|கம்மி/.test(q)) {
        matched = inventoryData.filter(i => i.status === 'warn' || i.status === 'critical');
        answer = matched.length > 0
          ? `⚠️ <b>${matched.length} low-stock item(s):</b><br>` + matched.map(i => `• <b>${i.name}</b> — ${i.stock} units (threshold: ${i.reorderPt})`).join('<br>')
          : '✅ All items have adequate stock.';
      }
      else if (/reorder|order|ஆர்டர்/.test(q)) {
        matched = inventoryData.filter(i => i.stock <= i.reorderPt);
        answer = matched.length > 0
          ? `🛒 <b>${matched.length} item(s) need reorder:</b><br>` + matched.map(i => `• <b>${i.name}</b> — ${i.stock} left (min: ${i.reorderPt})`).join('<br>')
          : '✅ No items need reordering right now.';
      }
      else if (/total|how many|count|எத்தனை|மொத்த/.test(q)) {
        const ok = inventoryData.filter(i => i.status === 'ok').length;
        const warn = inventoryData.filter(i => i.status === 'warn').length;
        const crit = inventoryData.filter(i => i.status === 'critical').length;
        answer = `📦 <b>Inventory Summary:</b><br>• Total SKUs: <b>${inventoryData.length}</b><br>• In Stock (OK): <b>${ok}</b><br>• Low Stock: <b>${warn}</b><br>• Critical: <b>${crit}</b>`;
      }
      else if (/drug|medicine|மருந்து/.test(q)) {
        matched = inventoryData.filter(i => i.cat === 'drug' || i.cat === 'critical');
        answer = `💊 <b>${matched.length} drug/medicine item(s):</b><br>` + matched.map(i => `• <b>${i.name}</b> — ${i.stock} units`).join('<br>');
      }
      else {
        // Direct name/id/location search
        matched = inventoryData.filter(i =>
          i.name.toLowerCase().includes(q) ||
          i.id.toLowerCase().includes(q) ||
          i.location.toLowerCase().includes(q)
        );
        if (matched.length > 0) {
          answer = `🔎 <b>${matched.length} item(s) found for "${query}":</b><br>` +
            matched.map(i => {
              const col = i.status === 'critical' ? 'var(--danger)' : i.status === 'warn' ? 'var(--warning)' : 'var(--success)';
              return `• <b>${i.name}</b> (${i.id}) — <span style="color:${col};font-weight:600">${i.stock} units</span> · ${i.location}`;
            }).join('<br>');
        } else {
          answer = `🤖 No match found for <b>${query}</b>.<br><br>Try: <i>critical items, low stock, expiring, reorder, medicine, total</i><br>Or type an item name like <i>Paracetamol</i>`;
        }
      }

      matchedIds = matched.map(i => i.id);

      if (answerEl) {
        answerEl.style.display = 'block';
        answerEl.innerHTML = `
          <div style="display:flex;gap:10px;align-items:flex-start">
            <span style="font-size:18px">🤖</span>
            <div style="flex:1">
              <div style="color:var(--text);line-height:1.6">${answer}</div>
              ${suggestion ? `<div style="font-size:11px;color:var(--muted);margin-top:6px">💡 ${suggestion}</div>` : ''}
              ${matchedIds.length > 0 ? `<button onclick="highlightInventoryItems(${JSON.stringify(matchedIds)}); this.parentElement.parentElement.parentElement.previousElementSibling.previousElementSibling.querySelector('input').value=''" class="btn btn-ghost" style="font-size:11px;margin-top:8px;padding:4px 10px">📋 View in Inventory →</button>` : ''}
            </div>
          </div>`;
      }
    } catch(e) {
      if (answerEl) { answerEl.innerHTML = `<span style="color:var(--danger)">Error: ${e.message}</span>`; }
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = '🔍'; }
    }
  }, 300);
}

async function runNLSearch(query) {
  if (!query || query.trim().length < 2) return;
  const btn = document.getElementById('nlSearchBtn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳'; }

  await new Promise(r => setTimeout(r, 400));

  try {
    const q = query.toLowerCase().trim();
    const today = new Date();

    // Keyword maps — English + Tamil
    const keywords = {
      critical:   ['critical','urgent','critical','முக்கியமான','அவசர'],
      low:        ['low','less','குறைவு','கம்மி','stock low'],
      expiry:     ['expir','expire','காலாவதி','கெட்டுப்போகும்'],
      outofstock: ['out of stock','zero','empty','இல்லை','ஸ்டாக் இல்லை'],
      warn:       ['warn','warning','எச்சரிக்கை'],
      drug:       ['drug','medicine','மருந்து'],
      supply:     ['supply','supplies','supplies','சப்ளை'],
      device:     ['device','equipment','சாதனம்'],
      icu:        ['icu','intensive'],
      pharmacy:   ['pharmacy','pharma','மருந்தகம்'],
    };

    let matched = [];
    let answer = '';
    let suggestion = '';

    // Out of stock
    if (keywords.outofstock.some(k => q.includes(k))) {
      matched = inventoryData.filter(i => i.stock === 0);
      answer = matched.length > 0
        ? `${matched.length} item(s) are out of stock: ${matched.map(i=>i.name).join(', ')}`
        : 'No items are currently out of stock.';
      suggestion = 'Check Auto Reorder page to place orders.';
    }
    // Critical items
    else if (keywords.critical.some(k => q.includes(k))) {
      matched = inventoryData.filter(i => i.status === 'critical');
      answer = matched.length > 0
        ? `${matched.length} critical item(s) found: ${matched.map(i=>i.name).join(', ')}`
        : 'No critical stock items at the moment.';
      suggestion = 'Use Smart Reorder to generate purchase orders.';
    }
    // Expiry
    else if (keywords.expiry.some(k => q.includes(k))) {
      matched = inventoryData.filter(i => {
        if (!i.expiry || i.expiry === 'N/A') return false;
        const days = Math.ceil((new Date(i.expiry) - today) / 86400000);
        return days < 90;
      });
      answer = matched.length > 0
        ? `${matched.length} item(s) expiring within 90 days: ${matched.map(i=>i.name).join(', ')}`
        : 'No items expiring soon.';
      suggestion = 'Run Expiry Risk AI for detailed analysis.';
    }
    // Low stock
    else if (keywords.low.some(k => q.includes(k))) {
      matched = inventoryData.filter(i => i.status === 'warn' || i.status === 'critical');
      answer = matched.length > 0
        ? `${matched.length} item(s) with low stock: ${matched.map(i=>i.name).join(', ')}`
        : 'All items have adequate stock levels.';
    }
    // By category
    else if (keywords.drug.some(k => q.includes(k))) {
      matched = inventoryData.filter(i => i.cat === 'drug');
      answer = `${matched.length} drug(s) in inventory: ${matched.map(i=>i.name).join(', ')}`;
    }
    else if (keywords.device.some(k => q.includes(k))) {
      matched = inventoryData.filter(i => i.cat === 'device');
      answer = `${matched.length} device(s) found: ${matched.map(i=>i.name).join(', ')}`;
    }
    else if (keywords.supply.some(k => q.includes(k))) {
      matched = inventoryData.filter(i => i.cat === 'supply');
      answer = `${matched.length} supply item(s): ${matched.map(i=>i.name).join(', ')}`;
    }
    // Location search
    else if (keywords.icu.some(k => q.includes(k))) {
      matched = inventoryData.filter(i => i.location.toLowerCase().includes('icu'));
      answer = `${matched.length} item(s) in ICU: ${matched.map(i=>i.name).join(', ')}`;
    }
    else if (keywords.pharmacy.some(k => q.includes(k))) {
      matched = inventoryData.filter(i => i.location.toLowerCase().includes('pharmacy'));
      answer = `${matched.length} item(s) in Pharmacy: ${matched.map(i=>i.name).join(', ')}`;
    }
    // Direct name search
    else {
      matched = inventoryData.filter(i =>
        i.name.toLowerCase().includes(q) ||
        i.id.toLowerCase().includes(q) ||
        i.location.toLowerCase().includes(q)
      );
      answer = matched.length > 0
        ? `Found ${matched.length} item(s) matching "${query}": ${matched.map(i => i.name + ' (' + i.stock + ' units)').join(', ')}`
        : `No items found matching "${query}". Try searching by name, location, or category.`;
      suggestion = matched.length === 0 ? 'Try: "critical items", "expiring soon", "ICU stock"' : '';
    }

    const answerEl = document.getElementById('nlSearchAnswer');
    if (answerEl) {
      answerEl.style.display = 'block';
      answerEl.innerHTML = `
        <div style="display:flex;gap:10px;align-items:flex-start">
          <span style="font-size:20px">🤖</span>
          <div>
            <div style="font-size:13px;color:var(--text);margin-bottom:4px">${answer}</div>
            ${suggestion ? `<div style="font-size:11px;color:var(--muted)">💡 ${suggestion}</div>` : ''}
          </div>
        </div>`;
    }

    if (matched.length > 0) {
      highlightInventoryItems(matched.map(i => i.id));
    }

  } catch (e) {
    const answerEl = document.getElementById('nlSearchAnswer');
    if (answerEl) { answerEl.style.display='block'; answerEl.innerHTML = `<span style="color:var(--muted)">Search error: ${e.message}</span>`; }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '🔍'; }
  }
}

function highlightInventoryItems(ids) {
  navigateTo('inventory');
  setTimeout(() => {
    document.querySelectorAll('#inventoryTableBody tr').forEach(row => {
      const idCell = row.querySelector('td:first-child');
      if (idCell) {
        const matched = ids.some(id => idCell.textContent.includes(id));
        row.style.background = matched ? 'rgba(0,212,255,0.1)' : '';
        row.style.borderLeft = matched ? '3px solid var(--accent)' : '';
      }
    });
  }, 300);
}

// ── Local AI fallback (no API key needed) ────────────────────────
function _localAIReply(msg) {
  const q = msg.toLowerCase();

  // Stock status queries
  const critical = inventoryData.filter(i => i.status === 'critical');
  const warn     = inventoryData.filter(i => i.status === 'warn');
  const expiring = inventoryData.filter(i => i.expiry && i.expiry !== 'N/A' && new Date(i.expiry.split('/').reverse().join('-')) < new Date(Date.now() + 30*24*60*60*1000));

  if (q.includes('critical') || q.includes('urgent') || q.includes('அவசர') || q.includes('அவசரம்')) {
    if (critical.length === 0) return '✅ <b>No critical items</b> right now. All stocks are at safe levels.';
    return `🚨 <b>${critical.length} critical item(s):</b><br>${critical.map(i => `• <b>${i.name}</b> — only <b>${i.stock} units</b> left (${i.location})`).join('<br>')}`;
  }

  if (q.includes('low') || q.includes('warn') || q.includes('குறைவு') || q.includes('குறைந்த')) {
    if (warn.length === 0) return '✅ No low-stock items currently.';
    return `⚠️ <b>${warn.length} low-stock item(s):</b><br>${warn.map(i => `• <b>${i.name}</b> — ${i.stock} units`).join('<br>')}`;
  }

  if (q.includes('expir') || q.includes('காலாவதி')) {
    if (expiring.length === 0) return '✅ No items expiring in the next 30 days.';
    return `📅 <b>${expiring.length} item(s) expiring soon:</b><br>${expiring.map(i => `• <b>${i.name}</b> — expires ${i.expiry}`).join('<br>')}`;
  }

  if (q.includes('total') || q.includes('how many') || q.includes('count') || q.includes('எத்தனை') || q.includes('மொத்த')) {
    return `📦 <b>Inventory Summary:</b><br>• Total SKUs: <b>${inventoryData.length}</b><br>• In Stock (OK): <b>${inventoryData.filter(i=>i.status==='ok').length}</b><br>• Low Stock: <b>${warn.length}</b><br>• Critical: <b>${critical.length}</b>`;
  }

  if (q.includes('reorder') || q.includes('order') || q.includes('ஆர்டர்')) {
    const needReorder = inventoryData.filter(i => i.stock <= i.reorderPt);
    if (needReorder.length === 0) return '✅ No items need reordering right now.';
    return `🛒 <b>${needReorder.length} item(s) need reorder:</b><br>${needReorder.map(i=>`• <b>${i.name}</b> — ${i.stock} left (threshold: ${i.reorderPt})`).join('<br>')}`;
  }

  if (q.includes('icu') || q.includes('ot ') || q.includes('pharmacy') || q.includes('ward') || q.includes('store')) {
    const loc = inventoryData.filter(i => i.location.toLowerCase().includes(q.split(' ')[q.split(' ').findIndex(w=>['icu','ot','pharmacy','ward','store'].includes(w))]||''));
    if (loc.length > 0) return `📍 <b>Items in that location:</b><br>${loc.map(i=>`• ${i.name}: ${i.stock} units`).join('<br>')}`;
  }

  // Item name search
  const words = q.split(/\s+/).filter(w => w.length > 2);
  const found = inventoryData.filter(i => words.some(w => i.name.toLowerCase().includes(w) || i.id.toLowerCase().includes(w)));
  if (found.length > 0) {
    return found.map(i => {
      const days = i.dailyUse > 0 ? Math.ceil(i.stock / i.dailyUse) : '∞';
      const col = i.status === 'critical' ? 'var(--danger)' : i.status === 'warn' ? 'var(--warning)' : 'var(--success)';
      return `💊 <b>${i.name}</b> (${i.id})<br>Stock: <b style="color:${col}">${i.stock} units</b> · Location: ${i.location}<br>Days remaining: <b>${days}</b> · Expiry: ${i.expiry}`;
    }).join('<br><br>');
  }

  // Help & greeting
  if (q.includes('help') || q.includes('உதவி') || q.includes('hi') || q.includes('hello') || q.includes('வணக்கம்')) {
    return `👋 <b>MedAI Assistant</b> — என்னால் உதவ முடியும்!<br><br>Try asking:<br>• "Show critical items" / "அவசர items காட்டு"<br>• "Low stock list"<br>• "Items expiring soon"<br>• "How many items total"<br>• "Paracetamol stock"<br><br>💡 Add an API key in Settings for full AI responses.`;
  }

  return `🤖 I searched your inventory for <b>"${msg}"</b> but couldn't find a match.<br><br>Try: <i>critical items, low stock, expiring soon, reorder list,</i> or an item name like <i>"Paracetamol"</i>.<br><br>💡 Add an OpenRouter API key in <b>Settings → AI Configuration</b> for full natural language AI.`;
}

// ── AI Chat (Real) ────────────────────────────────────────────────
async function sendAIMessage() {
  const input = document.getElementById('aiInputField');
  const msg = input.value.trim();
  if (!msg) return;

  const chat = document.getElementById('aiChat');
  const userDiv = document.createElement('div');
  userDiv.className = 'msg user';
  userDiv.innerHTML = `<div class="msg-icon">👤</div><div class="msg-bubble">${msg}</div>`;
  chat.appendChild(userDiv);
  input.value = '';
  chat.scrollTop = chat.scrollHeight;

  // Loading bubble
  const loadDiv = document.createElement('div');
  loadDiv.className = 'msg ai';
  loadDiv.id = 'aiLoadingMsg';
  loadDiv.innerHTML = `<div class="msg-icon">🤖</div><div class="msg-bubble" style="color:var(--muted)">⏳ Thinking...</div>`;
  chat.appendChild(loadDiv);
  chat.scrollTop = chat.scrollHeight;

  if (!hasApiKey()) {
    // ── Smart local fallback (works without API key) ──────────────
    setTimeout(() => {
      loadDiv.remove();
      const reply = _localAIReply(msg);
      const aiDiv = document.createElement('div');
      aiDiv.className = 'msg ai';
      aiDiv.innerHTML = `<div class="msg-icon">🤖</div><div class="msg-bubble">${reply}</div>`;
      chat.appendChild(aiDiv);
      chat.scrollTop = chat.scrollHeight;
    }, 700);
    return;
  }

  const system = `You are MedAI Pro's hospital inventory AI assistant. You have access to this inventory:
${JSON.stringify(inventoryData.map(i => ({ name:i.name, id:i.id, stock:i.stock, status:i.status, expiry:i.expiry, location:i.location, dailyUse:i.dailyUse })))}
Answer concisely. Support both English and Tamil questions. Format with bold for key info.`;

  try {
    const reply = await callClaude(system, msg, 500);
    loadDiv.remove();
    const aiDiv = document.createElement('div');
    aiDiv.className = 'msg ai';
    aiDiv.innerHTML = `<div class="msg-icon">🤖</div><div class="msg-bubble">${reply.replace(/\n/g,'<br>')}</div>`;
    chat.appendChild(aiDiv);
  } catch (e) {
    loadDiv.remove();
    const aiDiv = document.createElement('div');
    aiDiv.className = 'msg ai';
    aiDiv.innerHTML = `<div class="msg-icon">🤖</div><div class="msg-bubble" style="color:var(--danger)">Error: ${e.message === 'INVALID_KEY' ? 'Invalid API key. Check Settings.' : e.message}</div>`;
    chat.appendChild(aiDiv);
  }
  chat.scrollTop = chat.scrollHeight;
}

// ── Shared AI Result Panel ───────────────────────────────────────
function showAIPanel(title, htmlContent) {
  let panel = document.getElementById('aiResultPanel');
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'aiResultPanel';
    panel.style.cssText = `
      position:fixed;right:20px;bottom:20px;width:400px;max-height:70vh;
      background:var(--card);border:1px solid var(--accent);border-radius:16px;
      box-shadow:0 8px 40px rgba(0,212,255,0.15);z-index:3000;
      display:flex;flex-direction:column;overflow:hidden;`;
    document.body.appendChild(panel);
  }
  panel.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;background:var(--surface);border-bottom:1px solid var(--border);">
      <div style="font-weight:700;font-size:13px;color:var(--accent)">${title}</div>
      <span onclick="document.getElementById('aiResultPanel').remove()" style="cursor:pointer;color:var(--muted);font-size:18px;line-height:1">✕</span>
    </div>
    <div style="padding:14px 16px;overflow-y:auto;flex:1;">${htmlContent}</div>`;
  panel.style.display = 'flex';
}

// ── On load: show API key status in settings ──────────────────────
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(checkApiKeyStatus, 500);
  // Apply saved language and backup schedule on startup
  const startSaved = _loadSettingsFromDisk();
  if (startSaved) {
    Object.assign(appSettings, startSaved);
    if (appSettings.language && appSettings.language !== 'English') {
      applyLanguage(appSettings.language);
    }
    if (appSettings.backupFreq) {
      scheduleAutoBackup(appSettings.backupFreq);
    }
  }
});
